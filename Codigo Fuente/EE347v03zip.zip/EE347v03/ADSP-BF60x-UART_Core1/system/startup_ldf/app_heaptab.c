/* MANAGED-BY-SOURCE-GENERATOR                                  */
/* CrossCore Embedded Studio                                    */
/* LDFGenPrinter version: 6.0.2.21                              */
/* LDFGen version: 6.0.2.21                                     */
/* VDSG version: 6.0.2.21                                       */

/*
** User heap source file generated on Feb 22, 2012 at 10:25:47.
**
** Copyright (C) 2000-2012 Analog Devices Inc., All Rights Reserved.
**
** This file is generated automatically based upon the options selected in the
** Startup Code/LDF Configuration Editor. Changes to the Stack/Heap configuration
** should be made by changing the appropriate options rather than editing this file.
**
** Additional user code can be inserted within the user-modifiable sections.
** Code place within these sections is preserved if this file is re-generated.
**
** Configuration:-
**     crt_doj:                                app_startup.doj
**     processor:                              ADSP-BF609
**     product_name:                           CrossCore Embedded Studio
**     si_revision:                            0.0
**     default_silicon_revision_from_archdef:  0.0
**     device_init:                            true
**     cplb_init:                              true
**     cplb_init_cplb_ctrl:                    57
**     cplb_init_cplb_src_file:                app_cplbtab.c
**     cplb_init_cplb_obj_file:                app_cplbtab.doj
**     cplb_init_cplb_src_alt:                 false
**     dcache_config:                          disable_dcache_and_enable_cplb
**     icache_config:                          enable_icache
**     using_cplusplus:                        true
**     use_profiling:                          false
**     mem_init:                               false
**     use_eh:                                 true
**     use_argv:                               false
**     use_pgo_hw:                             false
**     use_full_cpplib:                        false
**     running_from_internal_memory:           true
**     user_heap_src_file:                     app_heaptab.c
**     libraries_use_fileio_libs:              false
**     libraries_use_eh_enabled_libs:          false
**     libraries_use_fixed_point_io_libs:      false
**     libraries_heap_dbg_libs:                false
**     libraries_use_utility_rom:              false
**     detect_stackoverflow:                   false
**     system_heap:                            L1
**     system_heap_min_size:                   2
**     system_heap_size_units:                 kB
**     system_stack:                           L1
**     system_stack_min_size:                  2
**     system_stack_size_units:                kB
**     use_sdram:                              false
**     use_mt:                                 false
**     use_software_modules:                   false
**     use_multicores:                         2
**     use_multicores_use_core:                coreB
**     coreID:                                 1
**
*/

#ifdef _MISRA_RULES
#pragma diag(push)
#pragma diag(suppress:misra_rule_1_1)
#pragma diag(suppress:misra_rule_2_2)
#pragma diag(suppress:misra_rule_6_3)
#pragma diag(suppress:misra_rule_8_10)
#pragma diag(suppress:misra_rule_10_1_a)
#pragma diag(suppress:misra_rule_11_3)
#pragma diag(suppress:misra_rule_12_7)
#else
#pragma diag(suppress:1124)
#endif /* _MISRA_RULES */


extern "asm" int ldf_heap_space;
extern "asm" int ldf_heap_length;

struct heap_table_t
{
  void          *base;
  unsigned long  length;
  long int       userid;
};

#pragma file_attr("libData=HeapTable")
#pragma section("constdata")
struct heap_table_t heap_table[2] =
{

  { &ldf_heap_space, (unsigned long) &ldf_heap_length, 0 },

  { 0, 0, 0 }
};

#ifdef _MISRA_RULES
#pragma diag(pop)
#endif /* _MISRA_RULES */

