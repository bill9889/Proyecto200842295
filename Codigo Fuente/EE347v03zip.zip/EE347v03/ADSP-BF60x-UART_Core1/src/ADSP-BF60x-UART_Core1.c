/*****************************************************************************
 * ADSP-BF60x-UART_Core1.c
 *****************************************************************************/

#include <ccblkfn.h>
#include "adi_initialize.h"
#include "../../ADSP-BF60x-UART/src/ADSP-BF60x-UART.h"

int main(void)
{
	while(1) { idle(); }
/*
	mcapi_param_t init_parameters;
	mcapi_info_t mcapi_info;
	mcapi_status_t mcapi_status;

	// Add your operating system initialization code here

	// Initialize MCAPI
	mcapi_initialize(
		DOMAIN, 
		NODE_CORE_B, 
		&init_parameters,
		&mcapi_info,
		&mcapi_status );

	if(MCAPI_SUCCESS != mcapi_status)
	{
		exit(1);
	}

	// Initialize any managed drivers and/or services
	adi_initComponents();

	// Begin adding your custom code here
*/
	return 0;
}

