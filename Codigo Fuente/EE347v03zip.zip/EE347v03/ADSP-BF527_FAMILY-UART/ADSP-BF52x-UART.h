/*****************************************************************************
**                                                                          **
**  Name:   UART Software Interface                                         **
**                                                                          **
******************************************************************************

(C) Copyright 2009 - Analog Devices, Inc.  All rights reserved.

File Name:      ADSP-BF52x-UART.h

Date Modified:  03/11/2010

Processor:      ADSP-BF526/4/2

Software:       VisualDSP++ 5.0

Purpose:        This file contains some library functions commonly used on UART processing.

                uart print functions (Core and DMA version) are available,
                which use the same syntax like the c standard i/o printf function

******************************************************************************/

#ifndef _UART_H_
#define _UART_H_

/*******************************************************************************
*
*  Include File Area
*
*******************************************************************************/

/*******************************************************************************
*
*  Exported Constants/Definition Area
*
*******************************************************************************/

// USE_UART_NR sets the UART Nr to be used.
// USE_UART_DMA_NR sets the DMA channel Nr to be used.
// Autobaud detection is optional.
// USE_UART_BITRATE sets a fixed UartBitrate.
#define USE_UART_NR     0
#define AUTOBAUD        0

#if (AUTOBAUD==0)
#define USE_UART_BITRATE 115200
#endif

/* This are the default UART peripheral DMAs */
/* As there can only be one DMA channel assign to the same peripheral, */
/* the PMAP value of the default channel must be changed as well, */
/* if these definitions are changed! */
#define UART0RX_DMA     8
#define UART0TX_DMA     9
#define UART1RX_DMA     10
#define UART1TX_DMA     11

#if   (USE_UART_NR == 0)
    #define USE_UART_DMA_NR UART0TX_DMA
#elif (USE_UART_NR == 1)
    #define USE_UART_DMA_NR UART1TX_DMA
#else
    #error Wrong or unknown definition for USE_UART_NR
#endif

/*******************************************************************************
*
*  Exported Types Area
*
*******************************************************************************/

/*******************************************************************************
*
*  Exported Macros Area
*
*******************************************************************************/

/*******************************************************************************
*
*  Exported Function Prototypes Area
*
*******************************************************************************/

/* Programm Flow:
UartDmaInitTxAutobaud() -> UartInitAutobaud() -> return
UartInitAutobaud() -> UartGpioInit() -> UartAutobaud() -> return

UartDmaInitTx() -> UartInit() -> return
UartInit() -> UartGpioInit() -> return
*/

short UartGpioInit(unsigned char UartNum);
short UartInterruptsInit(unsigned char UartNum);

long  UartAutobaud(unsigned char UartNum);

long  UartInitAutobaud(unsigned char UartNum);
short UartInit(unsigned char UartNum, unsigned long UartBitrate);
short UartInitTerminal(unsigned char UartNum, unsigned long UartBitrate);
short UartDmaInitTx(unsigned char UartNum, unsigned char DmaChan);
short UartDmaInitRx(unsigned char UartNum, unsigned char DmaChan);

short UartWaitForTransmitCompletion(unsigned char UartNum);
short UartDmaWaitForTransmitCompletion(unsigned char UartNum, unsigned char DmaChan);
short UartDmaWaitForDmaDone(unsigned char DmaChan);

short UartClockDisable(unsigned char UartNum);
short UartDmaDisable(unsigned char UartNum, unsigned char DmaChan);

short UartPutc(unsigned char UartNum, char c);
short UartPuts(unsigned char UartNum, char *c);
short UartPutsn(unsigned char UartNum, char *c, unsigned long NumChar);
short UartDmaPuts(unsigned char UartNum, unsigned char DmaChan, char *c);
short UartDmaPutsn(unsigned char UartNum, unsigned char DmaChan, char *c, unsigned short NumChar);

char  UartGetc(unsigned char UartNum);
short UartGets(unsigned char UartNum, char *c);
short UartGetsn(unsigned char UartNum, char *c, unsigned long NumChar);
short UartDmaGetsn(unsigned char UartNum, unsigned char DmaChan, char *c, unsigned short NumChar);

short UartGetsEcho(unsigned char UartNum, char *c);
short UartEcho(unsigned char UartNum);
short UartEchoPrompt(unsigned char UartNum);

long  UartGetBitrate(unsigned char UartNum);
short UartSetBitrate(unsigned char UartNum, unsigned long UartBitrate);

#endif /* _UART_H_ */
/******************************** End of File *********************************/
