/* MANAGED-BY-SYSTEM-BUILDER                                    */
/* VisualDSP++ 5.0 Update 8                                     */
/* LDF Printer version: 5.8.0.2                                 */
/* ldfgen.exe version: 5.8.0.2                                  */
/* VDSG version: 5.8.0.2                                        */

/*
** User heap source file generated on Apr 26, 2010 at 13:24:56.
**
** Copyright (C) 2000-2010 Analog Devices Inc., All Rights Reserved.
**
** This file is generated automatically based upon the options selected
** in the LDF Wizard. Changes to the LDF configuration should be made by
** changing the appropriate options rather than editing this file.
**
** Configuration:-
**     crt_doj:                                ADSP-BF59x-UART_basiccrt.doj
**     processor:                              ADSP-BF592-A
**     product_name:                           VisualDSP++ 5.0 Update 8
**     si_revision:                            0.0
**     default_silicon_revision_from_archdef:  0.0
**     using_cplusplus:                        true
**     mem_init:                               false
**     use_vdk:                                false
**     use_eh:                                 true
**     use_argv:                               false
**     running_from_internal_memory:           true
**     user_heap_src_file:                     C:\Users\APellkof\My Documents\DSP\Blackfin\Code\c\UART\BfUart\ADSP-BF59x-UART\ADSP-BF59x-UART_heaptab.c
**     libraries_use_stdlib:                   true
**     libraries_use_fileio_libs:              false
**     libraries_use_ieeefp_emulation_libs:    false
**     libraries_use_eh_enabled_libs:          false
**     system_heap:                            L1
**     system_heap_min_size:                   2k
**     system_stack:                           L1
**     system_stack_min_size:                  2k
**     use_sdram:                              false
**     num_user_heaps:                         1
**     user_heap0:                             SCRATCHPAD
**     user_heap0_size:                        1k
**     user_heap0_heap_name:                   MyHeap
**
*/


#ifdef _MISRA_RULES
#pragma diag(push)
#pragma diag(suppress:misra_rule_1_1)
#pragma diag(suppress:misra_rule_2_2)
#pragma diag(suppress:misra_rule_6_3)
#pragma diag(suppress:misra_rule_8_10)
#pragma diag(suppress:misra_rule_10_1_a)
#pragma diag(suppress:misra_rule_11_3)
#pragma diag(suppress:misra_rule_12_7)
#else
#pragma diag(suppress:1124)
#endif /* _MISRA_RULES */



extern "asm" int ldf_heap_space;
extern "asm" int ldf_heap_length;
extern "asm" int MyHeap_space;
extern "asm" int MyHeap_length;


struct heap_table_t
{
  void          *base;
  unsigned long  length;
  long int       userid;
};

#pragma file_attr("libData=HeapTable")
#pragma section("constdata")
struct heap_table_t heap_table[3] =
{


  { &ldf_heap_space, (unsigned long) &ldf_heap_length, 0 },
  { &MyHeap_space, (unsigned long) &MyHeap_length, 1 },


  { 0, 0, 0 }
};



#ifdef _MISRA_RULES
#pragma diag(pop)
#endif /* _MISRA_RULES */


