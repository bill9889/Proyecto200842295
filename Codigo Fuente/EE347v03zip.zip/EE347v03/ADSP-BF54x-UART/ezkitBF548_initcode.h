/****************************************************************************
 Include Section
*****************************************************************************/

/*****************************************************************************
 Symbolic constants / definitions
******************************************************************************/

#undef SPI_BAUD
#define SPI_BAUD            SPI0_BAUD


/*****************************************************************************
 Dynamic Power Managment
*****************************************************************************/

/*************************************************
* To activate PLL and Voltage Regulator settings *
* uncomment the following definition             *
*************************************************/

#define __ACTIVATE_DPM__


/********************************
* PLL Control Register Value    *
* Reset = 0x1000                *
* ADSP-BF548 EZ-KIT Lite:       *
* CLKIN = 25MHz                 *
* MSEL = 21                     *
* --> VCO = 25MHz x 21 = 525MHz *
********************************/

#define PLL_CTL_VAL             (\
                               nBYPASS              |   /* Bypass the PLL */\
                               nOUTPUT_DELAY        |   /* Add 200ps Delay To EBIU Output Signals */\
                               nINPUT_DELAY         |   /* Add 200ps Delay To EBIU Input Latches */\
                               nPDWN                |   /* Enter Deep Sleep Mode */\
                               nSTOPCK              |   /* Core Clock Off */\
                               nPLL_OFF             |   /* PLL Not Powered */\
                               nDF                  |   /* 0: PLL = CLKIN, 1: PLL = CLKIN/2 */\
                                SET_MSEL(21)        |   /* Set MSEL = 0-63 --> VCO = CLKIN*MSEL */\
                                0)

#define CLKIN_Hz                 25000000           /* CLKIN [Hz] */
#define VCO_MAX_Hz              533000000           /* VCO [Hz] */
#define VCO_MIN_Hz               50000000           /* VCO [Hz] */


/************************************
* PLL Divide Register Value         *
* Reset = 0x0004                    *
* ADSP-BF548 EZ-KIT Lite:           *
* CSEL = 1                          *
* --> CCLK = VCO / CSEL             *
* --> CCLK = 525MHz / 1 = 525MHz    *
* SSEL = 4                          *
* --> SCLK = VCO / SSEL             *
* --> SCLK = 525MHz / 4 = 131.25MHz *
************************************/

#define PLL_DIV_VAL             (\
                                SET_SSEL(4)         |   /* Set SSEL = 1-15 --> SCLK = VCO/SSEL */\
                                CSEL_DIV1           |   /* CCLK = VCO / 1 */\
                                0)

#define CCLK_MAX_Hz             VCO_MAX_Hz          /* Maximum Core Clock [Hz] */
#define SCLK_MAX_Hz             133000000           /* Maximum System Clock [Hz] */
#define SCLK_MIN_Hz              83000000           /* Minimum System Clock required for DDR-SDRAM memory [Hz] */


/********************************
* PLL Lock Count Register Value *
* Reset = 0x0200                *
********************************/

#define PLL_LOCKCNT_VAL         0x0200


/****************************
* PLL Status Register Value *
* Reset = 0x00A2            *
****************************/

#define PLL_STAT_VAL            (\
                                0x0080              |   /* Bit #7 set by default */\
                               nROTWS               |   /* Rotary Wake-Up Status */\
                               nKPADWS              |   /* Keypad Wake-Up Status */\
                               nUSBWS               |   /* USB Wake-Up Status */\
                               nGPWS                |   /* General-Purpose Wake-Up Status */\
                               nCANWS               |   /* CAN Wake-Up Status */\
                               nRTCWS               |   /* RTC/Reset Wake-Up Status */\
                                PLL_LOCKED          |   /* PLL Locked Status */\
                               nACTIVE_PLLDISABLED  |   /* Active Mode With PLL Disabled */\
                                FULL_ON             |   /* Full-On Mode */\
                               nACTIVE_PLLENABLED   |   /* Active Mode With PLL Enabled */\
                                0)


/*******************************************
* Voltage Regulator Control Register Value *
* Reset = 0x40DB                           *
*******************************************/

#define VR_CTL_VAL              (\
                               nSCKELOW             |   /* Enable Drive CKE Low During Reset */\
                               nWAKE                |   /* Enable RTC/Reset Wakeup From Hibernate */\
                               nCANWE               |   /* Enable CAN Wakeup From Hibernate */\
                               nGPWE                |   /* General-Purpose Wake-Up Enable */\
                               nUSBWE               |   /* USB Wake-Up Enable */\
                               nKPADWE              |   /* Keypad Wake-Up Enable */\
                               nROTWE               |   /* Rotary Wake-Up Enable */\
                                VLEV_125            |   /* VLEV = 1.25 V (-5% - +10% Accuracy) */\
                                CLKBUFOE            |   /* CLKIN Buffer Output Enable */\
                                GAIN_20             |   /* GAIN = 20 */\
                                FREQ_1000           |   /* Switching Frequency Is 1 MHz */\
                                0)


/*****************************************************************************
 EBIU: Asynchronous Memory
*****************************************************************************/


/****************************************************
* Asynchronous Memory Global Control Register Value *
* Reset = 0x00F2                                    *
* --> Enabling all four Async Banks and Clock Out   *
****************************************************/

#define EBIU_AMGCTL_VAL         (\
                                AMCKEN              |   /* Enable CLKOUT */\
                                AMBEN               |   /* 4MB Asynchronous Memory */\
                                0)


/****************************************************
* Asynchronous Memory Bank Control 0 Register Value *
* Reset = 0xFFC2 FFC2                               *
* Here  = 0xFFC2 7B3E                               *
****************************************************/

#define EBIU_AMBCTL0_VAL        (\
                                B1WAT               |   /* B1 Write Access Time = 15 cycles */\
                                B1RAT               |   /* B1 Read Access Time = 15 cycles */\
                                B1HT                |   /* B1 Hold Time (nRead/Write to nAOE) = 3 cycles */\
                                B1RDYPOL            |   /* B1 RDY Active High */\
                                SET_B0WAT(7)        |   /* B2 Write Access Time = 7 cycles (minimum 50ns/SCLK) */\
                                SET_B0RAT(11)       |   /* B2 Read Access Time = 11 cycles (minimum (90ns/SCLK) */\
                                SET_B0HT(0)         |   /* B2 Hold Time (~Read/Write to ~AOE) = 0 cycles (latched before OE# goes high) */\
                                SET_B0ST(3)         |   /* B2 Setup Time (AOE to Read/Write) = 3 cycle (minimum 20ns/SCLK) */\
                                SET_B0TT(3)         |   /* B2 Transition Time (Read to Write) = 3 cycles (minimum 20ns between read and write) */\
                                B0RDYPOL            |   /* B0 RDY Active High */\
                               nB0RDYEN             |   /* B0 ARDY disable */\
                                0)


/****************************************************
* Asynchronous Memory Bank Control 1 Register Value *
* Reset = 0xFFC2 FFC2                               *
****************************************************/

#define EBIU_AMBCTL1_VAL        (\
                                B3WAT               |   /* B1 Write Access Time = 15 cycles */\
                                B3RAT               |   /* B1 Read Access Time = 15 cycles */\
                                B3HT                |   /* B1 Hold Time (nRead/Write to nAOE) = 3 cycles */\
                                B3RDYPOL            |   /* B1 RDY Active High */\
                                B2WAT               |   /* B1 Write Access Time = 15 cycles */\
                                B2RAT               |   /* B1 Read Access Time = 15 cycles */\
                                B2HT                |   /* B1 Hold Time (nRead/Write to nAOE) = 3 cycles */\
                                B2RDYPOL            |   /* B1 RDY Active High */\
                                0)


/*********************************************
* Memory Mode Control Register               *
* Reset = 0x0000 0000                        *
* Set the mode to async Mode:                *
* 0-async mode                               *
* 1-flash mode                               *
* 2-page mode                                *
* 3-burst mode                               *
*********************************************/

#define EBIU_MODE_VAL           (\
                                B0MODE_ASYNC        |   /* Bank 0 Access Mode - 00 - Asynchronous Mode */\
                                B1MODE_ASYNC        |   /* Bank 1 Access Mode - 00 - Asynchronous Mode */\
                                B2MODE_ASYNC        |   /* Bank 2 Access Mode - 00 - Asynchronous Mode */\
                                B3MODE_ASYNC        |   /* Bank 3 Access Mode - 00 - Asynchronous Mode */\
                                0)


/*********************************************
* Flash Memory Bank Control Register         *
* Reset = 0x0000 0006                        *
*********************************************/

#define EBIU_FCTL_VAL           (\
                                BCLK                |   /* Burst clock frequency */\
                                0)


/*****************************************************************************
 EBIU: DDR SDRAM Memory
*****************************************************************************/


/*********************************************
* Memory Control 0 Register                  *
* Reset = 0x098E 8411                        *
* ADSP-BF548-proc.xml = 0x218A 8411          *
* here: 0x220A 840D                          *
* Additional Requirement:                    *
* tRAS + tRP >= tRC                          *
*********************************************/

#define EBIU_DDRCTL0_VAL        (\
                                SET_tRC(8)          |   /* tRC (Active-to-Active) [29:26] - Number of clock cycles from an active command to next active command (Default: 0x2) */\
                                SET_tRAS(8)         |   /* tRAS (Minimum Active-to-Precharge time) [3:0] - Number of clock cycles from an ACTIVE command until a PRE-CHARGE command is issued. To obtain this value, one should divide the minimum RAS to pre-charge delay of SDRAM by clock cycle time (Default: 0x6) */\
                                SET_tRP(2)          |   /* tRP (Precharge-to-Active Command period)[3:0] - Number of clock cycles needed for DDR to recover from a precharge command and ready to accept next active command (Default: 0x3) */\
                                SET_tRFC(10)        |   /* tRFC[3:0] AUTO-REFRESH Command Period[3:0] - Number of clock cycles needed for DDR to recover from a refresh to be ready for next active command (tRFC/Clock Period) (Default: 0xA) */\
                                SET_tREFI(1023)     |   /* tREFI (Refresh Interval)[13:0] - Number of clock cycles from one refresh cycle to next refresh cycle. To obtain this value, divide the DDR refresh period (tREF) by total number of rows to be refreshed. Then divide the result by total time. (Default: 0x0411) */\
                                0)


/*********************************************
* Memory Control 1 Register                  *
* Reset = 0x1002 6223                        *
* ADSP-BF548-proc.xml = 0x2002 2222          *
* here = 0x2002 2222                         *
* Additional Requirement:                    *
* tRCD + 1 = tRRD                            *
* EBIU internal calculation:                 *
* tRRD = tRCD + 1                            *
*********************************************/

#define EBIU_DDRCTL1_VAL        (\
                                SET_tWTR(2)         |   /* tWTR (Write-to-Read Delay)[3:0] - The Write to read delay (last write data to the next read command) as specified by DDR Data sheet (Default: 0x0001) */\
                                DDR_DEVSIZE_512     |   /* DDR_DEVSIZE DDR Device Size[19:18] */\
                                DDR_DEVWIDTH_16     |   /* DDR_DRVWIDTH DDR Device Width[17:16] */\
                                CS0                 |   /* EXTBANKS External Banks[15:14] */\
                                DDR_DATAWIDTH       |   /* DDR_DATWIDTH Total DDR Data Width (16-bit Only) */\
                                SET_tWR(2)          |   /* tWR Write Recovery Time[9:8] */\
                                SET_tMRD(2)         |   /* tMRD Mode register set to active[7:4] */\
                                SET_tRCD(2)         |   /* tRCD ACTIVE-to-READ/WRITE delay[3:0] */\
                                0)


/*********************************************
* Memory Control 2 Register                  *
* Reset = 0x0000 0021                        *
* ADSP-BF548-proc.xml = 0x0000 0021          *
* here = 0x0000 0021                         *
*********************************************/

#define EBIU_DDRCTL2_VAL        (\
                               nREGE                |   /* Register mode enable */\
                               nDLLRESET            |   /* DLL Reset */\
                                CASLATENCY2         |   /* CAS Latency 2 */\
                                BURSTLENGTH1        |   /* Burst length 1 */\
                                0)


/************************************************
* DDR Queue Configuration Register              *
* Reset = 0x0000 0115                           *
* here = 0x0000 0115                            *
* Do not modify reserved bits in this register! *
************************************************/

#define EBIU_DDRQUE_VAL         (\
                                DEB0_PFLEN4         |   /* 01 - 4 Half-words (Default) */\
                                DEB1_PFLEN4         |   /* 01 - 4 Half-words (Default) */\
                                DEB2_PFLEN4         |   /* 01 - 4 Half-words (Default) */\
                                DEB_ARB_PRIORITY1   |   /* 001 : DEB1>DEB0>DEB2 (Default) */\
                               nDEB0_URGENT         |   /* DEB0 Urgent */\
                               nDEB1_URGENT         |   /* DEB1 Urgent */\
                               nDEB2_URGENT         |   /* DEB2 Urgent */\
                                0)


/**********************************************************
* BMODE_SPIMEM: Boot from SPI memory                      *
* This definition will modify the SPI_BAUD register value *
* and can in/decrease boot speed                          *
* Boot Rom default: 0x85                                  *
**********************************************************/

#define SPI_BAUD_VAL            0x85


/****************************************************************************
 EOF
*****************************************************************************/
