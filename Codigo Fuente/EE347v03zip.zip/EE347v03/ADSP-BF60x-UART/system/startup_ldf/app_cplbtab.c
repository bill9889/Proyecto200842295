/* MANAGED-BY-SOURCE-GENERATOR                                  */
/* CrossCore Embedded Studio                                    */
/* LDFGenPrinter version: 6.0.2.21                              */
/* LDFGen version: 6.0.2.21                                     */
/* VDSG version: 6.0.2.21                                       */

/*
** CPLB table definitions for coreA generated on Feb 22, 2012 at 10:20:59.
**
** Copyright (C) 2000-2012 Analog Devices Inc., All Rights Reserved.
**
** This file is generated automatically based upon the options selected
** in the Startup Code/LDF Configuration Editor. Changes to the CPLB
** configuration should be made by changing the appropriate options rather
** than editing this file.
**
** Additional user code can be inserted within the user-modifiable sections.
** Code place within these sections is preserved if this file is re-generated.
**
** Configuration:-
**     crt_doj:                                app_startup.doj
**     processor:                              ADSP-BF609
**     product_name:                           CrossCore Embedded Studio
**     si_revision:                            0.0
**     default_silicon_revision_from_archdef:  0.0
**     device_init:                            true
**     cplb_init:                              true
**     cplb_init_cplb_ctrl:                    57
**     cplb_init_cplb_src_file:                app_cplbtab.c
**     cplb_init_cplb_obj_file:                app_cplbtab.doj
**     cplb_init_cplb_src_alt:                 false
**     dcache_config:                          disable_dcache_and_enable_cplb
**     icache_config:                          enable_icache
**     using_cplusplus:                        true
**     use_profiling:                          false
**     mem_init:                               false
**     use_eh:                                 true
**     use_argv:                               false
**     use_pgo_hw:                             false
**     use_full_cpplib:                        false
**     running_from_internal_memory:           true
**     user_heap_src_file:                     app_heaptab.c
**     libraries_use_fileio_libs:              false
**     libraries_use_eh_enabled_libs:          false
**     libraries_use_fixed_point_io_libs:      false
**     libraries_heap_dbg_libs:                false
**     libraries_use_utility_rom:              false
**     detect_stackoverflow:                   false
**     system_heap:                            L1
**     system_heap_min_size:                   2
**     system_heap_size_units:                 kB
**     system_stack:                           L1
**     system_stack_min_size:                  2
**     system_stack_size_units:                kB
**     use_sdram:                              false
**     use_mt:                                 false
**     use_software_modules:                   false
**     use_multicores:                         2
**     use_multicores_use_core:                coreA
**     coreID:                                 0
**
*/

#include <sys/platform.h>
#include <cplbtab.h>

#ifdef _MISRA_RULES
#pragma diag(push)
#pragma diag(suppress:misra_rule_2_2)
#pragma diag(suppress:misra_rule_8_10)
#pragma diag(suppress:misra_rule_10_1_a)
#endif /* _MISRA_RULES */

#define CACHE_MEM_MODE (CPLB_DNOCACHE)

#define NOCACHE_READONLY (CPLB_READONLY_ACCESS)

#pragma section("cplb_data")
#pragma file_attr("DualCoreMem=CoreA")

cplb_entry dcplbs_table[] = {


   /*
   ** L1 data memory must be covered by a locked CPLB as it will contain
   ** the tables used in interrupt and exceptions handling support.
   ** For L1 Data A & B, set the write-through bit to avoid 1st write exceptions.
   */

   {0xFF800000, (ENUM_DCPLB_DATA_16KB | CPLB_DNOCACHE | BITM_DCPLB_DATA_LOCK | BITM_DCPLB_DATA_WT)}, 
   {0xFF804000, (ENUM_DCPLB_DATA_16KB | CPLB_DNOCACHE | BITM_DCPLB_DATA_LOCK | BITM_DCPLB_DATA_WT)}, 
   {0xFF900000, (ENUM_DCPLB_DATA_16KB | CPLB_DNOCACHE | BITM_DCPLB_DATA_LOCK | BITM_DCPLB_DATA_WT)}, 
   {0xFF904000, (ENUM_DCPLB_DATA_16KB | CPLB_DNOCACHE | BITM_DCPLB_DATA_LOCK | BITM_DCPLB_DATA_WT)}, 

   /*
   ** 256K L2 SRAM is split as follows:
   **
   **   ICC private area             - (0xC8080000-0xC808041F) 1056B
   **   Shareable, owned by 0        - (0xC8080420-0xC808820F) 32240B
   **   Shareable, owned by 1        - (0xC8088210-0xC808FFFF) 32240B
   **   Core 0                       - (0xC8090000-0xC80A7FFF) 96KB
   **   Core 1                       - (0xC80A8000-0xC80BFFFF) 96KB
   */

   {0xC8080000, (ENUM_DCPLB_DATA_64KB | CPLB_DNOCACHE)}, 
   {0xC8090000, (ENUM_DCPLB_DATA_64KB | CACHE_MEM_MODE)}, 
   {0xC80A0000, (ENUM_DCPLB_DATA_16KB | CACHE_MEM_MODE)}, 
   {0xC80A4000, (ENUM_DCPLB_DATA_16KB | CACHE_MEM_MODE)}, 
   {0xC80A8000, (ENUM_DCPLB_DATA_16KB | CPLB_READONLY_ACCESS)}, 
   {0xC80AC000, (ENUM_DCPLB_DATA_16KB | CPLB_READONLY_ACCESS)}, 
   {0xC80B0000, (ENUM_DCPLB_DATA_64KB | CPLB_READONLY_ACCESS)}, 

     /* Async Memory */
   {0xBC000000, (ENUM_DCPLB_DATA_64MB | CACHE_MEM_MODE)}, 
   {0xB8000000, (ENUM_DCPLB_DATA_64MB | CACHE_MEM_MODE)}, 
   {0xB4000000, (ENUM_DCPLB_DATA_64MB | CACHE_MEM_MODE)}, 
   {0xB0000000, (ENUM_DCPLB_DATA_64MB | CACHE_MEM_MODE)}, 

   /* SDRAM Memory */
   {0x00000000, (ENUM_DCPLB_DATA_64MB | CACHE_MEM_MODE)},
   {0x04000000, (ENUM_DCPLB_DATA_64MB | CACHE_MEM_MODE)},
   {0x08000000, (ENUM_DCPLB_DATA_64MB | CACHE_MEM_MODE)},
   {0x0C000000, (ENUM_DCPLB_DATA_64MB | CACHE_MEM_MODE)},

     /* L2 ROM */
   {0xC8000000, (ENUM_DCPLB_DATA_16KB | CACHE_MEM_MODE)}, 
   {0xC8004000, (ENUM_DCPLB_DATA_16KB | CACHE_MEM_MODE)}, 

   /* end of section - termination */
   {0xffffffff, 0}, 
}; /* dcplbs_table */

#pragma section("cplb_data")
#pragma file_attr("DualCoreMem=CoreA")

cplb_entry icplbs_table[] = {


     /* L1 Code SRAM */
   {0xFFA00000, (ENUM_ICPLB_DATA_64KB | CPLB_I_PAGE_MGMT)}, 

     /* L1 Code cache */
   {0xFFA10000, (ENUM_ICPLB_DATA_16KB | CPLB_I_PAGE_MGMT)}, 

     /* L2 ROM */
   {0xC8000000, (ENUM_ICPLB_DATA_16KB | CPLB_I_PAGE_MGMT)}, 
   {0xC8004000, (ENUM_ICPLB_DATA_16KB | CPLB_I_PAGE_MGMT)}, 

     /* L2 SRAM */
   {0xC8080000, (ENUM_ICPLB_DATA_64KB | CPLB_IDOCACHE)}, 
   {0xC8090000, (ENUM_ICPLB_DATA_64KB | CPLB_IDOCACHE)}, 
   {0xC80A0000, (ENUM_ICPLB_DATA_64KB | CPLB_IDOCACHE)}, 
   {0xC80B0000, (ENUM_ICPLB_DATA_64KB | CPLB_IDOCACHE)}, 

     /* Async Memory */
   {0xBC000000, (ENUM_ICPLB_DATA_64MB | CPLB_IDOCACHE)}, 
   {0xB8000000, (ENUM_ICPLB_DATA_64MB | CPLB_IDOCACHE)}, 
   {0xB4000000, (ENUM_ICPLB_DATA_64MB | CPLB_IDOCACHE)}, 
   {0xB0000000, (ENUM_ICPLB_DATA_64MB | CPLB_IDOCACHE)},

   /* SDRAM Memory */
   {0x00000000, (ENUM_ICPLB_DATA_64MB | CPLB_IDOCACHE)},
   {0x04000000, (ENUM_ICPLB_DATA_64MB | CPLB_IDOCACHE)},
   {0x08000000, (ENUM_ICPLB_DATA_64MB | CPLB_IDOCACHE)},
   {0x0C000000, (ENUM_ICPLB_DATA_64MB | CPLB_IDOCACHE)},

   /* end of section - termination */
   {0xffffffff, 0}, 
}; /* icplbs_table */


#ifdef _MISRA_RULES
#pragma diag(pop)
#endif /* _MISRA_RULES */

