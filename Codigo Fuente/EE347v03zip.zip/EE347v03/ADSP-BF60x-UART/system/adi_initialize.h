/*
** ADI initialize header file.
**
** Copyright (C) 2000-2011 Analog Devices Inc., All Rights Reserved.
**
** This file is generated automatically
*/

#ifndef __ADI_COMPONENT_INIT_H__
#define __ADI_COMPONENT_INIT_H__

#ifdef __cplusplus
extern "C" {
#endif

/* Declare "adi_initComponents()" */
void adi_initComponents(void);

#ifdef __cplusplus
}
#endif

#endif /* __ADI_COMPONENT_INIT_H__ */
