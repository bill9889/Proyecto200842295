/*
** ADI initialize C file.
**
** Copyright (C) 2000-2011 Analog Devices Inc., All Rights Reserved.
**
** This file is generated automatically
*/

#include "adi_initialize.h"

void adi_initComponents(void)
{
}
