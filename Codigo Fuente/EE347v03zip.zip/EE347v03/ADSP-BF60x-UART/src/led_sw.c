#include <blackfin.h>
#include <ccblkfn.h>

#include <stdio.h>
#include <stdlib.h>
#include <stdarg.h>
#include <string.h>

#include <sys/exception.h>

#include "init_platform.h"

#include "led_sw.h"

#include "BfDebugger.h"


/*******************************************************************************
 *
 *  Internal Constants Area
 *
 ******************************************************************************/

#define PE0         BITM_PORT_DATA_PX0
#define PE1         BITM_PORT_DATA_PX1
#define PE3         BITM_PORT_DATA_PX3
#define PE4         BITM_PORT_DATA_PX4
#define PE14        BITM_PORT_DATA_PX14
#define PB11        BITM_PORT_DATA_PX11

#define PUSHB1      PE0
#define PUSHB2      PE1
#define PUSHB_ALL   (PUSHB1|PUSHB2)

#define LED1        PB11
#define LED2        PE14
#define LED3        PE3
#define LED4        PE4
#define LED_ALL     (LED1|LED2|LED3|LED4)

/*******************************************************************************
 *
 *  Internal Types Area
 *
 ******************************************************************************/

/*******************************************************************************
 *
 *  Exported Data Area
 *
 ******************************************************************************/

 /*******************************************************************************
 *
 *  Internal Data Area
 *
 ******************************************************************************/

bool Pb1Cnt = 0;
bool Pb2Cnt = 0;

/*******************************************************************************
 *
 *  External Data Area
 *
 ******************************************************************************/
 
/*******************************************************************************
 *
 *  Internal Macros Area
 *
 ******************************************************************************/

/*******************************************************************************
 *
 *  Internal Function Prototypes Area
 *
 ******************************************************************************/

short PintInit(unsigned char PintNum);
short PintInterruptsSetup(unsigned char PintNum);

void Pint0InterruptsHandler(void);
void Pint1InterruptsHandler(void);
void Pint2InterruptsHandler(void);
void Pint3InterruptsHandler(void);
void Pint4InterruptsHandler(void);
void Pint5InterruptsHandler(void);
short PintInterruptsHandler(unsigned char PintNum);

/*******************************************************************************
 *
 *  Internal Functions Area
 *
 ******************************************************************************/

/*******************************************************************************
 *
 *  Exported Functions Area
 *
 ******************************************************************************/

/***************************************
 *
 * Function Name : LedInit
 * Description   : Set initial LED value
 *
 * Parameters    : none
 * Returns       : none
 * Globals       : none
 */
short LedInit(void)
{
    *pREG_PORTE_FER_CLR   = (LED2|LED3|LED4);
    *pREG_PORTB_FER_CLR   = LED1;
    *pREG_PORTE_INEN_CLR  = (LED2|LED3|LED4);
    *pREG_PORTB_INEN_CLR  = LED1;
    *pREG_PORTE_DIR_SET   = (LED2|LED3|LED4);
    *pREG_PORTB_DIR_SET   = (LED1);
    *pREG_PORTE_DATA_CLR  = (LED2|LED3|LED4);
    *pREG_PORTB_DATA_CLR  = (LED1);
    ssync();

    return 0;
}


/***************************************
 *
 * Function Name : LedOn
 * Description   : Turn on single LED
 *
 * Parameters    : LedNum  [1..4] LED number
 * Returns       : NULL. If LedOn is unsuccessful, a negative value is returned.
 * Globals       : none
 */
short LedOn(unsigned char LedNum)
{
	switch (LedNum) {
	    case 1: *pREG_PORTB_DATA_SET = LED1; break;
	    case 2: *pREG_PORTE_DATA_SET = LED2; break;
	    case 3: *pREG_PORTE_DATA_SET = LED3; break;
	    case 4: *pREG_PORTE_DATA_SET = LED4; break;
	    default: return -1;
	}

    ssync();

    return 0;
}


/***************************************
 *
 * Function Name : LedOff
 * Description   : Turn off a single LED
 *
 * Parameters    : LedNum  [1..4] LED number
 * Returns       : NULL. If LedOff is unsuccessful, a negative value is returned.
 * Globals       : none
 */
short LedOff(unsigned char LedNum)
{
	switch (LedNum) {
	    case 1: *pREG_PORTB_DATA_CLR = LED1; break;
	    case 2: *pREG_PORTE_DATA_CLR = LED2; break;
	    case 3: *pREG_PORTE_DATA_CLR = LED3; break;
	    case 4: *pREG_PORTE_DATA_CLR = LED4; break;
	    default: return -1;
	}

    ssync();

    return 0;
}


/***************************************
 *
 * Function Name : SwitchInit
 * Description   : Push Button 1-2 initialization
 *
 * Parameters    : none
 * Returns       : NULL. If SwitchInit is unsuccessful, a negative value is returned.
 * Globals       : none
 */
short SwitchInit(void)
{
    *pREG_PORTE_FER     &= ~PUSHB_ALL;
    *pREG_PORTE_MUX     &= ~PUSHB_ALL;
    *pREG_PORTE_DIR_CLR  =  PUSHB_ALL;
    *pREG_PORTE_INEN    |=  PUSHB_ALL;

    PintInterruptsSetup(3);
    PintInit(3);

    return 0;
}


/***************************************
 *
 * Function Name : PintInit
 * Description   : Setup PINT Interrupts
 *
 * Parameters    : Pint Number
 * Returns       : NULL. If PintInit is unsuccessful, a negative value is returned.
 * Globals       : none
 */
short PintInit(unsigned char PintNum)
{
    switch (PintNum) {
        case 0: break;
        case 1: break;
        case 2: break;
        case 3: break;
        case 4: break;
        case 5: break;
        default: printf("%s(): PINT%d is not available.\n",__func__,PintNum); return -1;
    }

    volatile unsigned long *pPintMaskSet = (volatile unsigned long*) (REG_PINT0_MSK_SET  + PintNum * 0x100);
    volatile unsigned long *pPintEdgeSet = (volatile unsigned long*) (REG_PINT0_EDGE_SET + PintNum * 0x100);
    volatile unsigned long *pPintEdgeClr = (volatile unsigned long*) (REG_PINT0_EDGE_CLR + PintNum * 0x100);
    volatile unsigned long *pPintInvSet  = (volatile unsigned long*) (REG_PINT0_INV_SET  + PintNum * 0x100);
    volatile unsigned long *pPintInvClr  = (volatile unsigned long*) (REG_PINT0_INV_CLR  + PintNum * 0x100);
    volatile unsigned long *pPintAssign  = (volatile unsigned long*) (REG_PINT0_ASSIGN   + PintNum * 0x100);
    volatile unsigned long *pPintLatch   = (volatile unsigned long*) (REG_PINT0_LATCH    + PintNum * 0x100);

    *pPintAssign   = BITM_PINT_ASSIGN_B0MAP;
    *pPintEdgeSet  = PUSHB_ALL;
//    *pPintEdgeClr  = PUSHB_ALL;
//    *pPintInvSet   = PUSHB_ALL;
    *pPintInvClr   = PUSHB_ALL;
    *pPintLatch    = PUSHB_ALL;
    *pPintMaskSet  = PUSHB_ALL;

    return 0;
}


/***************************************
 *
 * Function Name : PintInterruptsSetup
 * Description   : Setup SIC and IMASK
 *
 * Parameters    : none
 * Returns       : none
 * Globals       : none
 */
short PintInterruptsSetup(unsigned char PintNum)
{
    switch (PintNum) {
        case 0: sec_install_irq_handler(21,21,(unsigned long)Pint0InterruptsHandler); break;
        case 1: sec_install_irq_handler(22,22,(unsigned long)Pint1InterruptsHandler); break;
        case 2: sec_install_irq_handler(23,23,(unsigned long)Pint2InterruptsHandler); break;
        case 3: sec_install_irq_handler(24,24,(unsigned long)Pint3InterruptsHandler); break;
        case 4: sec_install_irq_handler(25,25,(unsigned long)Pint4InterruptsHandler); break;
        case 5: sec_install_irq_handler(26,26,(unsigned long)Pint5InterruptsHandler); break;
        default: printf("%s(): PINT%d is not available.\n",__func__,PintNum); return -1;
    }

    return 0;
}


/***************************************
 *
 * Function Name : Pint0InterruptsHandler
 * Description   : PINT0 Interrupts Handler
 *
 * Parameters    : none
 * Returns       : none
 * Globals       : none
 */
void Pint0InterruptsHandler(void)
{
	PintInterruptsHandler(0);
}


/***************************************
 *
 * Function Name : Pint1InterruptsHandlerStatus
 * Description   : PINT1 Interrupts Handler
 *
 * Parameters    : none
 * Returns       : none
 * Globals       : none
 */
void Pint1InterruptsHandler(void)
{
	PintInterruptsHandler(1);
}


/***************************************
 *
 * Function Name : Pint2InterruptsHandler
 * Description   : PINT2 Interrupts Handler
 *
 * Parameters    : none
 * Returns       : none
 * Globals       : none
 */
void Pint2InterruptsHandler(void)
{
	PintInterruptsHandler(2);
}


/***************************************
 *
 * Function Name : Pint3InterruptsHandlerStatus
 * Description   : PINT3 Interrupts Handler
 *
 * Parameters    : none
 * Returns       : none
 * Globals       : none
 */
void Pint3InterruptsHandler(void)
{
	PintInterruptsHandler(3);
}


/***************************************
 *
 * Function Name : Pint3InterruptsHandlerStatus
 * Description   : PINT3 Interrupts Handler
 *
 * Parameters    : none
 * Returns       : none
 * Globals       : none
 */
void Pint4InterruptsHandler(void)
{
	PintInterruptsHandler(4);
}


/***************************************
 *
 * Function Name : Pint3InterruptsHandlerStatus
 * Description   : PINT3 Interrupts Handler
 *
 * Parameters    : none
 * Returns       : none
 * Globals       : none
 */
void Pint5InterruptsHandler(void)
{
	PintInterruptsHandler(5);
}


/***************************************
 *
 * Function Name : PintInterruptsHandler
 * Description   : Handler for PINT Interrupts, Push Buttons
 *
 * Parameters    : PintNum
 * Returns       : none
 * Globals       : none
 */
short PintInterruptsHandler(unsigned char PintNum)
{
    switch (PintNum) {
        case 0: break;
        case 1: break;
        case 2: break;
        case 3: break;
        case 4: break;
        case 5: break;
        default: printf("%s(): PINT%d is not available.\n",__func__,PintNum); return -1;
    }

    volatile unsigned long *pPintPinstate = (volatile unsigned long*) (REG_PINT0_PINSTATE + PintNum * 0x100);
    volatile unsigned long *pPintRequest  = (volatile unsigned long*) (REG_PINT0_REQ      + PintNum * 0x100);
    volatile unsigned long *pPintLatch    = (volatile unsigned long*) (REG_PINT0_LATCH    + PintNum * 0x100);

    static unsigned char PulseLength = 0;
    PulseLength = circindex(PulseLength, 16, 127);

    if (*pPintLatch & PUSHB1) {
        while(*pPintPinstate & PUSHB1) { /* wait */ }
        *pPintLatch   = PUSHB1;
        *pPintRequest = PUSHB1;
        if (Pb1Cnt) { LedOff(1); Pb1Cnt = 0; } else { LedOn(1); Pb1Cnt = 1; }
        UartInsertPulse(0,PulseLength,0);
    }
    if (*pPintLatch & PUSHB2) {
        while(*pPintPinstate & PUSHB2) { /* wait */ }
        *pPintLatch   = PUSHB2;
        *pPintRequest = PUSHB2;
        if (Pb2Cnt) { LedOff(2); Pb2Cnt = 0; } else { LedOn(2); Pb2Cnt = 1; }
        UartInsertPulse(0,PulseLength,0);
    }

    return 0;
}


/******************************** End of File *********************************/

