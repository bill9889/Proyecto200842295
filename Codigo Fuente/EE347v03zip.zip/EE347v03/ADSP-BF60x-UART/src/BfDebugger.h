/*****************************************************************************
**                                                                          **
**  Name:   BfDebugger                                                      **
**                                                                          **
******************************************************************************

(C) Copyright 2009 - Analog Devices, Inc.  All rights reserved.

File Name:      BfDebugger.h

Date Modified:  05/05/2010

Processor:      Blackfin

Software:       CrossCore Embedded Studio

Purpose:        This header files includes the target specific UART.h files,
                depending the predefined preprocessor processor target macros. These files
                contain target individual settings.

                This header files additionally provides some easy to use
                preprocessor macros to control the level of verbosity (__VERBOSITY__)
                and the output color (DEBUG=default (grey), INFO=green, WARNING=yellow, ERROR=red, MSG=white)
                in the case of UART output.
                CONTROL does not insert any addition control sequences like new line or carriage return.
                Syntax: e.g. DEBUG(LoV, arg...);

                When the macros are in use, the application can switch between
                printf, fprintf, uprintf, and udprintf based outputs


An ANSI code is sent by the world by sending an escape character (ESC, ASCII value 27)
followed by the appropriate code sequence:

Code:           Meaning:
\a              Alert
\b              Backspace
\f              Form Feed
\n              Newline
\r              Carriage Return
\t              Horizontal Tab
\v              Vertical Tab

[0m             reset; clears all colors and styles (to white on black)
[1m             bold on (see below)
[3m             italics on
[4m             underline on
[7m             inverse on; reverses foreground & background colors
[9m             strikethrough on
[22m            bold off (see below)
[23m            italics off
[24m            underline off
[27m            inverse off
[29m            strikethrough off
[30m            set foreground color to black
[31m            set foreground color to red
[32m            set foreground color to green
[33m            set foreground color to yellow
[34m            set foreground color to blue
[35m            set foreground color to magenta (purple)
[36m            set foreground color to cyan
[37m            set foreground color to white
[39m            set foreground color to default (white)
[40m            set background color to black
[41m            set background color to red
[42m            set background color to green
[43m            set background color to yellow
[44m            set background color to blue
[45m            set background color to magenta (purple)
[46m            set background color to cyan
[47m            set background color to white
[49m            set background color to default (black)

******************************************************************************/

#ifndef __DEBUG_H__
#define __DEBUG_H__

/*******************************************************************************
*
*  Exported Constants/Definitions: User Area
*
*******************************************************************************/

//#define __UART_IO_DEVICE__          1   // Extend I/O support to a new device: Uart
//#define __PRE_REGISTERING_DEVICE__  1   // Pre-Register device: This replaces the PrimIO device for stdin, stdout & stderr


// multiple definitions at the same time will result in activation of only __DEBUG_UART__ without warning
//#define __DEBUG_UART__              1   // prints are directed to the UART interface, core mode
#define __DEBUG_UART_DMA__          1   // prints are directed to the UART interface, DMA mode
//#define __DEBUG_FILE__              1   // prints are directed to file DEBUG_FILE_NAME
//#define __DEBUG_VDSP__              1   // prints are directed to the VDSP console window (MUCH SLOWER!!!)


// level of verbosity
#define __VERBOSITY__               2

/*******************************************************************************
*
*  Exported Constants/Definitions: Do-Not-Modify-Area
*
*******************************************************************************/

// some syntax checking first
#if ( (__DEBUG_UART_DMA__ == 0) && (__DEBUG_UART__ == 0) && (__DEBUG_FILE__ == 0) && (__DEBUG_VDSP__ == 0) && (__DEBUG_LCD__ == 0) )
    #warning "__DEBUG_UART__" is enabled automatically
    #define __DEBUG_UART_DMA__  1
#endif

#if ( (__PRE_REGISTERING_DEVICE__ == 1) && (__UART_IO_DEVICE__ == 0) )
    #warning "__UART_IO_DEVICE__" is enabled automatically
    #undef __UART_IO_DEVICE__
    #define __UART_IO_DEVICE__  1
#endif

#if ( (__UART_IO_DEVICE__ == 1) && (__DEBUG_UART_DMA__ == 0) && (__DEBUG_UART__ == 0) )
    #warning "__DEBUG_UART_DMA__" is enabled automatically,
    #warning "__DEBUG_VDSP__" and/or "__DEBUG_FILE__" have been disabled
    #undef __DEBUG_FILE__
    #undef __DEBUG_VDSP__
    #undef __DEBUG_UART__
    #define __DEBUG_UART_DMA__  1
#endif

#define STRINGSIZE 512

#if ( (__DEBUG_UART_DMA__ == 1) || (__DEBUG_UART__ == 1) )
    #define _PROMPT_        "bf\\>"
    #define _RESETSCREEN_   "\f\e[0m"
    #define _CLEARSCREEN_   "\e[2J"
    #define _ERASELINE_     "\e[K"
//    #define _NEWLINE_       "\n\r" // carriage return is inserted automatic
    #define _NEWLINE_       "\n"
    #define _CARRIAGE_      "\r"
    #define _VTAB_          "\v"
    #define _HTAB_          "\t"
    #define _CURSORUP_      "\e[A"
    #define _CURSORDN_      "\e[B"
    #define _CURSORFW_      "\e[C"
    #define _CURSORBW_      "\e[D"
    #define _CURSORUPX_     "\e[%dA" // requires the number of lines as the 1st parameter
    #define _CURSORDNX_     "\e[%dB" // requires the number of lines as the 1st parameter
    #define _CURSORFWX_     "\e[%dC" // requires the number of lines as the 1st parameter
    #define _CURSORBWX_     "\e[%dD" // requires the number of lines as the 1st parameter
    #define _CURSORPOSXY_   "\e[%d;%dH"
    #define _CURSORPOSSAVE_ "\e[s"
    #define _CURSORPOSREST_ "\e[u"
    #define _INVERSEON_     "\e[7m"
    #define _INVERSEOFF_    "\e[27m"
    #define _NORMALTEXT_    "\e[0m"
    #define _BOLDTEXT_      "\e[1m"
    #define _ITALICTEXT_    "\e[3m"
    #define _BLINKTEXT_     "\e[5m"
    #define _BLACKTEXT_     "\e[30m"
    #define _REDTEXT_       "\e[31m"
    #define _GREENTEXT_     "\e[32m"
    #define _YELLOWTEXT_    "\e[33m"
    #define _BLUETEXT_      "\e[34m"
    #define _MAGENTATEXT_   "\e[35m"
    #define _CYANTEXT_      "\e[36m"
    #define _WHITETEXT_     "\e[37m"
    #define _TEST_          "\e[=3h"
#else
    #define _PROMPT_        ""
    #define _RESETSCREEN_   "\n"
    #define _CLEARSCREEN_   "\n"
    #define _ERASELINE_     ""
    #define _NEWLINE_       "\n"
    #define _CARRIAGE_      "\r"
    #define _VTAB_          "\n"
    #define _HTAB_          "\h"
    #define _CURSORUP_      ""
    #define _CURSORDN_      ""
    #define _CURSORFW_      ""
    #define _CURSORBW_      ""
    #define _CURSORUPX_     ""
    #define _CURSORDNX_     ""
    #define _CURSORFWX_     ""
    #define _CURSORBWX_     ""
    #define _CURSORPOSXY_   ""
    #define _CURSORPOSSAVE_ ""
    #define _CURSORPOSREST_ ""
    #define _INVERSEON_     ""
    #define _INVERSEOFF_    ""
    #define _NORMALTEXT_    ""
    #define _BOLDTEXT_      ""
    #define _ITALICTEXT_    ""
    #define _BLINKTEXT_     ""
    #define _BLACKTEXT_     ""
    #define _REDTEXT_       ""
    #define _GREENTEXT_     ""
    #define _YELLOWTEXT_    ""
    #define _BLUETEXT_      ""
    #define _MAGENTATEXT_   ""
    #define _CYANTEXT_      ""
    #define _WHITETEXT_     ""
    #define _TEST_          ""
#endif
#define _NL_    _NEWLINE_
#define _CR_    _CARRIAGE_
#define _EL_    _ERASELINE_
#define _CS_    _CLEARSCREEN_

static char crsuw[] = { '\e', '[', 'A' }; // Cursor Up
static char crsdw[] = { '\e', '[', 'B' }; // Cursor Down
static char crsfw[] = { '\e', '[', 'C' }; // Cursor Forward
static char crsbw[] = { '\e', '[', 'D' }; // Cursor Backward

static char crstb[] = { '\e', '[', '4', 'C' }; // Tab: Cursor Forward by 4


/*******************************************************************************
*
*  Include File Area
*
*******************************************************************************/

#include <stdio.h>
#include <device.h>
#include <device_int.h>

#if ( (__DEBUG_UART_DMA__ == 1) || (__DEBUG_UART__ == 1) )
    #if (__ADSPBF50x__ == 1)
        #include "ADSP-BF50x-UART.h"
    #elif (__ADSPBF51x__ == 1)
        #include "ADSP-BF51x-UART.h"
    #elif (__ADSPBF52x__ == 1)
        #include "ADSP-BF52x-UART.h"
    #elif (__ADSPBF533_FAMILY__ == 1)
        #include "ADSP-BF532-UART.h"
    #elif (__ADSPBF537_FAMILY__ == 1)
        #include "ADSP-BF534-UART.h"
    #elif (__ADSPBF538_FAMILY__ == 1)
        #include "ADSP-BF538-UART.h"
    #elif (__ADSPBF54x__ == 1)
        #include "ADSP-BF54x-UART.h"
    #elif (__ADSPBF561__ == 1)
        #include "ADSP-BF561-UART.h"
    #elif (__ADSPBF59x__ == 1)
        #include "ADSP-BF59x-UART.h"
    #elif (__ADSPBF60x__ == 1)
        #include "ADSP-BF60x-UART.h"
    #else
        #error target not supported
    #endif
#endif // (__DEBUG_UART_DMA__ == 1) || (__DEBUG_DMA__ == 1)


/*******************************************************************************
*
*  Exported Types Area
*
*******************************************************************************/

/*******************************************************************************
*
*  Exported Macros Area
*
*******************************************************************************/

/* Available macros:
DEBUG_OPEN()
DEBUG_CLOSE()
CONTROL(<level of verbosity>, args...)
DEBUG(<level of verbosity>, args...)
MSG(<level of verbosity>, args...)
INFO(<level of verbosity>, args...)
WARNING(<level of verbosity>, args...)
ERROR(<level of verbosity>, args...)
*/


#if (__DEBUG_UART__ == 1)

#if (AUTOBAUD == 0)
#define DEBUG_OPEN()    UartInitTerminal(USE_UART_NR,USE_UART_BITRATE)
#else
#define DEBUG_OPEN()    UartInitAutobaud(USE_UART_NR)
#endif
#define DEBUG_CLOSE()   UartClockDisable(USE_UART_NR)


#if (__VERBOSITY__ > 0)
#define CONTROL(n, args...)\
    do {\
        if (__VERBOSITY__ >= n) { uprintf(USE_UART_NR, args); }\
    } while (0)
#else
#define CONTROL(n, args...) do { } while(0)
#endif


#if (__VERBOSITY__ > 0)
#define DEBUG(n, args...)\
    do {\
        if (__VERBOSITY__ >= n) { uprintf(USE_UART_NR,_NORMALTEXT_ _CR_ args); }\
    } while (0)
#else
#define DEBUG(n, args...) do { } while(0)
#endif


#if (__VERBOSITY__ > 0)
#define INFO(n, args...)\
    do {\
        if (__VERBOSITY__ >= n) {\
        uprintf(USE_UART_NR,_BOLDTEXT_ _GREENTEXT_ _CR_ args);\
        }\
    } while (0)
#else
#define INFO(n, args...) do { } while(0)
#endif


#if (__VERBOSITY__ > 0)
#define INFO2(n, args...)\
    do {\
        if (__VERBOSITY__ >= n) {\
        uprintf(USE_UART_NR,_BOLDTEXT_ _GREENTEXT_ _CR_ args);\
        }\
    } while (0)
#else
#define INFO2(n, args...) do { } while(0)
#endif


#if (__VERBOSITY__ > 0)
#define WARNING(n, args...)\
    do {\
        if (__VERBOSITY__ >= n) {\
        uprintf(USE_UART_NR,_BOLDTEXT_ _YELLOWTEXT_ _CR_ args);\
        }\
    } while (0)
#else
#define WARNING(n, args...) do { } while(0)
#endif


#if (__VERBOSITY__ > 0)
#define ERROR(n, args...)\
    do {\
        if (__VERBOSITY__ >= n) {\
        uprintf(USE_UART_NR,_BOLDTEXT_ _REDTEXT_ _CR_ args);\
        }\
    } while (0)
#else
#define ERROR(n, args...) do { } while(0)
#endif


#if (__VERBOSITY__ > 0)
#define MSG(n, args...)\
    do {\
        if (__VERBOSITY__ >= n) {\
        uprintf(USE_UART_NR,_BOLDTEXT_ _WHITETEXT_ _CR_ args);\
        }\
    } while (0)
#else
#define MSG(n, args...) do { } while(0)
#endif


#endif // (__DEBUG_UART__ == 1)


#if (__DEBUG_UART_DMA__ == 1)

#if (AUTOBAUD == 0)
#define DEBUG_OPEN()    UartInitTerminal(USE_UART_NR,USE_UART_BITRATE);\
                        UartDmaInit(USE_UART_NR,0)
#else
#define DEBUG_OPEN()    UartInitAutobaud(USE_UART_NR);\
                        UartDmaInit(USE_UART_NR,0)
#endif
#define DEBUG_CLOSE()   UartDmaDisable(USE_UART_NR,0);\
                        UartClockDisable(USE_UART_NR)

#if (__VERBOSITY__ > 0)
#define CONTROL(n, args...)\
    do {\
        if (__VERBOSITY__ >= n) { udprintf(USE_UART_NR, args); }\
    } while (0)
#else
#define CONTROL(n, args...) do { } while(0)
#endif


#if (__VERBOSITY__ > 0)
#define DEBUG(n, args...)\
    do {\
        if (__VERBOSITY__ >= n) { udprintf(USE_UART_NR,_NORMALTEXT_ _CR_ args); }\
    } while (0)
#else
#define DEBUG(n, args...) do { } while(0)
#endif


#if (__VERBOSITY__ > 0)
#define INFO(n, args...)\
    do {\
        if (__VERBOSITY__ >= n) {\
        udprintf(USE_UART_NR,_BOLDTEXT_ _GREENTEXT_ _CR_ args);\
        }\
    } while (0)
#else
#define INFO(n, args...) do { } while(0)
#endif


#if (__VERBOSITY__ > 0)
#define INFO2(n, args...)\
    do {\
        if (__VERBOSITY__ >= n) {\
        udprintf(USE_UART_NR,_BOLDTEXT_ _BLUETEXT_ _CR_ args);\
        }\
    } while (0)
#else
#define INFO2(n, args...) do { } while(0)
#endif


#if (__VERBOSITY__ > 0)
#define WARNING(n, args...)\
    do {\
        if (__VERBOSITY__ >= n) {\
        udprintf(USE_UART_NR,_BOLDTEXT_ _YELLOWTEXT_ _CR_ args);\
        }\
    } while (0)
#else
#define WARNING(n, args...) do { } while(0)
#endif


#if (__VERBOSITY__ > 0)
#define ERROR(n, args...)\
    do {\
        if (__VERBOSITY__ >= n) {\
        udprintf(USE_UART_NR,_BOLDTEXT_ _REDTEXT_ _CR_ args);\
        }\
    } while (0)
#else
#define ERROR(n, args...) do { } while(0)
#endif


#if (__VERBOSITY__ > 0)
#define MSG(n, args...)\
    do {\
        if (__VERBOSITY__ >= n) {\
        udprintf(USE_UART_NR,_BOLDTEXT_ _WHITETEXT_ _CR_ args);\
        }\
    } while (0)
#else
#define MSG(n, args...) do { } while(0)
#endif


#endif // (__DEBUG_UART_DMA__ == 1)


#if ( (__DEBUG_VDSP__ == 1) || (__DEBUG_FILE__ == 1) )


#if (__DEBUG_FILE__ == 1)
    #define DEBUG_FILE_NAME     "debug.txt"
    #define DEBUG_STREAM        pDebugFile
// either: use fprintf directly
    #define DEBUG_PRINT         fprintf
    #define DEBUG_PRINT_OUTPUT  DEBUG_STREAM
// or: use function fileprintf, much slower
//        #define DEBUG_PRINT         fileprintf
//        #define DEBUG_PRINT_OUTPUT  DEBUG_FILE_NAME

    #define DEBUG_OPEN()        DEBUG_STREAM = fopen(DEBUG_FILE_NAME,"w");\
                                if (DEBUG_STREAM == NULL)\
                                {\
                                    fclose(DEBUG_STREAM);\
                                    return -1;\
                                }
    #define DEBUG_CLOSE()      fclose(DEBUG_STREAM)
#endif // (__DEBUG_FILE__


#if (__DEBUG_VDSP__ == 1)
    #define DEBUG_STREAM        stdout
    #define DEBUG_PRINT         fprintf
    #define DEBUG_PRINT_OUTPUT  DEBUG_STREAM
    #define DEBUG_OPEN()
    #define DEBUG_CLOSE()
#endif // (__DEBUG_VDSP__ == 1)


#if (__VERBOSITY__ > 0)
#define CONTROL(n, args...)\
    do {\
        if (__VERBOSITY__ >= n) { DEBUG_PRINT(DEBUG_PRINT_OUTPUT,args); }\
    } while (0)
#else
#define CONTROL(n, args...) do { } while(0)
#endif


#if (__VERBOSITY__ > 0)
#define DEBUG(n, args...)\
    do {\
        if (__VERBOSITY__ >= n) { DEBUG_PRINT(DEBUG_PRINT_OUTPUT,"  [DEBUG]"args); }\
    } while (0)
#else
#define DEBUG(n, args...) do { } while(0)
#endif


#if (__VERBOSITY__ > 0)
#define INFO(n, args...)\
    do {\
        if (__VERBOSITY__ >= n) { DEBUG_PRINT(DEBUG_PRINT_OUTPUT,"   [INFO]"args); }\
    } while (0)
#else
#define INFO(n, args...) do { } while(0)
#endif


#if (__VERBOSITY__ > 0)
#define INFO2(n, args...)\
    do {\
        if (__VERBOSITY__ >= n) { DEBUG_PRINT(DEBUG_PRINT_OUTPUT,"  [INFO2]"args); }\
    } while (0)
#else
#define INFO2(n, args...) do { } while(0)
#endif


#if (__VERBOSITY__ > 0)
#define WARNING(n, args...)\
    do {\
        if (__VERBOSITY__ >= n) { DEBUG_PRINT(DEBUG_PRINT_OUTPUT,"[WARNING]"args); }\
    } while (0)
#else
#define WARNING(n, args...) do { } while(0)
#endif


#if (__VERBOSITY__ > 0)
#define ERROR(n, args...)\
    do {\
        if (__VERBOSITY__ >= n) { DEBUG_PRINT(DEBUG_PRINT_OUTPUT,"  [ERROR]"args); }\
    } while (0)
#else
#define ERROR(n, args...) do { } while(0)
#endif


#if (__VERBOSITY__ > 0)
#define MSG(n, args...)\
    do {\
        if (__VERBOSITY__ >= n) { DEBUG_PRINT(DEBUG_PRINT_OUTPUT,"    [MSG]"args); }\
    } while (0)
#else
#define MSG(n, args...) do { } while(0)
#endif


#endif // (__DEBUG_VDSP__ == 1) || (__DEBUG_FILE__ == 1)


/*******************************************************************************
*
*  Exported Data Area
*
*******************************************************************************/

extern char strbuf[STRINGSIZE];

#if (__DEBUG_FILE__ == 1)
    extern FILE *DEBUG_STREAM;      // needs to be defined globally and opened -> main.c
#endif

#if (__UART_IO_DEVICE__ == 1)
    extern DevEntry UartIODevice;   // defined in BfDebugger.c
    extern FILE *pUartIOFile;       // needs to be defined globally and opened -> main.c
#endif
#define UartIOFileId 3


/*******************************************************************************
*
*  Exported Function Prototypes Area
*
*******************************************************************************/

short uprintf(unsigned char UartNum, const char *fmt, ...);
short udprintf(unsigned char UartNum, const char *fmt, ...);

short fileprintf(const char *file, const char *fmt, ...);

void WelcomeMessage(void);
void WelcomeMessage2(FILE* fp);


#endif // __DEBUG_H__
/******************************** End of File *********************************/
