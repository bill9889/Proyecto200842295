#define pREG_ICU_EVT11  ((volatile unsigned long *)REG_ICU_EVT11)
#define pREG_ICU_IMASK  ((volatile unsigned long *)REG_ICU_IMASK)
#define pREG_SEC_GCTL   ((volatile unsigned long *)REG_SEC_GCTL)
#define pREG_SEC_CCTL0  ((volatile unsigned long *)REG_SEC_CCTL0)
#define pREG_SEC_CSID0  ((volatile unsigned long *)REG_SEC_CSID0)
#define pREG_SEC_END    ((volatile unsigned long *)REG_SEC_END)

void sec_install_system_event_handler(void);
void sec_install_irq_handler(unsigned long IrqNum, unsigned long Prio, unsigned long Isr);
EX_INTERRUPT_HANDLER(sec_system_event_handler);
void sec_unused_error_handler(void);
