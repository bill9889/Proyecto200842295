/*****************************************************************************
**                                                                          **
**  Name:   UART Software Interface                                         **
**                                                                          **
******************************************************************************

(C) Copyright 2009 - Analog Devices, Inc.  All rights reserved.

File Name:      ADSP-BF54x-UART.h

Date Modified:  02/16/2010

Processor:      ADSP-BF54x

Software:       CrossCore Embedded Studio

Purpose:        This file contains some library functions commonly used on UART processing.

                uart print functions (Core and DMA version) are available,
                which use the same syntax like the c standard i/o printf function

******************************************************************************/

#ifndef _UART_H_
#define _UART_H_

/*******************************************************************************
*
*  Include File Area
*
*******************************************************************************/

/*******************************************************************************
*
*  Exported Constants/Definition Area
*
*******************************************************************************/

/* This are the default UART peripheral DMAs */
/* As there can only be one DMA channel assign to the same peripheral, */
/* the PMAP value of the default channel must be changed as well, */
/* if these definitions are changed! */
#define UART0TX_DMA     17
#define UART0RX_DMA     18
#define UART1TX_DMA     19
#define UART1RX_DMA     20

// USE_UART_NR sets the UART Nr to be used.
// USE_UART_DMA_NR sets the DMA channel Nr to be used.
// USE_UART_BITRATE sets a fixed UartBitrate.
// Autobaud detection is optional.
#define USE_UART_NR     0
#define AUTOBAUD        0
#define FIFOTHRESHOLD   0 // set FIFO interrupt threshold to 2/4 entries. 0 (2 entries) should be the preferred setting
#define FLOWCONTROL     0 // disable/enable Hardware Flow Control
#define FLOWPOLARITY    0 // clear/set UART_MCR.FCPOL bit

#if (AUTOBAUD==0)
#define USE_UART_BITRATE 115200
//#define USE_UART_BITRATE 921600
#endif

#if   (USE_UART_NR == 0)
    #define USE_UART_DMA_NR UART0TX_DMA
#elif (USE_UART_NR == 1)
    #define USE_UART_DMA_NR UART1TX_DMA
#else
    #error Wrong or unknown definition for USE_UART_NR
#endif


/*******************************************************************************/
/*                                                                             */
/*  DDE                                                                        */
/*                                                                             */
/*******************************************************************************/


#define UART_DMA_CONFIG_PERIINT_VAL (BITM_DMA_CFG_SYNC       |\
                                      ENUM_DMA_CFG_STOP       |\
                                      ENUM_DMA_CFG_PERIPH_INT |\
                                     0)

#define UART_DMA_CONFIG_XCNTINT_VAL (BITM_DMA_CFG_SYNC     |\
                                      ENUM_DMA_CFG_STOP     |\
                                      ENUM_DMA_CFG_XCNT_INT |\
                                     0)

#define UART_DMA_CONFIG_VAL UART_DMA_CONFIG_XCNTINT_VAL

/*******************************************************************************
*
*  Exported Types Area
*
*******************************************************************************/

/*******************************************************************************
*
*  Exported Macros Area
*
*******************************************************************************/

/*******************************************************************************
*
*  Exported Function Prototypes Area
*
*******************************************************************************/

short UartGpioInit(unsigned char UartNum);
short UartInterruptsInit(unsigned char UartNum);

long  UartAutobaud(unsigned char UartNum);

long  UartInitAutobaud(unsigned char UartNum);
short UartInit(unsigned char UartNum, unsigned long UartBitrate);
short UartInitTerminal(unsigned char UartNum, unsigned long UartBitrate);
short UartDmaInit(unsigned char UartNum, bool Dir);

short UartWaitForTransmitCompletion(unsigned char UartNum);
short UartDmaWaitForTransmitCompletion(unsigned char UartNum, bool Dir);
short UartDmaWaitForDmaDone(unsigned char UartNum, bool Dir);

short UartClockEnable(unsigned char UartNum);
short UartClockDisable(unsigned char UartNum);

short UartTxOn(unsigned char UartNum);
short UartTxOff(unsigned char UartNum);
short UartSetBreak(unsigned char UartNum);
short UartClrBreak(unsigned char UartNum);
short UartSetFfe(unsigned char UartNum);
short UartClrFfe(unsigned char UartNum);
short UartSetFpe(unsigned char UartNum);
short UartClrFpe(unsigned char UartNum);

short UartDmaBreak(unsigned char UartNum, bool Dir);
short UartDmaResume(unsigned char UartNum, bool Dir);
short UartDmaDisable(unsigned char UartNum, bool Dir);

short UartPutc(unsigned char UartNum, char c);
short UartPuts(unsigned char UartNum, char *c);
short UartPutsn(unsigned char UartNum, char *c, unsigned long NumChar);
short UartDmaPuts(unsigned char UartNum, char *c);
short UartDmaPutsn(unsigned char UartNum, char *c, unsigned short NumChar);

char  UartGetc(unsigned char UartNum);
short UartGets(unsigned char UartNum, char *c);
short UartGetsn(unsigned char UartNum, char *c, unsigned long NumChar);
short UartDmaGetsn(unsigned char UartNum, char *c, unsigned short NumChar);

short UartGetsEcho(unsigned char UartNum, char *c);
short UartEcho(unsigned char UartNum);
short UartEchoPrompt(unsigned char UartNum);

long  UartGetBitrate(unsigned char UartNum);
short UartSetBitrate(unsigned char UartNum, unsigned long UartBitrate);

short UartInsertPulse(unsigned char UartNum, unsigned char PulseLength, bool PulsePolarity);

#endif /* _UART_H_ */
/******************************** End of File *********************************/
