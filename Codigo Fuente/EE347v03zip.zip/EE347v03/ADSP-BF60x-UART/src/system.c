/*****************************************************************************
 Include Files
******************************************************************************/

#include <blackfin.h>

#include <stdio.h>
#include <stdlib.h>
#include <stdarg.h>
#include <string.h>

#include <sys/exception.h>
#include <cplb.h>
#include <cplbtab.h>

//#include <btc.h>

#include "init_platform.h"
#include "system.h"

#include "BfDebugger.h"

/*****************************************************************************
 Symbolic constants / definitions
******************************************************************************/

/*****************************************************************************
 Functions
******************************************************************************/


#if (__ADSPBF60x__ == 1)


#if (__USEBFSYSCONTROL__ == 0)


/***************************************
 *
 * Function Name : get_pllclk_hz
 * Description   : get current PLL clock frequency in Hz
 *
 * Parameters    : ulRegCgu0Ctl
 * Returns       : PLLCLK [Hz]
 * Globals       : none
 */
uint32_t get_pllclk_hz(uint32_t ulRegCgu0Ctl)
{
    uint32_t ulMsel = 0;
    uint32_t ulPllClkHz = 0;

    if (ulRegCgu0Ctl == 0) { ulRegCgu0Ctl = *pREG_CGU0_CTL; };

    ulMsel = ( (ulRegCgu0Ctl & BITM_CGU_CTL_MSEL) >> BITP_CGU_CTL_MSEL );
    if ( ulMsel == 0 ) { ulMsel = 128; }
    ulPllClkHz = ( ulMsel * CLKIN_Hz );

    return ( ulPllClkHz >> (BITM_CGU_CTL_DF & ulRegCgu0Ctl) );
}


/***************************************
 *
 * Function Name : get_pllclk_ns
 * Description   : get current PLL clock frequency in ns
 *
 * Parameters    : ulRegCgu0Ctl
 * Returns       : PLLCLK [ns]
 * Globals       : none
 */
uint32_t get_pllclk_ns(uint32_t ulRegCgu0Ctl)
{
    uint32_t ulMsel = 0;
    uint32_t ulPllClkNs = 0;
    STRUCT_ROM_SYSCTRL pllclk;

    if (ulRegCgu0Ctl == 0) { ulRegCgu0Ctl = *pREG_CGU0_CTL; };

    ulMsel = ( (ulRegCgu0Ctl & BITM_CGU_CTL_MSEL) >> BITP_CGU_CTL_MSEL );
    if ( ulMsel == 0 ) { ulMsel = 128; }
    ulPllClkNs = ( CLKIN_ns / ulMsel );

    return ( ulPllClkNs << (BITM_CGU_CTL_DF & ulRegCgu0Ctl) );
}


/***************************************
 *
 * Function Name : get_cclk_hz
 * Description   : get current core clock frequency in Hz
 *
 * Parameters    : none
 * Returns       : CCLK [Hz]
 * Globals       : none
 */
uint32_t get_cclk_hz(void)
{
    uint32_t ulCsel = 0;
    uint32_t ulRegCgu0Ctl = *pREG_CGU0_CTL;

    if (*pREG_CGU0_STAT & BITM_CGU_STAT_PLLBP) { return CLKIN_Hz; }

    ulCsel = ( (*pREG_CGU0_DIV & BITM_CGU_DIV_CSEL) >> BITP_CGU_DIV_CSEL );

    if (ulCsel == 0) { return 0; }

    return ( get_pllclk_hz(ulRegCgu0Ctl) / ulCsel );
}


/***************************************
 *
 * Function Name : get_sysclk_hz
 * Description   : get current system clock frequency in Hz
 *
 * Parameters    : ulRegCgu0Ctl, ulRegCgu0Stat, ulRegCgu0Div
 * Returns       : SYSCLK [Hz]
 * Globals       : none
 */
uint32_t get_sysclk_hz(uint32_t ulRegCgu0Ctl, uint32_t ulRegCgu0Stat, uint32_t ulRegCgu0Div)
{
    uint32_t ulSsySel = 0;

    if (ulRegCgu0Ctl == 0) {
        ulRegCgu0Ctl  = *pREG_CGU0_CTL;
        ulRegCgu0Stat = *pREG_CGU0_STAT;
        ulRegCgu0Div  = *pREG_CGU0_DIV;
    }

    if (ulRegCgu0Stat & BITM_CGU_STAT_PLLBP) { return CLKIN_Hz; }

    ulSsySel = ( (ulRegCgu0Div & BITM_CGU_DIV_SYSSEL) >> BITP_CGU_DIV_SYSSEL );

    if (ulSsySel == 0) { return 0; }

    return ( get_pllclk_hz(ulRegCgu0Ctl) / ulSsySel );
}


/***************************************
 *
 * Function Name : get_s0clk_hz
 * Description   : get current s0 clock frequency in Hz
 *
 * Parameters    : none
 * Returns       : S0CLK [Hz]
 * Globals       : none
 */
uint32_t get_s0clk_hz(void)
{
    uint32_t ulS0sel = 0;
    uint32_t ulRegCgu0Ctl  = *pREG_CGU0_CTL;
    uint32_t ulRegCgu0Stat = *pREG_CGU0_STAT;
    uint32_t ulRegCgu0Div  = *pREG_CGU0_DIV;

    if (ulRegCgu0Stat & BITM_CGU_STAT_PLLBP) { return CLKIN_Hz; }

    ulS0sel = ( (ulRegCgu0Div & BITM_CGU_DIV_S0SEL) >> BITP_CGU_DIV_S0SEL );

    if (ulS0sel == 0) { return 0; }

    return ( get_sysclk_hz(ulRegCgu0Ctl, ulRegCgu0Stat, ulRegCgu0Div) / ulS0sel );
}


/***************************************
 *
 * Function Name : get_s1clk_hz
 * Description   : get current s1 clock frequency in Hz
 *
 * Parameters    : none
 * Returns       : S1CLK [Hz]
 * Globals       : none
 */
uint32_t get_s1clk_hz(void)
{
    uint32_t ulS1sel = 0;
    uint32_t ulRegCgu0Ctl  = *pREG_CGU0_CTL;
    uint32_t ulRegCgu0Stat = *pREG_CGU0_STAT;
    uint32_t ulRegCgu0Div  = *pREG_CGU0_DIV;

    if (ulRegCgu0Stat & BITM_CGU_STAT_PLLBP) { return CLKIN_Hz; }

    ulS1sel = ( (ulRegCgu0Div & BITM_CGU_DIV_S1SEL) >> BITP_CGU_DIV_S1SEL );

    if (ulS1sel == 0) { return 0; }

    return ( get_sysclk_hz(ulRegCgu0Ctl, ulRegCgu0Stat, ulRegCgu0Div) / ulS1sel );
}


/***************************************
 *
 * Function Name : get_ddrclk_hz
 * Description   : get current ddr clock frequency in Hz
 *
 * Parameters    : none
 * Returns       : DDRCLK [Hz]
 * Globals       : none
 */
uint32_t get_ddrclk_hz(void)
{
    uint32_t ulDsel = 0;
    uint32_t ulRegCgu0Ctl = *pREG_CGU0_CTL;

    if (*pREG_CGU0_STAT & BITM_CGU_STAT_PLLBP) { return CLKIN_Hz; }

    ulDsel = ( (*pREG_CGU0_DIV & BITM_CGU_DIV_DSEL) >> BITP_CGU_DIV_DSEL );

    if (ulDsel == 0) { return 0; }

    return ( get_pllclk_hz(ulRegCgu0Ctl) / ulDsel );
}


/***************************************
 *
 * Function Name : get_ddrclk_ns
 * Description   : get current DDR clock frequency in ns
 *
 * Parameters    : none
 * Returns       : DDRCLK [ns]
 * Globals       : none
 */
uint32_t get_ddrclk_ns(void)
{
    uint32_t ulDsel = 0;
    uint32_t ulRegCgu0Ctl = *pREG_CGU0_CTL;

    if (*pREG_CGU0_STAT & BITM_CGU_STAT_PLLBP) { return CLKIN_Hz; }

    ulDsel = ( (*pREG_CGU0_DIV & BITM_CGU_DIV_DSEL) >> BITP_CGU_DIV_DSEL );

    if (ulDsel == 0) { return 0; }

    return ( get_pllclk_ns(ulRegCgu0Ctl) * ulDsel );
}


/***************************************
 *
 * Function Name : full_on
 * Description   : set the PLL Registers
 *
 * Parameters    : none
 * Returns       : none
 * Globals       : none
 */
void full_on(void)
{
    while ( !(*pREG_CGU0_STAT & BITM_CGU_STAT_PLLEN) )      { /* wait */ };
    while ( !(*pREG_CGU0_STAT & BITM_CGU_STAT_PLOCK) )      { /* wait */ };

    while ( (*pREG_CGU0_STAT & BITM_CGU_STAT_PLOCKERR) )    { /* wait */ };
    while ( (*pREG_CGU0_STAT & BITM_CGU_STAT_CLKSALGN) )    { /* wait */ };

    *pREG_CGU0_DIV = REG_CGU0_DIV_VAL;
    *pREG_CGU0_CTL = REG_CGU0_CTL_VAL;

    while ( !(*pREG_CGU0_STAT & BITM_CGU_STAT_PLOCK)    )   { /* wait */ };
    while (  (*pREG_CGU0_STAT & BITM_CGU_STAT_PLLBP)    )   { /* wait */ };
    while (  (*pREG_CGU0_STAT & BITM_CGU_STAT_CLKSALGN) )   { /* wait */ };

    return;
}


#else /* (__USEBFSYSCONTROL__ == 1) */


/***************************************
 *
 * Function Name : get_pllclk_hz
 * Description   : get current PLL clock frequency in Hz
 *
 * Parameters    : ulRegCgu0Ctl
 * Returns       : PLLCLK [Hz]
 * Globals       : none
 */
uint32_t get_pllclk_hz(uint32_t ulRegCgu0Ctl)
{
    uint32_t ulMsel = 0;
    uint32_t ulPllClkHz = 0;
    STRUCT_ROM_SYSCTRL pllclk;

    if (ulRegCgu0Ctl == 0) {
        rom_SysControl( BITM_ROM_SYSCTRL_CGU_READ | BITM_ROM_SYSCTRL_CGU_CTL, &pllclk, NULL );
    }
    else {
        pllclk.ulCGU_CTL  = ulRegCgu0Ctl;
    }

    ulMsel = ( (pllclk.ulCGU_CTL & BITM_CGU_CTL_MSEL) >> BITP_CGU_CTL_MSEL );
    if ( ulMsel == 0 ) { ulMsel = 128; }
    ulPllClkHz = ( ulMsel * CLKIN_Hz );

    return ( ulPllClkHz >> (BITM_CGU_CTL_DF & pllclk.ulCGU_CTL) );
}


/***************************************
 *
 * Function Name : get_pllclk_ns
 * Description   : get current PLL clock frequency in ns
 *
 * Parameters    : ulRegCgu0Ctl
 * Returns       : PLLCLK [ns]
 * Globals       : none
 */
uint32_t get_pllclk_ns(uint32_t ulRegCgu0Ctl)
{
    uint32_t ulMsel = 0;
    uint32_t ulPllClkNs = 0;
    STRUCT_ROM_SYSCTRL pllclk;

    if (ulRegCgu0Ctl == 0) {
        rom_SysControl( BITM_ROM_SYSCTRL_CGU_READ | BITM_ROM_SYSCTRL_CGU_CTL, &pllclk, NULL );
    }
    else {
        pllclk.ulCGU_CTL = ulRegCgu0Ctl;
    }

    ulMsel = ( (pllclk.ulCGU_CTL & BITM_CGU_CTL_MSEL) >> BITP_CGU_CTL_MSEL );
    if ( ulMsel == 0 ) { ulMsel = 128; }
    ulPllClkNs = ( CLKIN_ns/ulMsel );

    return ( ulPllClkNs << (BITM_CGU_CTL_DF & pllclk.ulCGU_CTL) );
}


/***************************************
 *
 * Function Name : get_cclk_hz
 * Description   : get current core clock frequency in Hz
 *
 * Parameters    : none
 * Returns       : CCLK [Hz]
 * Globals       : none
 */
uint32_t get_cclk_hz(void)
{
    uint32_t ulCsel = 0;
    STRUCT_ROM_SYSCTRL cclk;

    rom_SysControl( BITM_ROM_SYSCTRL_CGU_READ | BITM_ROM_SYSCTRL_CGU_CTL | BITM_ROM_SYSCTRL_CGU_DIV | BITM_ROM_SYSCTRL_CGU_STAT, &cclk, NULL );

    if (cclk.ulCGU_STAT & BITM_CGU_STAT_PLLBP) { return CLKIN_Hz; }

    ulCsel = ( (cclk.ulCGU_DIV & BITM_CGU_DIV_CSEL) >> BITP_CGU_DIV_CSEL );

    if (ulCsel == 0) { return 0; }

    return ( get_pllclk_hz(cclk.ulCGU_CTL) / ulCsel );
}


/***************************************
 *
 * Function Name : get_cclk_ns
 * Description   : get current core clock frequency in ns
 *
 * Parameters    : none
 * Returns       : CCLK [ns]
 * Globals       : none
 */
uint32_t get_cclk_ns(void)
{
    uint32_t ulCsel = 0;
    STRUCT_ROM_SYSCTRL cclk;

    rom_SysControl( BITM_ROM_SYSCTRL_CGU_READ | BITM_ROM_SYSCTRL_CGU_CTL | BITM_ROM_SYSCTRL_CGU_DIV | BITM_ROM_SYSCTRL_CGU_STAT, &cclk, NULL );

    if (cclk.ulCGU_STAT & BITM_CGU_STAT_PLLBP) { return CLKIN_Hz; }

    ulCsel = ( (cclk.ulCGU_DIV & BITM_CGU_DIV_CSEL) >> BITP_CGU_DIV_CSEL );

    if (ulCsel == 0) { return 0; }

    return ( get_pllclk_ns(cclk.ulCGU_CTL) * ulCsel );
}


/***************************************
 *
 * Function Name : get_sysclk_hz
 * Description   : get current system clock frequency in Hz
 *
 * Parameters    : ulRegCgu0Ctl, ulRegCgu0Stat, ulRegCgu0Div
 * Returns       : SYSCLK [Hz]
 * Globals       : none
 */
uint32_t get_sysclk_hz(uint32_t ulRegCgu0Ctl, uint32_t ulRegCgu0Stat, uint32_t ulRegCgu0Div)
{
    uint32_t ulSysSel = 0;
    STRUCT_ROM_SYSCTRL sysclk;

    if (ulRegCgu0Ctl == 0) {
        rom_SysControl( BITM_ROM_SYSCTRL_CGU_READ | BITM_ROM_SYSCTRL_CGU_CTL | BITM_ROM_SYSCTRL_CGU_DIV | BITM_ROM_SYSCTRL_CGU_STAT, &sysclk, NULL );
    }
    else {
        sysclk.ulCGU_CTL  = ulRegCgu0Ctl;
        sysclk.ulCGU_DIV  = ulRegCgu0Div;
        sysclk.ulCGU_STAT = ulRegCgu0Stat;
    }

    if (sysclk.ulCGU_STAT & BITM_CGU_STAT_PLLBP) { return CLKIN_Hz; }

    ulSysSel = ( (sysclk.ulCGU_DIV & BITM_CGU_DIV_SYSSEL) >> BITP_CGU_DIV_SYSSEL );

    if (ulSysSel == 0) { return 0; }

    return ( get_pllclk_hz(sysclk.ulCGU_CTL) / ulSysSel );
}


/***************************************
 *
 * Function Name : get_s0clk_hz
 * Description   : get current s0 clock frequency in Hz
 *
 * Parameters    : none
 * Returns       : S0CLK [Hz]
 * Globals       : none
 */
uint32_t get_s0clk_hz(void)
{
    uint32_t ulS0sel = 0;
    STRUCT_ROM_SYSCTRL s0clk;

    rom_SysControl( BITM_ROM_SYSCTRL_CGU_READ | BITM_ROM_SYSCTRL_CGU_CTL | BITM_ROM_SYSCTRL_CGU_DIV | BITM_ROM_SYSCTRL_CGU_STAT, &s0clk, NULL );

    if (s0clk.ulCGU_STAT & BITM_CGU_STAT_PLLBP) { return CLKIN_Hz; }

    ulS0sel = ( (s0clk.ulCGU_DIV & BITM_CGU_DIV_S0SEL) >> BITP_CGU_DIV_S0SEL );

    if (ulS0sel == 0) { return 0; }

    return ( get_sysclk_hz(s0clk.ulCGU_CTL, s0clk.ulCGU_STAT, s0clk.ulCGU_DIV) / ulS0sel );
}


/***************************************
 *
 * Function Name : get_s1clk_hz
 * Description   : get current s1 clock frequency in Hz
 *
 * Parameters    : none
 * Returns       : S1CLK [Hz]
 * Globals       : none
 */
uint32_t get_s1clk_hz(void)
{
    uint32_t ulS1sel = 0;
    STRUCT_ROM_SYSCTRL s1clk;

    rom_SysControl( BITM_ROM_SYSCTRL_CGU_READ | BITM_ROM_SYSCTRL_CGU_CTL | BITM_ROM_SYSCTRL_CGU_DIV | BITM_ROM_SYSCTRL_CGU_STAT, &s1clk, NULL );

    if (s1clk.ulCGU_STAT & BITM_CGU_STAT_PLLBP) { return CLKIN_Hz; }

    ulS1sel = ( (s1clk.ulCGU_DIV & BITM_CGU_DIV_S1SEL) >> BITP_CGU_DIV_S1SEL );

    if (ulS1sel == 0) { return 0; }

    return ( get_sysclk_hz(s1clk.ulCGU_CTL, s1clk.ulCGU_STAT, s1clk.ulCGU_DIV) / ulS1sel );
}


/***************************************
 *
 * Function Name : get_ddrclk_hz
 * Description   : get current DDR clock frequency in Hz
 *
 * Parameters    : none
 * Returns       : DDRCLK [Hz]
 * Globals       : none
 */
uint32_t get_ddrclk_hz(void)
{
    uint32_t ulDsel = 0;
    STRUCT_ROM_SYSCTRL ddrclk;

    rom_SysControl( BITM_ROM_SYSCTRL_CGU_READ | BITM_ROM_SYSCTRL_CGU_CTL | BITM_ROM_SYSCTRL_CGU_DIV | BITM_ROM_SYSCTRL_CGU_STAT, &ddrclk, NULL );

    if (ddrclk.ulCGU_STAT & BITM_CGU_STAT_PLLBP) { return CLKIN_Hz; }

    ulDsel = ( (ddrclk.ulCGU_DIV & BITM_CGU_DIV_DSEL) >> BITP_CGU_DIV_DSEL );

    if (ulDsel == 0) { return 0; }

    return ( get_pllclk_hz(ddrclk.ulCGU_CTL) / ulDsel );
}


/***************************************
 *
 * Function Name : get_ddrclk_ns
 * Description   : get current DDR clock frequency in ns
 *
 * Parameters    : none
 * Returns       : DDRCLK [ns]
 * Globals       : none
 */
uint32_t get_ddrclk_ns(void)
{
    uint32_t ulDsel = 0;
    STRUCT_ROM_SYSCTRL ddrclk;

    rom_SysControl( BITM_ROM_SYSCTRL_CGU_READ | BITM_ROM_SYSCTRL_CGU_CTL | BITM_ROM_SYSCTRL_CGU_DIV | BITM_ROM_SYSCTRL_CGU_STAT, &ddrclk, NULL );

    if (ddrclk.ulCGU_STAT & BITM_CGU_STAT_PLLBP) { return CLKIN_ns; }

    ulDsel = ( (ddrclk.ulCGU_DIV & BITM_CGU_DIV_DSEL) >> BITP_CGU_DIV_DSEL );

    if (ulDsel == 0) { return 0; }

    return ( get_pllclk_ns(ddrclk.ulCGU_CTL) * ulDsel );
}


/***************************************
 *
 * Function Name : full_on
 * Description   : set the PLL Registers
 *
 * Parameters    : none
 * Returns       : none
 * Globals       : none
 */
void full_on(void)
{
    STRUCT_ROM_SYSCTRL init;

    init.ulCGU_CTL = REG_CGU0_CTL_VAL;
    init.ulCGU_DIV = REG_CGU0_DIV_VAL;
    init.ulCGU_CLKOUTSEL = REG_CGU0_CLKOUTSEL_VAL;

#if (__DDR2SDRAM__ == 1)
    dram_selfrefresh_enter();
#endif

//    rom_SysControl( BITM_ROM_SYSCTRL_CGU_WRITE | BITM_ROM_SYSCTRL_CGU_CTL | BITM_ROM_SYSCTRL_CGU_DIV | BITM_ROM_SYSCTRL_CGU_CLKOUTSEL, &init, NULL );
    rom_SysControl( BITM_ROM_SYSCTRL_CGU_WRITE | BITM_ROM_SYSCTRL_CGU_CTL | BITM_ROM_SYSCTRL_CGU_DIV, &init, NULL );

#if (__DDR2SDRAM__ == 1)
    dll_lock_wait();
    dram_selfrefresh_exit();
#endif

    return;
}


#endif /* (__USEBFSYSCONTROL__) */


/***************************************
 *
 * Function Name : smc_en
 * Description   : enable asynchronous memory
 *
 * Parameters    : none
 * Returns       : none
 * Globals       : none
 */
void smc_en(void)
{
    *pREG_SMC0_GCTL     = REG_SMC0_GCTL_VAL;

    *pREG_SMC0_B0CTL    = REG_SMC0_B0CTL_VAL;
    *pREG_SMC0_B0TIM    = REG_SMC0_B0TIM_VAL;
    *pREG_SMC0_B0ETIM   = REG_SMC0_B0ETIM_VAL;

    *pREG_SMC0_B1CTL    = REG_SMC0_B1CTL_VAL;
    *pREG_SMC0_B1TIM    = REG_SMC0_B1TIM_VAL;
    *pREG_SMC0_B1ETIM   = REG_SMC0_B1ETIM_VAL;

    *pREG_SMC0_B2CTL    = REG_SMC0_B2CTL_VAL;
    *pREG_SMC0_B2TIM    = REG_SMC0_B2TIM_VAL;
    *pREG_SMC0_B2ETIM   = REG_SMC0_B2ETIM_VAL;

    *pREG_SMC0_B3CTL    = REG_SMC0_B3CTL_VAL;
    *pREG_SMC0_B3TIM    = REG_SMC0_B3TIM_VAL;
    *pREG_SMC0_B3ETIM   = REG_SMC0_B3ETIM_VAL;

    return;
}


#if (__DDR2SDRAM__ == 1)


/***************************************
 *
 * Function Name : dll_lock_wait
 * Description   : insert 4500 wait cycles to lock dll after DDR clock change
 *
 * Parameters    : none
 * Returns       : none
 * Globals       : none
 */
void dll_lock_wait(void)
{
    unsigned short usDsel = (*pREG_CGU0_DIV & BITM_CGU_DIV_DSEL) >> BITP_CGU_DIV_DSEL;
    unsigned short usCsel = (*pREG_CGU0_DIV & BITM_CGU_DIV_CSEL) >> BITP_CGU_DIV_CSEL;
    unsigned short usDllCyc = DLL_LOCK_PERIOD * usDsel / usCsel;
    unsigned short i = 0;

    for (i = 0 ; i < usDllCyc ; i++) { /* wait */ }
}


/***************************************
 *
 * Function Name : dmc_en
 * Description   : enable dynamic memory controller
 *
 * Parameters    : none
 * Returns       : none
 * Globals       : none
 */
void dmc_en(void)
{
    *pREG_DDR0_CFG = REG_DDR0_CFG_VAL;

    *pREG_DDR0_TR0 = REG_DDR0_TR0_VAL;
    *pREG_DDR0_TR1 = REG_DDR0_TR1_VAL;
    *pREG_DDR0_TR2 = REG_DDR0_TR2_VAL;

    *pREG_DDR0_MR   = REG_DDR0_MR_VAL;
    *pREG_DDR0_EMR1 = REG_DDR0_EMR1_VAL;
    *pREG_DDR0_EMR2 = REG_DDR0_EMR2_VAL;
    *pREG_DDR0_EMR3 = REG_DDR0_EMR3_VAL;

    *pREG_DDR0_PADCTL = REG_DDR0_PADCTL_VAL;

    *pREG_DDR0_PHY_CTL1 = REG_DDR0_PHY_CTL1_VAL;
    *pREG_DDR0_PHY_CTL3 = REG_DDR0_PHY_CTL3_VAL;

    *pREG_DDR0_CTL = REG_DDR0_CTL_VAL|BITM_DDR_CTL_INIT;

    while( !(*pREG_DDR0_STAT & BITM_DDR_STAT_MEMINITDONE) ) { /* wait */ }
    while( !(*pREG_DDR0_STAT & BITM_DDR_STAT_DLLCALDONE) )  { /* wait */ }

//    while( !(*pREG_DDR0_STAT & BITM_DDR_STAT_IDLE) )       { /* wait */ }
//    *pREG_DDR0_CTL |= BITM_DDR_CTL_DLLCAL;
//    while( !(*pREG_DDR0_STAT & BITM_DDR_STAT_DLLCALDONE) ) { /* wait */ }

//    unsigned char ucPhyRdPhase = ((*pREG_DDR0_STAT & BITM_DDR_STAT_PHYRDPHASE) >> BITP_DDR_STAT_PHYRDPHASE);
//    *pREG_DDR0_DLLCTL = ( (*pREG_DDR0_DLLCTL & ~(BITM_DDR_DLLCTL_DATACYC)) | (ucPhyRdPhase << BITP_DDR_DLLCTL_DATACYC) );

    unsigned short usDllcalRdCnt = ((*pREG_DDR0_DLLCTL & BITM_DDR_DLLCTL_DLLCALRDCNT) >> BITP_DDR_DLLCTL_DLLCALRDCNT);
    *pREG_DDR0_DLLCTL = (ENUM_DDR_DLLCTL_DATACYC5 | (usDllcalRdCnt << BITP_DDR_DLLCTL_DLLCALRDCNT));

    return;
}


/***************************************
 *
 * Function Name : dram_selfrefresh_enter
 * Description   : Put DRAM into self-refresh mode
 *
 * Parameters    : none
 * Returns       : none
 * Globals       : none
 */
void dram_selfrefresh_enter(void)
{
    if (!(*pREG_DDR0_STAT & BITM_DDR_STAT_MEMINITDONE)) { return; }
    if (*pREG_DDR0_STAT & BITM_DDR_STAT_SRACK) { return; }

    while(!(*pREG_DDR0_STAT & BITM_DDR_STAT_DLLCALDONE)) { /* wait */ }
    while(!(*pREG_DDR0_STAT & BITM_DDR_STAT_IDLE)) { /* wait */ }
    *pREG_DDR0_CTL |= BITM_DDR_CTL_SRREQ;
    while( !(*pREG_DDR0_STAT & BITM_DDR_STAT_SRACK) ) { /* wait */ }
}


/***************************************
 *
 * Function Name : dram_selfrefresh_exit
 * Description   : Exit DRAM self-refresh mode
 *
 * Parameters    : none
 * Returns       : none
 * Globals       : none
 */
void dram_selfrefresh_exit(void)
{
    if (!(*pREG_DDR0_STAT & BITM_DDR_STAT_SRACK)) { return; }

    *pREG_DDR0_CTL &= ~BITM_DDR_CTL_SRREQ;
    while(*pREG_DDR0_STAT & BITM_DDR_STAT_SRACK) { /* wait */ }
}


/***************************************
 *
 * Function Name : ddr_calc_params
 * Description   : enable DDR2-SDRAM
 *
 * Parameters    : uiDDR2Val, fDCLKns
 * Returns       : none
 * Globals       : none
 */
uint32_t ddr_calc_params(unsigned short usDDR2Val, unsigned short usfDCLKns)
{
    if ( (usDDR2Val % usfDCLKns) > 0 ) { return ( (usDDR2Val / usfDCLKns) + 1 ); }
    return (usDDR2Val / usfDCLKns);
}


/***************************************
 *
 * Function Name : dmc_en_dyn
 * Description   : enable DDR2-SDRAM
 *
 * Parameters    : none
 * Returns       : none
 * Globals       : none
 */
void dmc_en_dyn(void)
{
    unsigned long PhyRdPhase;

    unsigned short usfDCLKns            = get_ddrclk_ns();

    unsigned short usDDR_CTL_TR0_RCck   = ddr_calc_params(DDR_CTL_TR0_RCns,  usfDCLKns);
    unsigned short usDDR_CTL_TR0_RASck  = ddr_calc_params(DDR_CTL_TR0_RASns, usfDCLKns);
    unsigned short usDDR_CTL_TR0_RPck   = ddr_calc_params(DDR_CTL_TR0_RPns,  usfDCLKns);
    unsigned short usDDR_CTL_TR0_WTRck  = ddr_calc_params(DDR_CTL_TR0_WTRns, usfDCLKns);
    unsigned short usDDR_CTL_TR0_RCDck  = ddr_calc_params(DDR_CTL_TR0_RCDns, usfDCLKns);

    unsigned short usDDR_CTL_TR1_RRDck  = ddr_calc_params(DDR_CTL_TR1_RRDns,  usfDCLKns);
    unsigned short usDDR_CTL_TR1_RFCck  = ddr_calc_params(DDR_CTL_TR1_RFCns,  usfDCLKns);
    unsigned short usDDR_CTL_TR1_REFIck = ddr_calc_params(DDR_CTL_TR1_REFIns, usfDCLKns);

    unsigned short usDDR_CTL_TR2_WRck   = ddr_calc_params(DDR_CTL_TR2_WRns,  usfDCLKns);
    unsigned short usDDR_CTL_TR2_RTPck  = ddr_calc_params(DDR_CTL_TR2_RTPns, usfDCLKns);
    unsigned short usDDR_CTL_TR2_FAWck  = ddr_calc_params(DDR_CTL_TR2_FAWns, usfDCLKns);

    *pREG_DDR0_CFG = REG_DDR0_CFG_VAL;

    *pREG_DDR0_TR0 = REG_DDR0_TR0_DYN_VAL;
    *pREG_DDR0_TR1 = REG_DDR0_TR1_DYN_VAL;
    *pREG_DDR0_TR2 = REG_DDR0_TR2_DYN_VAL;

    *pREG_DDR0_MR   = REG_DDR0_MR_VAL;
    *pREG_DDR0_EMR1 = REG_DDR0_EMR1_VAL;
    *pREG_DDR0_EMR2 = REG_DDR0_EMR2_VAL;
    *pREG_DDR0_EMR3 = REG_DDR0_EMR3_VAL;

    *pREG_DDR0_PADCTL = REG_DDR0_PADCTL_VAL;

    *pREG_DDR0_PHY_CTL1 = REG_DDR0_PHY_CTL1_VAL;
    *pREG_DDR0_PHY_CTL3 = REG_DDR0_PHY_CTL3_VAL;

    *pREG_DDR0_CTL = REG_DDR0_CTL_VAL|BITM_DDR_CTL_INIT;

    while( !(*pREG_DDR0_STAT & BITM_DDR_STAT_MEMINITDONE) ) { /* wait */ }
    while( !(*pREG_DDR0_STAT & BITM_DDR_STAT_DLLCALDONE) )  { /* wait */ }

//    while( !(*pREG_DDR0_STAT & BITM_DDR_STAT_IDLE) )       { /* wait */ }
//    *pREG_DDR0_CTL |= BITM_DDR_CTL_DLLCAL;
//    while( !(*pREG_DDR0_STAT & BITM_DDR_STAT_DLLCALDONE) ) { /* wait */ }

//    unsigned char ucPhyRdPhase = ((*pREG_DDR0_STAT & BITM_DDR_STAT_PHYRDPHASE) >> BITP_DDR_STAT_PHYRDPHASE);
//    *pREG_DDR0_DLLCTL = ( (*pREG_DDR0_DLLCTL & ~(BITM_DDR_DLLCTL_DATACYC)) | (ucPhyRdPhase << BITP_DDR_DLLCTL_DATACYC) );

    unsigned short usDllcalRdCnt = ((*pREG_DDR0_DLLCTL & BITM_DDR_DLLCTL_DLLCALRDCNT) >> BITP_DDR_DLLCTL_DLLCALRDCNT);
    *pREG_DDR0_DLLCTL = (ENUM_DDR_DLLCTL_DATACYC5 | (usDllcalRdCnt << BITP_DDR_DLLCTL_DLLCALRDCNT));

    return;
}


#endif /* (__DDR2SDRAM__) */


#endif /* (__ADSPBF60x__) */


/***************************************
 *
 * Function Name : cplb_mgr_return_handler
 * Description   : CPLB Manager Return Code Handler
 *
 * Parameters    : none
 * Returns       : none
 * Globals       : none
 */
void cplb_mgr_return_handler(unsigned short cplb_mgr_return)
{
    switch (cplb_mgr_return) {
        case CPLB_RELOADED:         INFO(3,"Successfully updated CPLB table."_NL_""); return;
        case CPLB_NO_UNLOCKED:      ERROR(1,"All CPLBs are locked; thus, they cannot be evicted."_NL_"");
                                    ERROR(1,"This indicates that the CPLBs in the configuration table"_NL_"");
                                    ERROR(1,"are badly configured, as this should never occur."_NL_"");
                                    asm("EMUEXCPT; cplb_miss_all_locked: jump cplb_miss_all_locked;");
                                    break;
        case CPLB_NO_ADDR_MATCH:    ERROR(1,"The address being accessed, that triggered the exception,"_NL_"");
                                    ERROR(1,"is not covered by any of the CPLBs in the configuration table."_NL_"");
                                    ERROR(1,"The application is presumably misbehaving."_NL_"");
                                    asm("EMUEXCPT; cplb_miss_without_replacement: jump cplb_miss_without_replacement;");
                                    break;
        case CPLB_PROT_VIOL:        ERROR(1,"The address being accessed, that triggered the exception, is not a"_NL_"");
                                    ERROR(1,"first-write to a clean write-back data page, and so presumably is a"_NL_"");
                                    ERROR(1,"genuine violation of the page�s protection attributes."_NL_"");
                                    ERROR(1,"The application is misbehaving."_NL_"");
                                    asm("EMUEXCPT; cplb_protection_violation: jump cplb_protection_violation;");
                                    break;
        default:                    asm("EMUEXCPT; strange_return_from_cplb_mgr: jump strange_return_from_cplb_mgr;"); break;
    }
}


/***************************************
 *
 * Function Name : ErrorWithNoReturn
 * Description   : Kernel Panic!!!
 *
 * Parameters    : interrupt_info last_int_info
 * Returns       : none
 * Globals       : none
 */
void ErrorWithNoReturn(interrupt_info last_int_info)
{
    while(0) { asm("EMUEXCPT;"); idle(); }
}


/***************************************
 *
 * Function Name : HwErrorHandler
 * Description   : Hardware Error Handler
 *
 * Parameters    : none
 * Returns       : none
 * Globals       : none
 */
EX_EXCEPTION_HANDLER(HwErrorHandler)
{
    unsigned char HwErrCause;
    static interrupt_info last_int_info;

    get_interrupt_info(ik_hardware_err, &last_int_info);
    HwErrCause = (unsigned char) (last_int_info.value>>14);

#if defined (__BTC__)
    SequencerStatus = last_int_info.value;
    btc_poll();
#endif

//    ERROR(1,""_RESETSCREEN_"");

    switch (HwErrCause) {
        case 0x02: ERROR(1,"HWERRCAUSE 0x%02X: System MMR Error:"_NL_"",HwErrCause);
                   ERROR(1,"An error can occur if an invalid System MMR location is accessed,"_NL_"");
                   ERROR(1,"if a 32-bit register is accessed with a 16-bit instruction,"_NL_"");
                   ERROR(1,"or if a 16-bit register is accessed with a 32-bit instruction,"_NL_"");
                   ERROR(1,"or if a read-only register is written."_NL_"");
                   break;
        case 0x03: ERROR(1,"HWERRCAUSE 0x%02X: External Memory Addressing Error."_NL_"",HwErrCause);
                   ERROR(1,"An access was attempted to reserved or uninitialized memory."_NL_"");
                   break;
        case 0x12: ERROR(1,"HWERRCAUSE 0x%02X: Performance Monitor Overflow"_NL_"",HwErrCause);
                   break;
        case 0x18: ERROR(1,"HWERRCAUSE 0x%02X: RAISE 5 instruction."_NL_"",HwErrCause);
                   ERROR(1,"Software issued a RAISE 5 instruction to invoke the Hardware Error Interrupt (IVHW)."_NL_"");
                   break;
        default  : ERROR(1,"Unknown Hardware Excause Type '0x%02X'"_NL_"",HwErrCause); break;
    }

    ERROR(1,""_NL_"PC/RETI: 0x%08X "_NL_"",last_int_info.pc);

    ErrorWithNoReturn(last_int_info);
}


/***************************************
 *
 * Function Name : ExceptionHandler
 * Description   : ExceptionHandler
 *
 * Parameters    : none
 * Returns       : none
 * Globals       : none
 */
EX_EXCEPTION_HANDLER(ExceptionHandler)
{
    unsigned short cplb_mgr_return;
    unsigned  char ExCause;
    static interrupt_info last_int_info;

    get_interrupt_info(ik_exception, &last_int_info);
    ExCause = (unsigned char) (last_int_info.value);

#if defined (__BTC__)
    SequencerStatus = last_int_info.value;
    btc_poll();
#endif

//    ERROR(1,""_RESETSCREEN_"");

    switch (ExCause) {
        case EX_DB_SINGLE_STEP: INFO(1,"EXCAUSE 0x%02X: Single step."_NL_"",ExCause);
                                INFO(1,"When the processor is in single step mode, every instruction generates an exception."_NL_"");
                                INFO(1,"Primarily used for debugging."_NL_"");
                                return;
        case EX_DB_EMTRCOVRFLW: //if (*pTBUFCTL & TBUFEN) { TraceBufferPrint(); return; }
                                //else
                                //{
                                    INFO(1,"EXCAUSE 0x%02X: Exception caused by a trace buffer full condition."_NL_"",ExCause);
                                    INFO(1,"The processor takes this exception when the trace buffer overflows"_NL_"");
                                    INFO(1,"(only when enabled by the Trace Unit Control register)."_NL_"");
                                    break;
                                //}
        case EX_SYS_UNDEFINSTR: ERROR(1,"EXCAUSE 0x%02X: Undefined instruction."_NL_"",ExCause);
                                ERROR(1,"May be used to emulate instructions that are not defined for a particular processor implementation."_NL_"");
                                break;
        case EX_SYS_ILLINSTRC:  ERROR(1,"EXCAUSE 0x%02X: Illegal instruction combination."_NL_"",ExCause);
                                ERROR(1,"See section for multi-issue rules in the Blackfin Processor Programming Reference."_NL_"");
                                break;
        case EX_SYS_DCPLBPROT:  cplb_mgr_return = cplb_mgr(CPLB_EVT_DCPLB_WRITE,__cplb_ctrl);
                                cplb_mgr_return_handler(cplb_mgr_return);
                                return;
/*
                                ERROR(1,"EXCAUSE 0x%02X: Data access CPLB protection violation."_NL_"",ExCause);
                                ERROR(1,"Attempted read or write to Supervisor resource, or illegal data memory access."_NL_"");
                                ERROR(1,"Supervisor resources are registers and instructions that are reserved for Supervisor use:"_NL_"");
                                ERROR(1,"Supervisor only registers, all MMRs, and Supervisor only instructions."_NL_"");
                                ERROR(1,"(A simultaneous, dual access to two MMRs using the data address generators"_NL_"");
                                ERROR(1,"generates this type of exception.)"_NL_"");
                                ERROR(1,"In addition, this entry is used to signal a protection violation,"_NL_"");
                                ERROR(1,"caused by disallowed memory access, and it is defined by "_NL_"");
                                ERROR(1,"the Memory Management Unit (MMU) cacheability protection lookaside buffer (CPLB)."_NL_"");
                                ERROR(1,"DATA_FAULT_ADDR: 0x%08X"_NL_"",last_int_info.addr);
                                ERROR(1,"DATA_FAULT_STATUS: 0x%08X"_NL_"",last_int_info.status);
                                break;
*/
        case EX_SYS_DALIGN:     ERROR(1,"EXCAUSE 0x%02X: Data access misaligned address violation."_NL_"",ExCause);
                                ERROR(1,"Attempted misaligned data memory or data cache access."_NL_"");
                                ERROR(1,"DATA_FAULT_ADDR: 0x%08X"_NL_"",last_int_info.addr);
                                ERROR(1,"DATA_FAULT_STATUS: 0x%08X"_NL_"",last_int_info.status);
                                break;
        case EX_SYS_UNRECEVT:   ERROR(1,"EXCAUSE 0x%02X: Unrecoverable event."_NL_"",ExCause);
                                ERROR(1,"For example, an exception generated while processing a previous exception."_NL_"");
                                break;
        case EX_SYS_DCPLBMISS:  cplb_mgr_return = cplb_mgr(CPLB_EVT_DCPLB_MISS,__cplb_ctrl);
                                cplb_mgr_return_handler(cplb_mgr_return);
                                return;
/*
                                ERROR(1,"EXCAUSE 0x%02X: Data access CPLB miss."_NL_"");
                                ERROR(1,"Used by the MMU to signal a CPLB miss on a data access."_NL_"",ExCause);
                                ERROR(1,"DATA_FAULT_ADDR: 0x%08X"_NL_"",last_int_info.addr);
                                ERROR(1,"DATA_FAULT_STATUS: 0x%08X"_NL_"",last_int_info.status);
                                break;
*/
        case EX_SYS_DCPLBMHIT:  ERROR(1,"EXCAUSE 0x%02X: Data access multiple CPLB hits."_NL_"",ExCause);
                                ERROR(1,"More than one CPLB entry matches data fetch address."_NL_"");
                                ERROR(1,"DATA_FAULT_ADDR: 0x%08X"_NL_"",last_int_info.addr);
                                ERROR(1,"DATA_FAULT_STATUS: 0x%08X"_NL_"",last_int_info.status);
                                break;
        case EX_SYS_EMWATCHPT:  ERROR(1,"EXCAUSE 0x%02X: Exception caused by an emulation watchpoint match."_NL_"",ExCause);
                                ERROR(1,"There is a watchpoint match, and one of the EMUSW bits"_NL_"");
                                ERROR(1,"in the Watchpoint Instruction Address Control register (WPIACTL) is set."_NL_"");
                                break;
        case EX_SYS_CACCESSEX:  ERROR(1,"EXCAUSE 0x%02X: Instruction fetch access exception"_NL_"",ExCause);
                                ERROR(1,"CODE_FAULT_ADDR: 0x%08X"_NL_"",last_int_info.addr);
                                ERROR(1,"CODE_FAULT_STATUS: 0x%08X"_NL_"",last_int_info.status);
                                break;
        case EX_SYS_CALIGN:     ERROR(1,"EXCAUSE 0x%02X: Instruction fetch misaligned address violation."_NL_"",ExCause);
                                ERROR(1,"Attempted misaligned instruction cache fetch."_NL_"");
                                ERROR(1,"(Note this exception can never be generated from PC-relative branches, only from indirect branches.)"_NL_"");
                                ERROR(1,"CODE_FAULT_ADDR: 0x%08X"_NL_"",last_int_info.addr);
                                ERROR(1,"CODE_FAULT_STATUS: 0x%08X"_NL_"",last_int_info.status);
                                break;
        case EX_SYS_CCPLBPROT:  ERROR(1,"EXCAUSE 0x%02X: Instruction fetch CPLB protection violation."_NL_"",ExCause);
                                ERROR(1,"Illegal instruction fetch access (memory protection violation)."_NL_"");
                                ERROR(1,"CODE_FAULT_ADDR: 0x%08X"_NL_"",last_int_info.addr);
                                ERROR(1,"CODE_FAULT_STATUS: 0x%08X"_NL_"",last_int_info.status);
                                break;
        case EX_SYS_CCPLBMISS:  cplb_mgr_return = cplb_mgr(CPLB_EVT_ICPLB_MISS,__cplb_ctrl);
                                cplb_mgr_return_handler(cplb_mgr_return);
                                return;
/*
                                ERROR(1,"EXCAUSE 0x%02X: Instruction fetch CPLB miss."_NL_"",ExCause);
                                ERROR(1,"CPLB miss on an instruction fetch."_NL_"");
                                ERROR(1,"CODE_FAULT_ADDR: 0x%08X"_NL_"",last_int_info.addr);
                                ERROR(1,"CODE_FAULT_STATUS: 0x%08X"_NL_"",last_int_info.status);
                                break;
*/
        case EX_SYS_CCPLBMHIT:  ERROR(1,"EXCAUSE 0x%02X: Instruction fetch multiple CPLB hits."_NL_"",ExCause);
                                ERROR(1,"More than one CPLB entry matches instruction fetch address."_NL_"");
                                ERROR(1,"CODE_FAULT_ADDR: 0x%08X"_NL_"",last_int_info.addr);
                                ERROR(1,"CODE_FAULT_STATUS: 0x%08X"_NL_"",last_int_info.status);
                                break;
        case EX_SYS_ILLUSESUP:  ERROR(1,"EXCAUSE 0x%02X: Illegal use of supervisor resource."_NL_"",ExCause);
                                ERROR(1,"Attempted to use a Supervisor register or instruction from User mode."_NL_"");
                                ERROR(1,"Supervisor resources are registers and instructions that are reserved for Supervisor use:"_NL_"");
                                ERROR(1,"Supervisor only registers, all MMRs, and Supervisor only instructions."_NL_"");
                                break;
        default:                ERROR(1,"Unknown Excause Type '0x%02X'"_NL_"",ExCause);
                                break;
    }

    ERROR(1,""_NL_"PC/RETX: 0x%08X "_NL_"",last_int_info.pc);

    ErrorWithNoReturn(last_int_info);
}


/***************************************
 *
 * Function Name : CoreTimerInterruptHandler
 * Description   : Core Timer Interrupts Handler
 *
 * Parameters    : none
 * Returns       : none
 * Globals       : none
 */
EX_INTERRUPT_HANDLER(CoreTimerInterruptHandler)
{
    static unsigned char count;
    count = circindex(count, 1, 4);
    switch(count) {
        case 0: DEBUG(2,"|");  break;
        case 1: DEBUG(2,"/");  break;
        case 2: DEBUG(2,"-");  break;
        case 3: DEBUG(2,"\\"); break;
        default: return;
    }
}


/***************************************
 *
 * Function Name : CoreTimer
 * Description   : Core Timer Setup
 *
 * Parameters    : u32 count
 * Returns       : none
 * Globals       : none
 */
void CoreTimer(uint32_t count)
{
    #define pREG_ICU_EVT6  ((volatile unsigned long *)REG_ICU_EVT6)
//    register_handler_ex(ik_timer,CoreTimerInterruptHandler,EX_INT_ENABLE);
    *pREG_ICU_EVT6 = (unsigned long)CoreTimerInterruptHandler;
    *pREG_ICU_IMASK |= BITM_ICU_IMASK_IVTMR;
    *pTCOUNT  = count;
    *pTPERIOD = count; // When auto-reload is enabled, the TCOUNT register is reloaded with the value of TPERIOD
    *pTSCALE = 0;
    csync();
    *pTCNTL   = (BITM_TCNTL_AUTORLD|BITM_TCNTL_PWR|BITM_TCNTL_EN);
    csync();
}


/***************************************
 *
 * Function Name : CoreTimer2
 * Description   : Core Timer Setup
 *
 * Parameters    : value and *command ["s","ms","us","ns"]
 * Returns       : number of ticks
 * Globals       : none
 */
long CoreTimer2(unsigned long PosVal, const char *command)
{
    volatile unsigned long RetVal = 0;
    volatile unsigned long ticks = 0;

         if (!strncmp("ns",command,2)) { ticks=(PosVal*1); }
    else if (!strncmp("us",command,2)) { ticks=(PosVal*1000); }
    else if (!strncmp("ms",command,2)) { ticks=(PosVal*1000000); }
    else if (!strncmp( "s",command,1)) { ticks=(PosVal*1000000000); }
    else { return -1; }

    RetVal = (1000000000/get_cclk_hz());
    RetVal = ticks;

    CoreTimer(ticks);

    return RetVal;
}


/***************************************
 *
 * Function Name : wait
 * Description   : core clock based wait function
 *
 * Parameters    : value and *command ["s","ms","us","ns"]
 * Returns       : number of ticks.
 * Globals       : none
 */
long wait(unsigned long PosVal, const char *command)
{
    volatile unsigned long RetVal = 0;
    volatile unsigned long ticks = 0;

         if (!strncmp("ns",command,2)) { ticks=(PosVal*1); }
    else if (!strncmp("us",command,2)) { ticks=(PosVal*1000); }
    else if (!strncmp("ms",command,2)) { ticks=(PosVal*1000000); }
    else if (!strncmp( "s",command,1)) { ticks=(PosVal*1000000000); }
    else { return -1; }

    // while loop takes ~10 core clock cycles which will be compensated here
    ticks = (ticks/(get_cclk_ns()*10));
    RetVal = ticks;
    // whole function consumes about 1000 cylces
    if (ticks < 1000) { return RetVal; }
    while (1000 < ticks) { ticks--; }

    return RetVal;
}


/***************************************
 *
 * Function Name : wait2
 * Description   : core clock based wait function
 *                 identical to wait, but different approach
 *
 * Parameters    : value and *command ["s","ms","us","ns"]
 * Returns       : number of ticks.
 * Globals       : none
 */
long wait2(unsigned long PosVal, const char *command)
{
    volatile unsigned long RetVal = 0;
    volatile unsigned long ticks = 0;

         if (!strncmp("ns",command,2)) { ticks=(PosVal*1); }
    else if (!strncmp("us",command,2)) { ticks=(PosVal*1000); }
    else if (!strncmp("ms",command,2)) { ticks=(PosVal*1000000); }
    else if (!strncmp( "s",command,1)) { ticks=(PosVal*1000000000); }
    else { return -1; }

    RetVal = (1000000000/get_cclk_hz());
    // while loop takes ~10 core clock cycles which will be compensated here
    ticks = (ticks/(RetVal*10));
    RetVal = ticks;
    // whole function consumes about 1000 cylces
    if (ticks < 1000) { return RetVal; }
    while (1000 < ticks) { ticks--; }

    return RetVal;
}


/****************************************************************************
 EOF
*****************************************************************************/
