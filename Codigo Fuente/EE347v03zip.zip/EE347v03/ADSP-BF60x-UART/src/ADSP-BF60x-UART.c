/*****************************************************************************
**                                                                          **
**  Name:   UART Software Interface                                         **
**                                                                          **
******************************************************************************

(C) Copyright 2011-2011 - Analog Devices, Inc.  All rights reserved.

File Name:      ADSP-BF60x-UART.c

Date Modified:  10/27/2011

Processor:      ADSP-BF60x

Software:       CrossCore Embedded Studio

Purpose:        This file contains some library functions commonly used on UART processing.

                uart print functions (Core and DMA version) are available,
                which use the same syntax like the c standard i/o printf function

******************************************************************************/

/*******************************************************************************
*
*  Include File Area
*
*******************************************************************************/

#include "init_platform.h"
#include "BfDebugger.h"
#include "ADSP-BF60x-UART.h"

/*******************************************************************************
*
*  Internal Constants/Definitions Area
*
*******************************************************************************/

#define LOOP                (0) // only for test purposes

#define UART0RTS            BITM_PORT_DATA_SET_PX7  // PD7
#define UART0CTS            BITM_PORT_DATA_SET_PX8  // PD8
#define UART0TX             BITM_PORT_DATA_SET_PX9  // PD9
#define UART0RX             BITM_PORT_DATA_SET_PX10 // PD10

#define UART1RTS            BITM_PORT_DATA_SET_PX10 // PG10
#define UART1CTS            BITM_PORT_DATA_SET_PX13 // PG13
#define UART1TX             BITM_PORT_DATA_SET_PX14 // PG14
#define UART1RX             BITM_PORT_DATA_SET_PX15 // PG15

#define UART0_MMR_OFFSET    (0x0000) // 0xFFC0 2000
#define UART1_MMR_OFFSET    (0x0400) // 0xFFC0 2400

#define UART0_TIMER         (0)
#define UART1_TIMER         (1)

/*******************************************************************************
*
*  Internal Data Area
*
*******************************************************************************/

section ("L1_data_a") char UartRcvBuf[STRINGSIZE];

/*******************************************************************************
*
*  Internal Functions Area
*
*******************************************************************************/

void UartDmaInterruptsHandlerStatus(void);
void Uart0InterruptsHandlerStatus(void);
void Uart1InterruptsHandlerStatus(void);
short UartInterruptsHandlerStatus(unsigned char);
void Uart0InterruptsHandlerData(void);
void Uart1InterruptsHandlerData(void);
short UartInterruptsHandlerData(unsigned char);
void UartTimerEnable(unsigned char TmrNum, unsigned long TmrCfg);
void UartTimerDisable(unsigned char TmrNum);

void PrintDmaErrorCause(unsigned char DmaChan, unsigned long DmaIrqStatus);

/*******************************************************************************
*
*  Functions Area
*
*******************************************************************************/

//***************************************
//*
//* Function Name : short UartGpioInit(unsigned char UartNum)
//* Description   : Setup Port Structure
//*
//* Parameters    : none
//* Returns       : NULL. If UartGpioInit is unsuccessful, a negative value is returned.
//* Globals       : none
//*
short UartGpioInit(unsigned char UartNum)
{
    switch (UartNum) {
        case 0: *pREG_PORTD_MUX     &= ~0x003FC000;
                *pREG_PORTD_MUX     |=  0x00154000;
                *pREG_PORTD_FER_SET  = (BITM_PORT_FER_SET_PX10|BITM_PORT_FER_SET_PX9|BITM_PORT_FER_SET_PX8|BITM_PORT_FER_SET_PX7);
                break;
        case 1: *pREG_PORTG_MUX     &= ~0xFC300000;
                *pREG_PORTG_MUX     |=  0x00000000;
                *pREG_PORTG_FER_SET  = (BITM_PORT_FER_SET_PX15|BITM_PORT_FER_SET_PX14|BITM_PORT_FER_SET_PX13|BITM_PORT_FER_SET_PX10);
                break;
        default: return -1;
    }
    return 0;
}


/***************************************
 *
 * Function Name : UartDmaInterruptsHandlerStatus
 * Description   : Generic DMA Status Interrupts Handler
 *
 * Parameters    : none
 * Returns       : none
 * Globals       : none
 */
void UartDmaInterruptsHandlerStatus(void)
{
    unsigned char DmaChan = 0;
    volatile uint32_t *pDmaIrqStatus = 0;

         if (*pSPORT0_A_DMA_STAT & ENUM_DMA_STAT_IRQERR)    { DmaChan = CHID_SPORT0_A_DMA;      pDmaIrqStatus = pSPORT0_A_DMA_STAT; }   // DMACHAN=0
    else if (*pSPORT0_B_DMA_STAT & ENUM_DMA_STAT_IRQERR)    { DmaChan = CHID_SPORT0_B_DMA;      pDmaIrqStatus = pSPORT0_B_DMA_STAT; }   // DMACHAN=1
    else if (*pSPORT1_A_DMA_STAT & ENUM_DMA_STAT_IRQERR)    { DmaChan = CHID_SPORT1_A_DMA;      pDmaIrqStatus = pSPORT1_A_DMA_STAT; }   // DMACHAN=2
    else if (*pSPORT1_B_DMA_STAT & ENUM_DMA_STAT_IRQERR)    { DmaChan = CHID_SPORT1_B_DMA;      pDmaIrqStatus = pSPORT1_B_DMA_STAT; }   // DMACHAN=3
    else if (*pSPORT2_A_DMA_STAT & ENUM_DMA_STAT_IRQERR)    { DmaChan = CHID_SPORT2_A_DMA;      pDmaIrqStatus = pSPORT2_A_DMA_STAT; }   // DMACHAN=4
    else if (*pSPORT2_B_DMA_STAT & ENUM_DMA_STAT_IRQERR)    { DmaChan = CHID_SPORT2_B_DMA;      pDmaIrqStatus = pSPORT2_B_DMA_STAT; }   // DMACHAN=5
    else if (*pSPI0_TXDMA_STAT & ENUM_DMA_STAT_IRQERR)      { DmaChan = CHID_SPI0_TXDMA;        pDmaIrqStatus = pSPI0_TXDMA_STAT; }     // DMACHAN=6
    else if (*pSPI0_RXDMA_STAT & ENUM_DMA_STAT_IRQERR)      { DmaChan = CHID_SPI0_RXDMA;        pDmaIrqStatus = pSPI0_RXDMA_STAT; }     // DMACHAN=7
    else if (*pSPI1_TXDMA_STAT & ENUM_DMA_STAT_IRQERR)      { DmaChan = CHID_SPI1_TXDMA;        pDmaIrqStatus = pSPI1_TXDMA_STAT; }     // DMACHAN=8
    else if (*pSPI1_RXDMA_STAT & ENUM_DMA_STAT_IRQERR)      { DmaChan = CHID_SPI1_RXDMA;        pDmaIrqStatus = pSPI1_RXDMA_STAT; }     // DMACHAN=9
    else if (*pRSI0_DMA_STAT & ENUM_DMA_STAT_IRQERR)        { DmaChan = CHID_RSI0_DMA;          pDmaIrqStatus = pRSI0_DMA_STAT; }       // DMACHAN=10
    else if (*pSDU0_DMA_STAT & ENUM_DMA_STAT_IRQERR)        { DmaChan = CHID_SDU0_DMA;          pDmaIrqStatus = pSDU0_DMA_STAT; }       // DMACHAN=11
    else if (*pLP0_DMA_STAT & ENUM_DMA_STAT_IRQERR)         { DmaChan = CHID_LP0_DMA;           pDmaIrqStatus = pLP0_DMA_STAT; }        // DMACHAN=13
    else if (*pLP1_DMA_STAT & ENUM_DMA_STAT_IRQERR)         { DmaChan = CHID_LP1_DMA;           pDmaIrqStatus = pLP1_DMA_STAT; }        // DMACHAN=14
    else if (*pLP2_DMA_STAT & ENUM_DMA_STAT_IRQERR)         { DmaChan = CHID_LP2_DMA;           pDmaIrqStatus = pLP2_DMA_STAT; }        // DMACHAN=15
    else if (*pLP3_DMA_STAT & ENUM_DMA_STAT_IRQERR)         { DmaChan = CHID_LP3_DMA;           pDmaIrqStatus = pLP3_DMA_STAT; }        // DMACHAN=16
    else if (*pUART0_TXDMA_STAT & ENUM_DMA_STAT_IRQERR)     { DmaChan = CHID_UART0_TXDMA;       pDmaIrqStatus = pUART0_TXDMA_STAT; }    // DMACHAN=17
    else if (*pUART0_RXDMA_STAT & ENUM_DMA_STAT_IRQERR)     { DmaChan = CHID_UART0_RXDMA;       pDmaIrqStatus = pUART0_RXDMA_STAT; }    // DMACHAN=18
    else if (*pUART1_TXDMA_STAT & ENUM_DMA_STAT_IRQERR)     { DmaChan = CHID_UART1_TXDMA;       pDmaIrqStatus = pUART1_TXDMA_STAT; }    // DMACHAN=19
    else if (*pUART1_RXDMA_STAT & ENUM_DMA_STAT_IRQERR)     { DmaChan = CHID_UART1_RXDMA;       pDmaIrqStatus = pUART1_RXDMA_STAT; }    // DMACHAN=20
//    else if (*pMDMA0_SRC_CRC0_IN_STAT  & ENUM_DMA_STAT_IRQERR)  { DmaChan = CHID_MDMA0_SRC_CRC0_IN;  pDmaIrqStatus = pMDMA0_SRC_CRC0_IN_STAT; }     // DMACHAN=21
//    else if (*pMDMA0_DST_CRC0_OUT_STAT & ENUM_DMA_STAT_IRQERR)  { DmaChan = CHID_MDMA0_DST_CRC0_OUT; pDmaIrqStatus = pMDMA0_DST_CRC0_OUT_STAT; }    // DMACHAN=22
//    else if (*pMDMA1_SRC_CRC0_IN_STAT  & ENUM_DMA_STAT_IRQERR)  { DmaChan = CHID_MDMA1_SRC_CRC1_IN;  pDmaIrqStatus = pMDMA1_SRC_CRC0_IN_STAT; }     // DMACHAN=23
//    else if (*pMDMA1_DST_CRC0_OUT_STAT & ENUM_DMA_STAT_IRQERR)  { DmaChan = CHID_MDMA1_DST_CRC1_OUT; pDmaIrqStatus = pMDMA1_DST_CRC0_OUT_STAT; }    // DMACHAN=24
    else if (*pMDMA0_SRC_CRC0_IN_STAT  & ENUM_DMA_STAT_IRQERR)  { DmaChan = CHID_MDMA0_SRC; pDmaIrqStatus = pMDMA0_SRC_CRC0_IN_STAT; }     // DMACHAN=21
    else if (*pMDMA0_DST_CRC0_OUT_STAT & ENUM_DMA_STAT_IRQERR)  { DmaChan = CHID_MDMA0_DST; pDmaIrqStatus = pMDMA0_DST_CRC0_OUT_STAT; }    // DMACHAN=22
    else if (*pMDMA1_SRC_CRC0_IN_STAT  & ENUM_DMA_STAT_IRQERR)  { DmaChan = CHID_MDMA1_SRC; pDmaIrqStatus = pMDMA1_SRC_CRC0_IN_STAT; }     // DMACHAN=23
    else if (*pMDMA1_DST_CRC0_OUT_STAT & ENUM_DMA_STAT_IRQERR)  { DmaChan = CHID_MDMA1_DST; pDmaIrqStatus = pMDMA1_DST_CRC0_OUT_STAT; }    // DMACHAN=24
    else if (*pMDMA2_SRC_STAT & ENUM_DMA_STAT_IRQERR)       { DmaChan = CHID_MDMA2_SRC;         pDmaIrqStatus = pMDMA2_SRC_STAT; }      // DMACHAN=25
    else if (*pMDMA2_DST_STAT & ENUM_DMA_STAT_IRQERR)       { DmaChan = CHID_MDMA2_DST;         pDmaIrqStatus = pMDMA2_DST_STAT; }      // DMACHAN=26
    else if (*pMDMA3_SRC_STAT & ENUM_DMA_STAT_IRQERR)       { DmaChan = CHID_MDMA3_SRC;         pDmaIrqStatus = pMDMA3_SRC_STAT; }      // DMACHAN=27
    else if (*pMDMA3_DST_STAT & ENUM_DMA_STAT_IRQERR)       { DmaChan = CHID_MDMA3_DST;         pDmaIrqStatus = pMDMA3_DST_STAT; }      // DMACHAN=28
    else if (*pEPPI0_CH0_DMA_STAT & ENUM_DMA_STAT_IRQERR)   { DmaChan = CHID_EPPI0_CH0_DMA;     pDmaIrqStatus = pEPPI0_CH0_DMA_STAT; }  // DMACHAN=29
    else if (*pEPPI0_CH1_DMA_STAT & ENUM_DMA_STAT_IRQERR)   { DmaChan = CHID_EPPI0_CH1_DMA;     pDmaIrqStatus = pEPPI0_CH1_DMA_STAT; }  // DMACHAN=30
    else if (*pEPPI2_CH0_DMA_STAT & ENUM_DMA_STAT_IRQERR)   { DmaChan = CHID_EPPI2_CH0_DMA;     pDmaIrqStatus = pEPPI2_CH0_DMA_STAT; }  // DMACHAN=31
    else if (*pEPPI2_CH1_DMA_STAT & ENUM_DMA_STAT_IRQERR)   { DmaChan = CHID_EPPI2_CH1_DMA;     pDmaIrqStatus = pEPPI2_CH1_DMA_STAT; }  // DMACHAN=32
    else if (*pEPPI1_CH0_DMA_STAT & ENUM_DMA_STAT_IRQERR)   { DmaChan = CHID_EPPI1_CH0_DMA;     pDmaIrqStatus = pEPPI1_CH0_DMA_STAT; }  // DMACHAN=33
    else if (*pEPPI1_CH1_DMA_STAT & ENUM_DMA_STAT_IRQERR)   { DmaChan = CHID_EPPI1_CH1_DMA;     pDmaIrqStatus = pEPPI1_CH1_DMA_STAT; }  // DMACHAN=34
    else if (*pPIXC0_CH0_DMA_STAT & ENUM_DMA_STAT_IRQERR)   { DmaChan = CHID_PIXC0_CH0_DMA;     pDmaIrqStatus = pPIXC0_CH0_DMA_STAT; }  // DMACHAN=35
    else if (*pPIXC0_CH1_DMA_STAT & ENUM_DMA_STAT_IRQERR)   { DmaChan = CHID_PIXC0_CH1_DMA;     pDmaIrqStatus = pPIXC0_CH1_DMA_STAT; }  // DMACHAN=36
    else if (*pPIXC0_CH2_DMA_STAT & ENUM_DMA_STAT_IRQERR)   { DmaChan = CHID_PIXC0_CH2_DMA;     pDmaIrqStatus = pPIXC0_CH2_DMA_STAT; }  // DMACHAN=37
    else if (*pPVP0_CPDOB_DMA_STAT & ENUM_DMA_STAT_IRQERR)  { DmaChan = CHID_PVP0_CPDOB_DMA;    pDmaIrqStatus = pPVP0_CPDOB_DMA_STAT; } // DMACHAN=38
    else if (*pPVP0_CPDOC_DMA_STAT & ENUM_DMA_STAT_IRQERR)  { DmaChan = CHID_PVP0_CPDOC_DMA;    pDmaIrqStatus = pPVP0_CPDOC_DMA_STAT; } // DMACHAN=39
    else if (*pPVP0_CPSTAT_DMA_STAT & ENUM_DMA_STAT_IRQERR) { DmaChan = CHID_PVP0_CPSTAT_DMA;   pDmaIrqStatus = pPVP0_CPSTAT_DMA_STAT; } // DMACHAN=40
    else if (*pPVP0_CPCI_DMA_STAT & ENUM_DMA_STAT_IRQERR)   { DmaChan = CHID_PVP0_CPCI_DMA;     pDmaIrqStatus = pPVP0_CPCI_DMA_STAT; }  // DMACHAN=41
    else if (*pPVP0_MPDO_DMA_STAT & ENUM_DMA_STAT_IRQERR)   { DmaChan = CHID_PVP0_MPDO_DMA;     pDmaIrqStatus = pPVP0_MPDO_DMA_STAT; }  // DMACHAN=42
    else if (*pPVP0_MPDI_DMA_STAT & ENUM_DMA_STAT_IRQERR)   { DmaChan = CHID_PVP0_MPDI_DMA;     pDmaIrqStatus = pPVP0_MPDI_DMA_STAT; }  // DMACHAN=43
    else if (*pPVP0_MPSTAT_DMA_STAT & ENUM_DMA_STAT_IRQERR) { DmaChan = CHID_PVP0_MPSTAT_DMA;   pDmaIrqStatus = pPVP0_MPSTAT_DMA_STAT; } // DMACHAN=44
    else if (*pPVP0_MPCI_DMA_STAT & ENUM_DMA_STAT_IRQERR)   { DmaChan = CHID_PVP0_MPCI_DMA;     pDmaIrqStatus = pPVP0_MPCI_DMA_STAT; }  // DMACHAN=45
    else if (*pPVP0_CPDOA_DMA_STAT & ENUM_DMA_STAT_IRQERR)  { DmaChan = CHID_PVP0_CPDOA_DMA;    pDmaIrqStatus = pPVP0_CPDOA_DMA_STAT; } // DMACHAN=46
    else { printf("%s(): Unknown DMA status interrupt source\n",__func__); EMUEXCPT(); }

    PrintDmaErrorCause(DmaChan, *pDmaIrqStatus & ENUM_DMA_STAT_IRQERR);

    ssync();
}


/***************************************
 *
 * Function Name : PrintDmaErrorCause
 * Description   :
 *
 * Parameters    : DmaChan, DmaIrqStatus
 * Returns       : none
 * Globals       : none
 */
void PrintDmaErrorCause(unsigned char DmaChan, unsigned long DmaIrqStatus)
{
    printf("\n\n");
    switch(DmaIrqStatus & BITM_DMA_STAT_ERRC) {
        case ENUM_DMA_STAT_CFGERR:   printf("%s(): DMA%d ERRC: Configuration Error\n",__func__, DmaChan); break;
        case ENUM_DMA_STAT_ILLWRERR: printf("%s(): DMA%d ERRC: Illegal Write Occurred While Channel Running\n",__func__, DmaChan); break;
        case ENUM_DMA_STAT_ALGNERR:  printf("%s(): DMA%d ERRC: Address Alignment Error\n",__func__, DmaChan); break;
        case ENUM_DMA_STAT_MEMERR:   printf("%s(): DMA%d ERRC: Memory Access/Fabric Error\n",__func__, DmaChan); break;
        case ENUM_DMA_STAT_TRGOVERR: printf("%s(): DMA%d ERRC: Trigger Overrun\n",__func__, DmaChan); break;
        case ENUM_DMA_STAT_BWMONERR: printf("%s(): DMA%d ERRC: Bandwidth Monitor Error\n",__func__, DmaChan); break;
        default: break;
    }
    printf("\n\n");

    while(0) { asm("EMUEXCPT;"); idle(); }
}


/***************************************
 *
 * Function Name : Uart0InterruptsHandlerStatus
 * Description   : UART0 Status Interrupts Handler
 *
 * Parameters    : none
 * Returns       : none
 * Globals       : none
 */
void Uart0InterruptsHandlerStatus(void)
{
    UartInterruptsHandlerStatus(0);
}


/***************************************
 *
 * Function Name : Uart1InterruptsHandlerStatus
 * Description   : UART1 Status Interrupts Handler
 *
 * Parameters    : none
 * Returns       : none
 * Globals       : none
 */
void Uart1InterruptsHandlerStatus(void)
{
    UartInterruptsHandlerStatus(1);
}


/***************************************
 *
 * Function Name : UartInterruptsHandlerStatus
 * Description   : Generic UART Status Interrupts Handler
 *
 * Parameters    : UartNum
 * Returns       : NULL. If UartInterruptsHandlerStatus is unsuccessful, a negative value is returned.
 * Globals       : none
 */
short UartInterruptsHandlerStatus(unsigned char UartNum)
{
    unsigned short UartMmrOffset = 0;
    unsigned  long UartStat = 0;
    char c;

    switch (UartNum) {
        case 0: UartMmrOffset = UART0_MMR_OFFSET; break;
        case 1: UartMmrOffset = UART1_MMR_OFFSET; break;
        default: printf("%s(): UART%d is not available.\n",__func__,UartNum); return -1;
    }

    volatile unsigned long *pUartCtl  = (volatile unsigned long*) (UartMmrOffset + REG_UART0_CTL);
    volatile unsigned long *pUartStat = (volatile unsigned long*) (UartMmrOffset + REG_UART0_STAT);

    ssync();

    UartStat = *pUartStat;

    if (UartStat &  BITM_UART_STAT_TFI) { *pUartStat =  BITM_UART_STAT_TFI; return 0; }
    if (UartStat &   BITM_UART_STAT_BI) { *pUartStat =   BITM_UART_STAT_BI; ERROR(1,"UART%d Break Interrupt\n", UartNum); }
    if (UartStat &   BITM_UART_STAT_FE) { *pUartStat =   BITM_UART_STAT_FE; ERROR(1,"UART%d Framing Error\n",   UartNum); }
    if (UartStat &   BITM_UART_STAT_PE) { *pUartStat =   BITM_UART_STAT_PE; ERROR(1,"UART%d Parity Error\n",    UartNum); }
    if (UartStat &   BITM_UART_STAT_OE) { *pUartStat =   BITM_UART_STAT_OE; ERROR(1,"UART%d Overrun Error\n",   UartNum); }
    if (UartStat & BITM_UART_STAT_SCTS) { *pUartStat = BITM_UART_STAT_SCTS; INFO(1,"UART%d_CTS transitioned from 0 to 1\n", UartNum); }

    if (UartStat & BITM_UART_STAT_RFCS) {
        if (*pUartCtl & BITM_UART_CTL_RFIT) { INFO(1,"Receive Buffer contains 4 or more entries\n"); }
        else                                { INFO(1,"Receive Buffer contains 2 or more entries\n"); }
        while (*pUartStat & BITM_UART_STAT_DR) { c = UartGetc(UartNum); } // just clear FIFO, more advanced handler required
    }
    if (UartStat &  BITM_UART_STAT_OE) {
        while (*pUartStat & BITM_UART_STAT_DR) { c = UartGetc(UartNum); } // just clear FIFO, more advanced handler required
        *pUartStat = BITM_UART_STAT_OE;
    }

    return 0;
}


/***************************************
 *
 * Function Name : Uart0InterruptsHandlerData
 * Description   : UART0 Data Interrupts Handler
 *
 * Parameters    : none
 * Returns       : none
 * Globals       : none
 */
void Uart0InterruptsHandlerData(void)
{
    UartInterruptsHandlerData(0);
}


/***************************************
 *
 * Function Name : Uart1InterruptsHandlerData
 * Description   : UART1 Data Interrupts Handler
 *
 * Parameters    : none
 * Returns       : none
 * Globals       : none
 */
void Uart1InterruptsHandlerData(void)
{
    UartInterruptsHandlerData(1);
}


/***************************************
 *
 * Function Name : UartInterruptsHandlerData
 * Description   : Generic UART Data Interrupts Handler
 *
 * Parameters    : UartNum
 * Returns       : NULL. If UartInterruptsHandlerData is unsuccessful, a negative value is returned.
 * Globals       : none
 */
short UartInterruptsHandlerData(unsigned char UartNum)
{
    unsigned short UartMmrOffset = 0;

    switch (UartNum) {
        case 0: UartMmrOffset = UART0_MMR_OFFSET; break;
        case 1: UartMmrOffset = UART1_MMR_OFFSET; break;
        default: printf("%s(): UART%d is not available.\n",__func__,UartNum); return -1;
    }

    volatile unsigned long *pUartStat = (volatile unsigned long*) (UartMmrOffset + REG_UART0_STAT);

//    if (*pUartStat & BITM_UART_STAT_DR) { UartGets(UartNum, UartRcvBuf); } // start to receive string from UART terminal. Stop when a carriage return is received (or buffer is full)
//    if (*pUartStat & BITM_UART_STAT_DR) { UartGetsEcho(UartNum, UartRcvBuf); } // start to receive string from UART terminal and bounce it back. Stop when a carriage return is received (or buffer is full)
//    if (*pUartStat & BITM_UART_STAT_DR) { UartEcho(UartNum); } // simple ping pong
    if (*pUartStat & BITM_UART_STAT_DR) { UartEchoPrompt(UartNum); } // start to receive string from UART terminal and bounce it back. Stop when a carriage return is received (or buffer is full)

    if (*pUartStat & BITM_UART_STAT_TFI) { *pUartStat = BITM_UART_STAT_TFI; }

    return 0;
}


//***************************************
//*
//* Function Name : UartInterruptsInit
//* Description   : Setup Interrupts and register handlers
//*
//* Parameters    : UART Number
//* Returns       : NULL. If UartInterruptsInit is unsuccessful, a negative value is returned.
//* Globals       : none
//*
short UartInterruptsInit(unsigned char UartNum)
{
    unsigned short UartMmrOffset = 0;

    switch (UartNum) {
        case 0: UartMmrOffset = UART0_MMR_OFFSET;
//                sec_install_irq_handler(80,80,(unsigned long)Uart0InterruptsHandlerData); // TX0
                sec_install_irq_handler(81,81,(unsigned long)Uart0InterruptsHandlerData); // RX0
                sec_install_irq_handler(82,82,(unsigned long)Uart0InterruptsHandlerStatus); // STAT0
                break;
        case 1: UartMmrOffset = UART1_MMR_OFFSET;
//                sec_install_irq_handler(83,83,(unsigned long)Uart1InterruptsHandlerData); // TX1
                sec_install_irq_handler(84,84,(unsigned long)Uart1InterruptsHandlerData); // RX1
                sec_install_irq_handler(85,85,(unsigned long)Uart1InterruptsHandlerStatus); // STAT1
                break;
        default: return -1;
    }

    sec_install_irq_handler(128,128,(unsigned long)UartDmaInterruptsHandlerStatus);

    volatile unsigned long *pUartImskSet = (volatile unsigned long*) (UartMmrOffset + REG_UART0_IMSK_SET);

    *pUartImskSet = (BITM_UART_IMSK_ERBFI|BITM_UART_IMSK_ELSI|BITM_UART_IMSK_ERFCI);

    return 0;
}


//***************************************
//*
//* Function Name : UartAutobaud
//* Description   : Assuming 8 data bits, this functions expects a '@'
//*                 (ASCII 0x40) character on the UART RX pin.
//*
//*                 Timer TmrNum performs the autobaud detection.
//*                 Also special support for half-duplex systems is provided.
//*
//* Parameters    : UART Number
//* Returns       : Timer Period Count. If UartAutobaud is unsuccessful, a negative value is returned.
//* Globals       : none
//*
long UartAutobaud(unsigned char UartNum)
{
    unsigned short UartMmrOffset        = 0;
    unsigned short TimerStatusOffset    = 0;
    unsigned short TimerEnDisableOffset = 0;
    unsigned  long TimerPeriod          = 0;
    unsigned  char TmrNum               = 0;

    switch (UartNum) {
        case 0: UartMmrOffset = UART0_MMR_OFFSET; TmrNum = UART0_TIMER; break;
        case 1: UartMmrOffset = UART1_MMR_OFFSET; TmrNum = UART1_TIMER; break;
        default: printf("%s(): UART%d is not available.\n",__func__,UartNum); return -1;
    }

    volatile unsigned long *pUartCtl     = (volatile unsigned long*) (UartMmrOffset + REG_UART0_CTL);
    volatile unsigned long *pTimerPeriod = (volatile unsigned long*) (REG_TIMER0_TMR0_PER + TmrNum * 0x20);

    // Setup Timer Controller to do the autobaud detection. Timer captures
    // duration between two falling edges. It expects a '@' (ASCII 0x40) 
    // character. 8-bit, no parity assumed.
    // Disable Timer first, in case there was an unexpected history.
    UartTimerDisable(TmrNum);

    // Activate Loopback mode in order the receive channel is disconnected 
    // from RX pin during autobaud detection.
#if (FLOW_CONTROL == 1)
    *pUartCtl = (BITM_UART_CTL_LOOP_EN | BITM_UART_CTL_EN | BITM_UART_CTL_FCPOL);
#else
    *pUartCtl = (BITM_UART_CTL_LOOP_EN | BITM_UART_CTL_EN);
#endif

    // Capture from UART RxD pin. Select TimerPeriod capture from falling edge to 
    // falling edge. Enable IRQ_ENA, but don't enable the interrupt at system 
    // level (SIC).
    // Start the timer and wait until the according interrupt latch bit TIMILx
    // in the TIMER_STATUS register is set. Then, two falling edges on the RxD
    // pin have been detected.
    UartTimerEnable(TmrNum, BITM_TIMER_TMR_CFG_TINSEL | ENUM_TIMER_TMR_CFG_IRQMODE2 | ENUM_TIMER_TMR_CFG_WIDCAP0_MODE);

    while (!(*pREG_TIMER0_DATA_ILAT & (1 << TmrNum))) { /* wait */ }

    // Disable Timer again
    UartTimerDisable(TmrNum);

    // Save TimerPeriod value
    TimerPeriod = *pTimerPeriod;

    // In order to support also half-duplex connections, we need to delay any 
    // transmission, in order the sent character does not overlap the autobaud
    // pattern.
    // Use Timer to perform this delay. Note that the Period Register still
    // contains the proper value and the Width Register is not used.
    UartTimerEnable(TmrNum, BITM_TIMER_TMR_CFG_OUTDIS | ENUM_TIMER_TMR_CFG_IRQMODE2 | ENUM_TIMER_TMR_CFG_PWMSING_MODE);

    while (!(*pREG_TIMER0_DATA_ILAT & (1 << TmrNum))) { /* wait */ }

    // Disable the Timer again
    UartTimerDisable(TmrNum);

    // Deactivate Loopback mode again
    *pUartCtl &= ~(BITM_UART_CTL_FCPOL | BITM_UART_CTL_LOOP_EN);

    // Return TimerPeriod
    return TimerPeriod;
}


//***************************************
//*
//* Function Name : UartTimerDisable
//* Description   : Disables and Resets Timer TmrNum
//*
//* Parameters    : TmrNum, TmrCfg
//* Returns       : none
//* Globals       : none
//*
void UartTimerEnable(unsigned char TmrNum, unsigned long TmrCfg)
{
    volatile unsigned short *pTimerConfig = (volatile unsigned short*) (REG_TIMER0_TMR0_CFG + TmrNum * 0x20);
    volatile unsigned  long *pTimerPeriod = (volatile unsigned  long*) (REG_TIMER0_TMR0_PER + TmrNum * 0x20);
    volatile unsigned  long *pTimerWidth  = (volatile unsigned  long*) (REG_TIMER0_TMR0_WID + TmrNum * 0x20);
    volatile unsigned  long *pTimerDelay  = (volatile unsigned  long*) (REG_TIMER0_TMR0_DLY + TmrNum * 0x20);
    unsigned long TimerPeriod = 0;

    *pREG_TIMER0_STOP_CFG_SET  =  (1 << TmrNum);
    *pREG_TIMER0_DATA_IMSK    &= ~(1 << TmrNum);
    TimerPeriod   = *pTimerPeriod;
    *pTimerConfig = TmrCfg;
    *pTimerPeriod = TimerPeriod;
    *pTimerWidth  = TimerPeriod;
    *pTimerDelay  = 0;
    *pREG_TIMER0_RUN_SET = (1 << TmrNum);
    ssync();
}


//***************************************
//*
//* Function Name : UartTimerDisable
//* Description   : Disables and Resets Timer TmrNum
//*
//* Parameters    : TmrNum
//* Returns       : none
//* Globals       : none
//*
void UartTimerDisable(unsigned char TmrNum)
{
    volatile unsigned short *pTimerConfig = (volatile unsigned short*) (REG_TIMER0_TMR0_CFG + TmrNum * 0x20);

    *pREG_TIMER0_RUN_CLR       = (1 << TmrNum);
    *pREG_TIMER0_STAT_ILAT     = (1 << TmrNum);
    *pREG_TIMER0_DATA_ILAT     = (1 << TmrNum);
    *pREG_TIMER0_STOP_CFG_CLR  = (1 << TmrNum);
    *pREG_TIMER0_DATA_IMSK    |= (1 << TmrNum);
    *pTimerConfig = 0;
    ssync();
}


//***************************************
//*
//* Function Name : UartInitAutobaud
//* Description   : Configures UART in 8 data bits, no parity, 1 stop bit mode.
//*
//*                 Autobaud function used, if UartDivisor parameter is NULL
//*
//* Parameters    : UART Number
//* Returns       : UART Bitrate Value. If UartInitAutobaud is unsuccessful, a negative value is returned.
//* Globals       : none
//*
long UartInitAutobaud(unsigned char UartNum)
{
    unsigned short UartMmrOffset = 0;
    unsigned  long UartBitrate   = 0;
    unsigned short UartDivisor   = 0;
              long TimerPeriod   = 0;

    switch (UartNum) {
        case 0: UartMmrOffset = UART0_MMR_OFFSET; break;
        case 1: UartMmrOffset = UART1_MMR_OFFSET; break;
        default: printf("%s(): UART%d is not available.\n",__func__,UartNum); return -1;
    }

    printf("UART%d autobaud detection with character '@'.\n",UartNum);

    volatile unsigned long *pUartCtl = (volatile unsigned long*) (UartMmrOffset + REG_UART0_CTL);
    volatile unsigned long *pUartClk = (volatile unsigned long*) (UartMmrOffset + REG_UART0_CLK);

    if (*pUartCtl & BITM_UART_CTL_EN) { return -1; } // UART already enabled

    UartGpioInit(UartNum);

    // Autobaud
    TimerPeriod = UartAutobaud(UartNum);
    if (TimerPeriod == -1) { return -1;}

    // First of all, enable UART clock.
    *pUartCtl = (ENUM_UART_CTL_WL8BITS | BITM_UART_CTL_EN);

//    if (TimerPeriod<=524288) { *pUartClk |= BITM_UART_CLK_EDBO; } /* 2^19 -> 2^16 for the unsigned short value plus the shift by 3 */

    if (*pUartClk & BITM_UART_CLK_EDBO) {
        TimerPeriod += 4; // round up before divide by 8
        UartDivisor = ( TimerPeriod >> 3 );
        /* UartDivisor is an unsigned short value whereby TimerPeriod is long */
        /* For very small bitrates, the period might be long when EDBO=1 and only a division by 8 is done */
        /* E.g. SCLK = 131.250.000 Hz + Bitrate = 1.200 will result in a calculated bitrate of about 3.000 */
    }
    else {
        TimerPeriod += 64; // round up before divide by 128
        UartDivisor = ( TimerPeriod >> 7 );
    }

    // Write Divisor.
    *pUartClk &= ~(BITM_UART_CLK_DIV);
    *pUartClk |= UartDivisor;

    // Set UART frame to 8 bits, no parity, 1 stop bit.
    // This may differ in other scenarios.
#if (FLOWCONTROL == 1)
    *pUartCtl |= (BITM_UART_CTL_ARTS | BITM_UART_CTL_ACTS);
#endif
#if (FLOWPOLARITY == 1)
    *pUartCtl |= BITM_UART_CTL_FCPOL;
#endif
#if (FIFOTHRESHOLD == 1)
    *pUartCtl |= BITM_UART_CTL_RFIT;
#endif
#if (LOOP == 1)
    /* In loopback mode, MRTS (de)activates the UART's transmitter and sets/clears the CTS bit */
    *pUartCtl |= (BITM_UART_CTL_LOOP_EN | BITM_UART_CTL_MRTS);
#endif

    // return UartBitrate
    UartBitrate = ( get_s0clk_hz() / UartDivisor );
    if (!(*pUartClk & BITM_UART_CLK_EDBO)) {
        UartBitrate += 8; // round up before divide by 16
        UartBitrate >>= 4;
    }

#if (LOOP == 0)
    UartInterruptsInit(UartNum);
#endif

    return UartBitrate;
}


//***************************************
//*
//* Function Name : UartDmaInitAutobaud
//* Description   : Pre-Configures DMA channel.
//*
//* Parameters    : UART Number, Direction (0 - Memory Read / TX, 1 - Memory Write / RX)
//* Returns       : UART Bitrate Value. If UartDmaInitAutobaud is unsuccessful, a negative value is returned.
//* Globals       : none
//*
long UartDmaInitAutobaud(unsigned char UartNum, bool Dir)
{
    long UartBitrate = UartInitAutobaud(UartNum);
    if (UartBitrate == -1) { return -1; }

    unsigned long DmaMmrOffset = (UartNum | (Dir << 4));

    switch (DmaMmrOffset) {
        case 0x00: DmaMmrOffset = UART0_TXDMA_DSCPTR_NXT - UART0_TXDMA_DSCPTR_NXT; break; // DMA17 UART0 TX
        case 0x01: DmaMmrOffset = UART0_RXDMA_DSCPTR_NXT - UART0_TXDMA_DSCPTR_NXT; break; // DMA18 UART0 RX
        case 0x10: DmaMmrOffset = UART1_TXDMA_DSCPTR_NXT - UART0_TXDMA_DSCPTR_NXT; break; // DMA19 UART1 TX
        case 0x11: DmaMmrOffset = UART1_RXDMA_DSCPTR_NXT - UART0_TXDMA_DSCPTR_NXT; break; // DMA20 UART1 RX
        default: return 0;
    }

    volatile unsigned long *pDmaNextDescPtr  = (volatile unsigned long*) (DmaMmrOffset + UART0_TXDMA_DSCPTR_NXT);
    volatile unsigned long *pDmaStartAddr    = (volatile unsigned long*) (DmaMmrOffset + UART0_TXDMA_ADDRSTART);
    volatile unsigned long *pDmaConfig       = (volatile unsigned long*) (DmaMmrOffset + UART0_TXDMA_CFG);
    volatile unsigned long *pDmaXCount       = (volatile unsigned long*) (DmaMmrOffset + UART0_TXDMA_XCNT);
    volatile unsigned long *pDmaXModify      = (volatile unsigned long*) (DmaMmrOffset + UART0_TXDMA_XMOD);
    volatile unsigned long *pDmaYCount       = (volatile unsigned long*) (DmaMmrOffset + UART0_TXDMA_YCNT);
    volatile unsigned long *pDmaYModify      = (volatile unsigned long*) (DmaMmrOffset + UART0_TXDMA_YMOD);
    volatile unsigned long *pDmaCurrDescPtr  = (volatile unsigned long*) (DmaMmrOffset + UART0_TXDMA_DSCPTR_CUR);
    volatile unsigned long *pDmaCurrDescPrv  = (volatile unsigned long*) (DmaMmrOffset + UART0_TXDMA_DSCPTR_PRV);
    volatile unsigned long *pDmaCurrAddr     = (volatile unsigned long*) (DmaMmrOffset + UART0_TXDMA_ADDR_CUR);
    volatile unsigned long *pDmaIrqStatus    = (volatile unsigned long*) (DmaMmrOffset + UART0_TXDMA_STAT);
    volatile unsigned long *pDmaCurrXCount   = (volatile unsigned long*) (DmaMmrOffset + UART0_TXDMA_XCNT_CUR);
    volatile unsigned long *pDmaCurrYCount   = (volatile unsigned long*) (DmaMmrOffset + UART0_TXDMA_YCNT_CUR);
    volatile unsigned long *pDmaBwlCount     = (volatile unsigned long*) (DmaMmrOffset + UART0_TXDMA_BWLCNT);
    volatile unsigned long *pDmaBwlCurrCount = (volatile unsigned long*) (DmaMmrOffset + UART0_TXDMA_BWLCNT_CUR);
    volatile unsigned long *pDmaBwmCount     = (volatile unsigned long*) (DmaMmrOffset + UART0_TXDMA_BWMCNT);
    volatile unsigned long *pDmaBwmCurrCount = (volatile unsigned long*) (DmaMmrOffset + UART0_TXDMA_BWMCNT_CUR);

    *pDmaConfig         = 0;
    *pDmaNextDescPtr    = 0;
    *pDmaStartAddr      = 0xFF804000;
    *pDmaXCount         = 0;
    *pDmaXModify        = 1;
    *pDmaYCount         = 0;
    *pDmaYModify        = 0;
    *pDmaCurrDescPtr    = 0;
    *pDmaCurrAddr       = 0;
    *pDmaCurrXCount     = 0;
    *pDmaCurrYCount     = 0;
    *pDmaBwlCount       = 0;
    *pDmaBwlCurrCount   = 0;
    *pDmaBwmCount       = 0;
    *pDmaBwmCurrCount   = 0;

    ssync();

    return UartBitrate;
}


//***************************************
//*
//* Function Name : UartInit
//* Description   : Configures UART in 8 data bits, no parity, 1 stop bit mode. 
//*
//* Parameters    : UART Number, UART Bitrate Value
//* Returns       : If the UartInit function is unsuccessful, a negative value is returned.
//* Globals       : none
//*
short UartInit(unsigned char UartNum, unsigned long UartBitrate)
{
    unsigned short UartMmrOffset = 0;
    unsigned  long UartDivisor   = 0;

    switch (UartNum) {
        case 0: UartMmrOffset = UART0_MMR_OFFSET; break;
        case 1: UartMmrOffset = UART1_MMR_OFFSET; break;
        default: printf("%s(): UART%d is not available.\n",__func__,UartNum); return -1;
    }

    volatile unsigned long *pUartCtl = (volatile unsigned long*) (UartMmrOffset + REG_UART0_CTL);
    volatile unsigned long *pUartClk = (volatile unsigned long*) (UartMmrOffset + REG_UART0_CLK);

    UartGpioInit(UartNum);

    UartSetBitrate(UartNum, UartBitrate);

#if (LOOP == 0)
    UartInterruptsInit(UartNum);
#endif

    // Enable UART clock
    *pUartCtl = (ENUM_UART_CTL_WL8BITS | BITM_UART_CTL_EN);

    // Set UART frame to 8 bits, no parity, 1 stop bit.
    // This may differ in other scenarios.
#if (FLOWCONTROL == 1)
    *pUartCtl |= (BITM_UART_CTL_ARTS | BITM_UART_CTL_ACTS);
#endif
#if (FLOWPOLARITY == 1)
    *pUartCtl |= BITM_UART_CTL_FCPOL;
#endif
#if (FIFOTHRESHOLD == 1)
    *pUartCtl |= BITM_UART_CTL_RFIT;
#endif
#if (LOOP == 1)
    /* In loopback mode, MRTS (de)activates the UART's transmitter and sets/clears the CTS bit */
    *pUartCtl |= (BITM_UART_CTL_LOOP_EN | BITM_UART_CTL_MRTS);
#endif

    return 0;
}


//***************************************
//*
//* Function Name : UartInit
//* Description   : Configures UART in 8 data bits, no parity, 1 stop bit mode. 
//*
//* Parameters    : UART Number, UART Bitrate Value
//* Returns       : If the UartInit function is unsuccessful, a negative value is returned.
//* Globals       : none
//*
short UartInitTerminal(unsigned char UartNum, unsigned long UartBitrate)
{
    unsigned short UartMmrOffset = 0;
    unsigned  long UartDivisor   = 0;

    switch (UartNum) {
        case 0: UartMmrOffset = UART0_MMR_OFFSET; break;
        case 1: UartMmrOffset = UART1_MMR_OFFSET; break;
        default: printf("%s(): UART%d is not available.\n",__func__,UartNum); return -1;
    }

    volatile unsigned long *pUartCtl = (volatile unsigned long*) (UartMmrOffset + REG_UART0_CTL);
    volatile unsigned long *pUartClk = (volatile unsigned long*) (UartMmrOffset + REG_UART0_CLK);

    UartGpioInit(UartNum);

    UartSetBitrate(UartNum, UartBitrate);

    UartInterruptsInit(UartNum);

    // Enable UART clock
    *pUartCtl = (ENUM_UART_CTL_WL8BITS | BITM_UART_CTL_EN);

    // Set UART frame to 8 bits, no parity, 1 stop bit.
    // This may differ in other scenarios.
#if (FLOWCONTROL == 1)
    *pUartCtl |= (BITM_UART_CTL_ARTS | BITM_UART_CTL_ACTS);
#endif
#if (FLOWPOLARITY == 1)
    *pUartCtl |= BITM_UART_CTL_FCPOL;
#endif
#if (FIFOTHRESHOLD == 1)
    *pUartCtl |= BITM_UART_CTL_RFIT;
#endif

    return 0;
}


//***************************************
//*
//* Function Name : UartDmaInit
//* Description   : Pre-Configures DMA channel.
//*
//* Parameters    : UART Number, Direction (0 - Memory Read / TX, 1 - Memory Write / RX), UART Bitrate Value
//* Returns       : If the UartDmaInit function is unsuccessful, a negative value is returned.
//* Globals       : none
//*
short UartDmaInit(unsigned char UartNum, bool Dir)
{
    unsigned long DmaMmrOffset = (UartNum | (Dir << 4));

    switch (DmaMmrOffset) {
        case 0x00: DmaMmrOffset = UART0_TXDMA_DSCPTR_NXT - UART0_TXDMA_DSCPTR_NXT; break; // DMA17 UART0 TX
        case 0x01: DmaMmrOffset = UART0_RXDMA_DSCPTR_NXT - UART0_TXDMA_DSCPTR_NXT; break; // DMA18 UART0 RX
        case 0x10: DmaMmrOffset = UART1_TXDMA_DSCPTR_NXT - UART0_TXDMA_DSCPTR_NXT; break; // DMA19 UART1 TX
        case 0x11: DmaMmrOffset = UART1_RXDMA_DSCPTR_NXT - UART0_TXDMA_DSCPTR_NXT; break; // DMA20 UART1 RX
        default: return 0;
    }

    volatile unsigned long *pDmaNextDescPtr  = (volatile unsigned long*) (DmaMmrOffset + UART0_TXDMA_DSCPTR_NXT);
    volatile unsigned long *pDmaStartAddr    = (volatile unsigned long*) (DmaMmrOffset + UART0_TXDMA_ADDRSTART);
    volatile unsigned long *pDmaConfig       = (volatile unsigned long*) (DmaMmrOffset + UART0_TXDMA_CFG);
    volatile unsigned long *pDmaXCount       = (volatile unsigned long*) (DmaMmrOffset + UART0_TXDMA_XCNT);
    volatile unsigned long *pDmaXModify      = (volatile unsigned long*) (DmaMmrOffset + UART0_TXDMA_XMOD);
    volatile unsigned long *pDmaYCount       = (volatile unsigned long*) (DmaMmrOffset + UART0_TXDMA_YCNT);
    volatile unsigned long *pDmaYModify      = (volatile unsigned long*) (DmaMmrOffset + UART0_TXDMA_YMOD);
    volatile unsigned long *pDmaCurrDescPtr  = (volatile unsigned long*) (DmaMmrOffset + UART0_TXDMA_DSCPTR_CUR);
    volatile unsigned long *pDmaCurrDescPrv  = (volatile unsigned long*) (DmaMmrOffset + UART0_TXDMA_DSCPTR_PRV);
    volatile unsigned long *pDmaCurrAddr     = (volatile unsigned long*) (DmaMmrOffset + UART0_TXDMA_ADDR_CUR);
    volatile unsigned long *pDmaIrqStatus    = (volatile unsigned long*) (DmaMmrOffset + UART0_TXDMA_STAT);
    volatile unsigned long *pDmaCurrXCount   = (volatile unsigned long*) (DmaMmrOffset + UART0_TXDMA_XCNT_CUR);
    volatile unsigned long *pDmaCurrYCount   = (volatile unsigned long*) (DmaMmrOffset + UART0_TXDMA_YCNT_CUR);
    volatile unsigned long *pDmaBwlCount     = (volatile unsigned long*) (DmaMmrOffset + UART0_TXDMA_BWLCNT);
    volatile unsigned long *pDmaBwlCurrCount = (volatile unsigned long*) (DmaMmrOffset + UART0_TXDMA_BWLCNT_CUR);
    volatile unsigned long *pDmaBwmCount     = (volatile unsigned long*) (DmaMmrOffset + UART0_TXDMA_BWMCNT);
    volatile unsigned long *pDmaBwmCurrCount = (volatile unsigned long*) (DmaMmrOffset + UART0_TXDMA_BWMCNT_CUR);

    *pDmaConfig         = 0;
    *pDmaNextDescPtr    = 0;
    *pDmaStartAddr      = 0xFF804000;
    *pDmaXCount         = 0;
    *pDmaXModify        = 1;
    *pDmaYCount         = 0;
    *pDmaYModify        = 0;
    *pDmaCurrDescPtr    = 0;
    *pDmaCurrAddr       = 0;
    *pDmaIrqStatus      = (BITM_DMA_STAT_IRQDONE | BITM_DMA_STAT_IRQERR | BITM_DMA_STAT_PIRQ);
    *pDmaCurrXCount     = 0;
    *pDmaCurrYCount     = 0;
    *pDmaBwlCount       = 0;
    *pDmaBwlCurrCount   = 0;
    *pDmaBwmCount       = 0;
    *pDmaBwmCurrCount   = 0;

    ssync();

    return 0;
}


//***************************************
//*
//* Function Name : UartWaitForTransferCompletion
//* Description   : Waits for TEMT bit set in UART LSR register
//*
//* Parameters    : UART number
//* Returns       : If the UartWaitForTransferCompletion function is unsuccessful, a negative value is returned.
//* Globals       : none
//*
short UartWaitForTransferCompletion(unsigned char UartNum)
{
    unsigned short UartMmrOffset = 0;

    switch (UartNum) {
        case 0: UartMmrOffset = UART0_MMR_OFFSET; break;
        case 1: UartMmrOffset = UART1_MMR_OFFSET; break;
        default: printf("%s(): UART%d is not available.\n",__func__,UartNum); return -1;
    }

    volatile unsigned long *pUartStat = (volatile unsigned long*) (UartMmrOffset + REG_UART0_STAT);

//    while (!(*pUartStat & BITM_UART_STAT_THRE)) { /* wait */ }
    while (!(*pUartStat & BITM_UART_STAT_TEMT)) { /* wait */ }
    *pUartStat = BITM_UART_STAT_TFI;

    return 0;
}


//***************************************
//*
//* Function Name : UartDmaWaitForTransmitCompletion
//* Description   : This functions makes sure that a current DMA
//*                 transfer is completed by polling several status bits.
//*                 For the initial transfer, a global variable is required.
//*
//* Parameters    : UART Number, Direction (0 - Memory Read / TX, 1 - Memory Write / RX)
//* Returns       : If the UartDmaWaitForTransmitCompletion function is unsuccessful, a negative value is returned.
//* Globals       : none
//*
short UartDmaWaitForTransmitCompletion(unsigned char UartNum, bool Dir)
{
    unsigned short UartMmrOffset = 0;
    unsigned  long DmaMmrOffset  = (UartNum | (Dir << 4));

    switch (DmaMmrOffset) {
        case 0x00: DmaMmrOffset = UART0_TXDMA_DSCPTR_NXT - UART0_TXDMA_DSCPTR_NXT; UartMmrOffset = UART0_MMR_OFFSET; break; // DMA17 UART0 TX
        case 0x01: DmaMmrOffset = UART0_RXDMA_DSCPTR_NXT - UART0_TXDMA_DSCPTR_NXT; UartMmrOffset = UART0_MMR_OFFSET; break; // DMA18 UART0 RX
        case 0x10: DmaMmrOffset = UART1_TXDMA_DSCPTR_NXT - UART0_TXDMA_DSCPTR_NXT; UartMmrOffset = UART1_MMR_OFFSET; break; // DMA19 UART1 TX
        case 0x11: DmaMmrOffset = UART1_RXDMA_DSCPTR_NXT - UART0_TXDMA_DSCPTR_NXT; UartMmrOffset = UART1_MMR_OFFSET; break; // DMA20 UART1 RX
        default: printf("%s(): UART%d unavailable and/or direction wrong.\n",__func__,UartNum); return -1;
    }

    volatile unsigned long *pDmaConfig    = (volatile unsigned long*) (DmaMmrOffset  + UART0_TXDMA_CFG);
    volatile unsigned long *pDmaIrqStatus = (volatile unsigned long*) (DmaMmrOffset  + UART0_TXDMA_STAT);
    volatile unsigned long *pUartStat     = (volatile unsigned long*) (UartMmrOffset + REG_UART0_STAT);

    ssync();

    if (*pDmaConfig & BITM_DMA_CFG_EN) {
        while((*pDmaIrqStatus & BITM_DMA_STAT_RUN) != 0)   { /* wait */ }
        while(!(*pDmaIrqStatus & BITM_DMA_STAT_IRQDONE)) { /* if ((*pDmaIrqStatus & BITM_DMA_STAT_RUN) == 0) break; */ }
        *pDmaIrqStatus = BITM_DMA_STAT_IRQDONE;
    }

    while(!(*pUartStat & BITM_UART_STAT_TEMT)) { /* wait */ }

    *pUartStat = BITM_UART_STAT_TFI;

    ssync();

    return 0;
}


//***************************************
//*
//* Function Name : UartDmaWaitForDmaDone
//* Description   : This functions makes sure that a current DMA transmission (memory read)
//*                 is completed (DMA_DONE set).
//*                 DMA_DONE is cleared.
//*
//* Parameters    : UART Number, Direction (0 - Memory Read / TX, 1 - Memory Write / RX)
//* Returns       : NULL. If the UartDmaWaitForDmaDone function is unsuccessful, a negative value is returned.
//* Globals       : none
//*
short UartDmaWaitForDmaDone(unsigned char UartNum, bool Dir)
{
    unsigned short UartMmrOffset = 0;
    unsigned  long DmaMmrOffset  = (UartNum | (Dir << 4));

    switch (DmaMmrOffset) {
        case 0x00: DmaMmrOffset = UART0_TXDMA_DSCPTR_NXT - UART0_TXDMA_DSCPTR_NXT; UartMmrOffset = UART0_MMR_OFFSET; break; // DMA17 UART0 TX
        case 0x01: DmaMmrOffset = UART0_RXDMA_DSCPTR_NXT - UART0_TXDMA_DSCPTR_NXT; UartMmrOffset = UART0_MMR_OFFSET; break; // DMA18 UART0 RX
        case 0x10: DmaMmrOffset = UART1_TXDMA_DSCPTR_NXT - UART0_TXDMA_DSCPTR_NXT; UartMmrOffset = UART1_MMR_OFFSET; break; // DMA19 UART1 TX
        case 0x11: DmaMmrOffset = UART1_RXDMA_DSCPTR_NXT - UART0_TXDMA_DSCPTR_NXT; UartMmrOffset = UART1_MMR_OFFSET; break; // DMA20 UART1 RX
        default: printf("%s(): UART%d unavailable and/or direction wrong.\n",__func__,UartNum); return -1;
    }

    volatile unsigned long *pDmaConfig    = (volatile unsigned long*) (DmaMmrOffset + UART0_TXDMA_CFG);
    volatile unsigned long *pDmaIrqStatus = (volatile unsigned long*) (DmaMmrOffset + UART0_TXDMA_STAT);

    ssync();

    if (*pDmaConfig & BITM_DMA_CFG_EN) {
        while(!(*pDmaIrqStatus & BITM_DMA_STAT_IRQDONE)) { /* if (!(*pDmaIrqStatus & BITM_DMA_STAT_RUN)) break; */ }
        *pDmaIrqStatus = BITM_DMA_STAT_IRQDONE;
    }

    ssync();

    return 0;
}


//***************************************
//*
//* Function Name : UartPutc
//* Description   : This function transmits a character
//*                 by polling THRE bit in the LSR register.
//*
//* Parameters    : UART number, the character to transmit
//* Returns       : if the UartPutc function is unsuccessful, a negative value is returned.
//* Globals       : none
//*
short UartPutc(unsigned char UartNum, char c)
{
    unsigned short UartMmrOffset = 0;

    switch (UartNum) {
        case 0: UartMmrOffset = UART0_MMR_OFFSET; break;
        case 1: UartMmrOffset = UART1_MMR_OFFSET; break;
        default: printf("%s(): UART%d is not available.\n",__func__,UartNum); return -1;
    }

    volatile unsigned long *pUartStat = (volatile unsigned long*) (UartMmrOffset + REG_UART0_STAT);
    volatile unsigned long *pUartThr  = (volatile unsigned long*) (UartMmrOffset + REG_UART0_THR);

#if (FLOWCONTROL == 1)
    while (!(*pUartStat & BITM_UART_STAT_CTS)) { /* wait */ }
#endif

    while (!(*pUartStat & BITM_UART_STAT_THRE)) { /* wait */ }
    *pUartThr = c;

#if (LOOP == 1)
    unsigned short dummy;
    dummy = UartGetc(UartNum);
#endif

    return 0;
}


//***************************************
//*
//* Function Name : UartPuts
//* Description   : This function transmits a byte string
//*                 by polling THRE bit in the LSR register.
//*                 The string must be NULL-terminated (C-style).
//*                 A newline / carriage return character will terminate the transfer as well.
//*
//* Parameters    : UART number, pointer to the string to transmit
//* Returns       : if the UartPuts function is unsuccessful, a negative value is returned.
//* Globals       : none
//*
short UartPuts(unsigned char UartNum, char *c)
{
    while (*c) {
        UartPutc(UartNum, *c);
#if(0) // This is taken care by uprintf
        if (*c == '\n') { // 0x0A = newline?
            UartPutc(UartNum, '\r'); // 0x0D = insert carriage return
            return 0;
            }
        else if (*c == '\r') { // 0x0D = carriage return?
            UartPutc(UartNum, '\n'); // 0x0A = insert newline
            return 0;
            }
        else { c++; }
#else
        c++;
#endif
        }

    return 0;
}


//***************************************
//*
//* Function Name : UartPutsn
//* Description   : This function transmits a byte string of length NumChar.
//*
//* Parameters    : UART number, pointer to the string to transmit, number of characters
//* Returns       : NULL. If the UartPutsn function is unsuccessful, a negative value is returned.
//* Globals       : none
//*
short UartPutsn(unsigned char UartNum, char *c, unsigned long NumChar)
{
    unsigned long i;
    short status = 0;

    if (NumChar < 1) { return -1; }

    for ( i = 0; i < NumChar ; i++ ) { status = UartPutc(UartNum, c[i]); if (status < 0) { return status; } }

    return 0;
}


//***************************************
//*
//* Function Name : UartDmaPuts
//* Description   : This function transmits a byte string by DMA.
//*                 The string must be NULL-terminated (C-style).
//*
//* Parameters    : UART number, DMA channel, pointer to the string to transmit
//* Returns       : if the UartDmaPuts function is unsuccessful, a negative value is returned.
//* Globals       : none
//*
short UartDmaPuts(unsigned char UartNum, char *c)
{
    unsigned short UartMmrOffset = 0;
    unsigned short DmaMmrOffset  = 0;
    unsigned  char i=0, j=0;

    switch (UartNum) {
        case 0: UartMmrOffset = UART0_MMR_OFFSET; DmaMmrOffset = UART0_TXDMA_DSCPTR_NXT - UART0_TXDMA_DSCPTR_NXT; break; // DMA17 UART0 TX
        case 1: UartMmrOffset = UART1_MMR_OFFSET; DmaMmrOffset = UART1_TXDMA_DSCPTR_NXT - UART0_TXDMA_DSCPTR_NXT; break; // DMA19 UART1 TX
        default: printf("%s(): UART%d is not available.\n",__func__,UartNum); return -1;
    }

    volatile unsigned long *pDmaStartAddr = (volatile unsigned long*) (DmaMmrOffset  + UART0_TXDMA_ADDRSTART);
    volatile unsigned long *pDmaConfig    = (volatile unsigned long*) (DmaMmrOffset  + UART0_TXDMA_CFG);
    volatile unsigned long *pDmaXCount    = (volatile unsigned long*) (DmaMmrOffset  + UART0_TXDMA_XCNT);
    volatile unsigned long *pDmaXModify   = (volatile unsigned long*) (DmaMmrOffset  + UART0_TXDMA_XMOD);
    volatile unsigned long *pUartImskSet  = (volatile unsigned long*) (UartMmrOffset + REG_UART0_IMSK_SET);
    volatile unsigned long *pUartImskClr  = (volatile unsigned long*) (UartMmrOffset + REG_UART0_IMSK_CLR);

    unsigned short NumChar     = strlen(c);
    unsigned  long SrcAddr     = (unsigned long) c;
    unsigned  long TmpAddr     = SrcAddr | NumChar;
    unsigned  long DmaXCount   = 0;
    unsigned  long DmaXMod     = 0;
    unsigned  long DmaCfgMsize = 0; // 0=1byte; 1=2byte; 2=4byte; 3=8byte; 4=16byte; 5=32byte
    unsigned  long DmaCfgPsize = 0; // 0=8-bit; 1=16-bit; 2=32-bit; 3=64-bit

    // first calculate MSIZE according to StartAddr and NumChar
    for (i=32, j=5; i!=0; i>>=1, j--) {
        if (!(TmpAddr%i)) { DmaCfgMsize = j; break; }
    }

    // calculate XCNT and XMOD according to MSIZE
    DmaXCount = (NumChar>>DmaCfgMsize);
    DmaXMod   = (1<<DmaCfgMsize);

    // PSIZE according to NumChar
    for (i=4, j=2; i!=0; i>>=1, j--) {
        if (!(NumChar%i)) { DmaCfgPsize = j; break; }
    }

    // PSIZE = 0 for UART interface
    DmaCfgPsize = 0;

    DmaCfgMsize <<= BITP_DMA_CFG_MSIZE;
    DmaCfgPsize <<= BITP_DMA_CFG_PSIZE;

    *pUartImskClr  = BITM_UART_IMSK_ETBEI;
    *pDmaStartAddr = SrcAddr;
    *pDmaXCount    = DmaXCount;
    *pDmaXModify   = DmaXMod; // In 1D DMA, this increment is the stride that is applied after each DMA_CFG.MSIZE size data transfer.
    *pDmaConfig    = (DmaCfgMsize|DmaCfgPsize|UART_DMA_CONFIG_VAL|BITM_DMA_CFG_EN);
    *pUartImskSet  = BITM_UART_IMSK_ETBEI;

    return 0;
}


//***************************************
//*
//* Function Name : UartDmaPutsn
//* Description   : This function transmits a byte string by DMA of length NumChar
//*
//* Parameters    : UART number, pointer to the string to transmit, number of characters
//* Returns       : NULL. If the UartDmaPutsn function is unsuccessful, a negative value is returned.
//* Globals       : none
//*
short UartDmaPutsn(unsigned char UartNum, char *c, unsigned short NumChar)
{
    unsigned short UartMmrOffset = 0;
    unsigned short DmaMmrOffset  = 0;
    unsigned  char i=0, j=0;

    switch (UartNum) {
        case 0: UartMmrOffset = UART0_MMR_OFFSET; DmaMmrOffset = UART0_TXDMA_DSCPTR_NXT - UART0_TXDMA_DSCPTR_NXT; break; // DMA17 UART0 TX
        case 1: UartMmrOffset = UART1_MMR_OFFSET; DmaMmrOffset = UART1_TXDMA_DSCPTR_NXT - UART0_TXDMA_DSCPTR_NXT; break; // DMA19 UART1 TX
        default: printf("%s(): UART%d is not available.\n",__func__,UartNum); return -1;
    }

    volatile unsigned long *pDmaStartAddr = (volatile unsigned long*) (DmaMmrOffset  + UART0_TXDMA_ADDRSTART);
    volatile unsigned long *pDmaConfig    = (volatile unsigned long*) (DmaMmrOffset  + UART0_TXDMA_CFG);
    volatile unsigned long *pDmaXCount    = (volatile unsigned long*) (DmaMmrOffset  + UART0_TXDMA_XCNT);
    volatile unsigned long *pDmaXModify   = (volatile unsigned long*) (DmaMmrOffset  + UART0_TXDMA_XMOD);
    volatile unsigned long *pUartImskSet  = (volatile unsigned long*) (UartMmrOffset + REG_UART0_IMSK_SET);
    volatile unsigned long *pUartImskClr  = (volatile unsigned long*) (UartMmrOffset + REG_UART0_IMSK_CLR);

    unsigned  long SrcAddr     = (unsigned long) c;
    unsigned  long TmpAddr     = SrcAddr | NumChar;
    unsigned  long DmaXCount   = 0;
    unsigned  long DmaXMod     = 0;
    unsigned  long DmaCfgMsize = 0; // 0=1byte; 1=2byte; 2=4byte; 3=8byte; 4=16byte; 5=32byte
    unsigned  long DmaCfgPsize = 0; // 0=8-bit; 1=16-bit; 2=32-bit; 3=64-bit

    // first calculate MSIZE according to StartAddr and NumChar
    for (i=32, j=5; i!=0; i>>=1, j--) {
        if (!(TmpAddr%i)) { DmaCfgMsize = j; break; }
    }

    // calculate XCNT and XMOD according to MSIZE
    DmaXCount = (NumChar>>DmaCfgMsize);
    DmaXMod   = (1<<DmaCfgMsize);

    // calculate PSIZE according to NumChar
    for (i=4, j=2; i!=0; i>>=1, j--) {
        if (!(NumChar%i)) { DmaCfgPsize = j; break; }
    }

    // PSIZE = 0 for UART interface
    DmaCfgPsize = 0;

    DmaCfgMsize <<= BITP_DMA_CFG_MSIZE;
    DmaCfgPsize <<= BITP_DMA_CFG_PSIZE;

    *pUartImskClr  = BITM_UART_IMSK_ETBEI;
    *pDmaStartAddr = SrcAddr;
    *pDmaXCount    = DmaXCount;
    *pDmaXModify   = DmaXMod; // In 1D DMA, this increment is the stride that is applied after each DMA_CFG.MSIZE size data transfer.
    *pDmaConfig    = (DmaCfgMsize|DmaCfgPsize|UART_DMA_CONFIG_VAL|BITM_DMA_CFG_EN);
    *pUartImskSet  = BITM_UART_IMSK_ETBEI;

    return 0;
}


//***************************************
//*
//* Function Name : UartDmaGetsn
//* Description   : This function transmits a byte string by DMA of length NumChar
//*
//* Parameters    : UART number, pointer to the string to transmit, number of characters
//* Returns       : NULL. If the UartDmaGetsn function is unsuccessful, a negative value is returned.
//* Globals       : none
//*
short UartDmaGetsn(unsigned char UartNum, char *c, unsigned short NumChar)
{
    unsigned short UartMmrOffset = 0;
    unsigned short DmaMmrOffset  = 0;
    unsigned  char i=0, j=0;

    switch (UartNum) {
        case 0: UartMmrOffset = UART0_MMR_OFFSET; DmaMmrOffset = UART0_RXDMA_DSCPTR_NXT - UART0_TXDMA_DSCPTR_NXT; break; // DMA17 UART0 TX
        case 1: UartMmrOffset = UART1_MMR_OFFSET; DmaMmrOffset = UART1_RXDMA_DSCPTR_NXT - UART0_TXDMA_DSCPTR_NXT; break; // DMA19 UART1 TX
        default: printf("%s(): UART%d is not available.\n",__func__,UartNum); return -1;
    }

    volatile unsigned long *pDmaStartAddr = (volatile unsigned long*) (DmaMmrOffset  + UART0_TXDMA_ADDRSTART);
    volatile unsigned long *pDmaConfig    = (volatile unsigned long*) (DmaMmrOffset  + UART0_TXDMA_CFG);
    volatile unsigned long *pDmaXCount    = (volatile unsigned long*) (DmaMmrOffset  + UART0_TXDMA_XCNT);
    volatile unsigned long *pDmaXModify   = (volatile unsigned long*) (DmaMmrOffset  + UART0_TXDMA_XMOD);
    volatile unsigned long *pUartImskSet  = (volatile unsigned long*) (UartMmrOffset + REG_UART0_IMSK_SET);
    volatile unsigned long *pUartImskClr  = (volatile unsigned long*) (UartMmrOffset + REG_UART0_IMSK_CLR);

    // first calculate MSIZE according to StartAddr and NumChar
    unsigned  long SrcAddr     = (unsigned long) c;
    unsigned  long TmpAddr     = SrcAddr | NumChar;
    unsigned  long DmaXCount   = 0;
    unsigned  long DmaXMod     = 0;
    unsigned  long DmaCfgMsize = 0; // 0=1byte; 1=2byte; 2=4byte; 3=8byte; 4=16byte; 5=32byte
    unsigned  long DmaCfgPsize = 0; // 0=8-bit; 1=16-bit; 2=32-bit; 3=64-bit

    for (i=32, j=5; i!=0; i>>=1, j--) {
        if (!(TmpAddr%i)) { DmaCfgMsize = j; break; }
    }

    // calculate XCNT and XMOD according to MSIZE
    DmaXCount = (NumChar>>DmaCfgMsize);
    DmaXMod   = (1<<DmaCfgMsize);

    // calculate PSIZE according to NumChar
    for (i=4, j=2; i!=0; i>>=1, j--) {
        if (!(NumChar%i)) { DmaCfgPsize = j; break; }
    }

    // PSIZE = 0 for UART interface
    DmaCfgPsize = 0;

    DmaCfgMsize <<= BITP_DMA_CFG_MSIZE;
    DmaCfgPsize <<= BITP_DMA_CFG_PSIZE;

    *pUartImskClr  = BITM_UART_IMSK_ERBFI;
    *pDmaStartAddr = SrcAddr;
    *pDmaXCount    = DmaXCount;
    *pDmaXModify   = DmaXMod; // In 1D DMA, this increment is the stride that is applied after each DMA_CFG.MSIZE size data transfer.
    *pDmaConfig    = (DmaCfgMsize|DmaCfgPsize|UART_DMA_CONFIG_VAL|BITM_DMA_CFG_WNR|BITM_DMA_CFG_EN);
    *pUartImskSet  = BITM_UART_IMSK_ERBFI;

    return 0;
}


//***************************************
//*
//* Function Name : UartClockEnable
//* Description   : This function (re-)enables the UART clock
//*
//* Parameters    : UART number
//* Returns       : if the UartClockEnable function is unsuccessful, a negative value is returned.
//* Globals       : none
//*
short UartClockEnable(unsigned char UartNum)
{
    unsigned short UartMmrOffset = 0;

    switch (UartNum) {
        case 0: UartMmrOffset = UART0_MMR_OFFSET; break;
        case 1: UartMmrOffset = UART1_MMR_OFFSET; break;
        default: printf("%s(): UART%d is not available.\n",__func__,UartNum); return -1;
    }

    volatile unsigned long *pUartCtl = (volatile unsigned long*) (UartMmrOffset + REG_UART0_CTL);

    ssync();

    *pUartCtl |= BITM_UART_CTL_EN;

    return 0;
}


//***************************************
//*
//* Function Name : UartClockDisable
//* Description   : This function disables the UART clock
//*
//* Parameters    : UART number
//* Returns       : if the UartClockDisable function is unsuccessful, a negative value is returned.
//* Globals       : none
//*
short UartClockDisable(unsigned char UartNum)
{
    unsigned short UartMmrOffset = 0;

    switch (UartNum) {
        case 0: UartMmrOffset = UART0_MMR_OFFSET; break;
        case 1: UartMmrOffset = UART1_MMR_OFFSET; break;
        default: printf("%s(): UART%d is not available.\n",__func__,UartNum); return -1;
    }

    volatile unsigned long *pUartCtl = (volatile unsigned long*) (UartMmrOffset + REG_UART0_CTL);

    UartWaitForTransferCompletion(UartNum);

    *pUartCtl &= ~BITM_UART_CTL_EN;

    return 0;
}


//***************************************
//*
//* Function Name : UartTxOn
//* Description   : This function disables the UART clock
//*
//* Parameters    : UART number
//* Returns       : if the UartTxOn function is unsuccessful, a negative value is returned.
//* Globals       : none
//*
short UartTxOn(unsigned char UartNum)
{
    unsigned short UartMmrOffset = 0;

    switch (UartNum) {
        case 0: UartMmrOffset = UART0_MMR_OFFSET; break;
        case 1: UartMmrOffset = UART1_MMR_OFFSET; break;
        default: printf("%s(): UART%d is not available.\n",__func__,UartNum); return -1;
    }

    volatile unsigned long *pUartCtl = (volatile unsigned long*) (UartMmrOffset + REG_UART0_CTL);

    *pUartCtl |= BITM_UART_CTL_XOFF;

    return 0;
}


//***************************************
//*
//* Function Name : UartTxOff
//* Description   : This function disables the UART clock
//*
//* Parameters    : UART number
//* Returns       : if the UartTxOff function is unsuccessful, a negative value is returned.
//* Globals       : none
//*
short UartTxOff(unsigned char UartNum)
{
    unsigned short UartMmrOffset = 0;

    switch (UartNum) {
        case 0: UartMmrOffset = UART0_MMR_OFFSET; break;
        case 1: UartMmrOffset = UART1_MMR_OFFSET; break;
        default: printf("%s(): UART%d is not available.\n",__func__,UartNum); return -1;
    }

    volatile unsigned long *pUartCtl = (volatile unsigned long*) (UartMmrOffset + REG_UART0_CTL);

    *pUartCtl &= ~BITM_UART_CTL_XOFF;

    return 0;
}


//***************************************
//*
//* Function Name : UartSetBreak
//* Description   : This function disables the UART clock
//*
//* Parameters    : UART number
//* Returns       : if the UartSetBreak function is unsuccessful, a negative value is returned.
//* Globals       : none
//*
short UartSetBreak(unsigned char UartNum)
{
    unsigned short UartMmrOffset = 0;

    switch (UartNum) {
        case 0: UartMmrOffset = UART0_MMR_OFFSET; break;
        case 1: UartMmrOffset = UART1_MMR_OFFSET; break;
        default: printf("%s(): UART%d is not available.\n",__func__,UartNum); return -1;
    }

    volatile unsigned long *pUartCtl = (volatile unsigned long*) (UartMmrOffset + REG_UART0_CTL);

    *pUartCtl |= BITM_UART_CTL_SB;

    return 0;
}


//***************************************
//*
//* Function Name : UartClrBreak
//* Description   : This function disables the UART clock
//*
//* Parameters    : UART number
//* Returns       : if the UartClrBreak function is unsuccessful, a negative value is returned.
//* Globals       : none
//*
short UartClrBreak(unsigned char UartNum)
{
    unsigned short UartMmrOffset = 0;

    switch (UartNum) {
        case 0: UartMmrOffset = UART0_MMR_OFFSET; break;
        case 1: UartMmrOffset = UART1_MMR_OFFSET; break;
        default: printf("%s(): UART%d is not available.\n",__func__,UartNum); return -1;
    }

    volatile unsigned long *pUartCtl = (volatile unsigned long*) (UartMmrOffset + REG_UART0_CTL);

    *pUartCtl &= ~BITM_UART_CTL_SB;

    return 0;
}


//***************************************
//*
//* Function Name : UartSetFfe
//* Description   : This function disables the UART clock
//*
//* Parameters    : UART number
//* Returns       : if the UartSetFfe function is unsuccessful, a negative value is returned.
//* Globals       : none
//*
short UartSetFfe(unsigned char UartNum)
{
    unsigned short UartMmrOffset = 0;

    switch (UartNum) {
        case 0: UartMmrOffset = UART0_MMR_OFFSET; break;
        case 1: UartMmrOffset = UART1_MMR_OFFSET; break;
        default: printf("%s(): UART%d is not available.\n",__func__,UartNum); return -1;
    }

    volatile unsigned long *pUartCtl = (volatile unsigned long*) (UartMmrOffset + REG_UART0_CTL);

    *pUartCtl |= BITM_UART_CTL_FFE;

    return 0;
}


//***************************************
//*
//* Function Name : UartClrFfe
//* Description   : This function disables the UART clock
//*
//* Parameters    : UART number
//* Returns       : if the UartClrFfe function is unsuccessful, a negative value is returned.
//* Globals       : none
//*
short UartClrFfe(unsigned char UartNum)
{
    unsigned short UartMmrOffset = 0;

    switch (UartNum) {
        case 0: UartMmrOffset = UART0_MMR_OFFSET; break;
        case 1: UartMmrOffset = UART1_MMR_OFFSET; break;
        default: printf("%s(): UART%d is not available.\n",__func__,UartNum); return -1;
    }

    volatile unsigned long *pUartCtl = (volatile unsigned long*) (UartMmrOffset + REG_UART0_CTL);

    *pUartCtl &= ~BITM_UART_CTL_FFE;

    return 0;
}


//***************************************
//*
//* Function Name : UartSetFpe
//* Description   : This function disables the UART clock
//*
//* Parameters    : UART number
//* Returns       : if the UartSetFpe function is unsuccessful, a negative value is returned.
//* Globals       : none
//*
short UartSetFpe(unsigned char UartNum)
{
    unsigned short UartMmrOffset = 0;

    switch (UartNum) {
        case 0: UartMmrOffset = UART0_MMR_OFFSET; break;
        case 1: UartMmrOffset = UART1_MMR_OFFSET; break;
        default: printf("%s(): UART%d is not available.\n",__func__,UartNum); return -1;
    }

    volatile unsigned long *pUartCtl = (volatile unsigned long*) (UartMmrOffset + REG_UART0_CTL);

    *pUartCtl |= BITM_UART_CTL_FPE;

    return 0;
}


//***************************************
//*
//* Function Name : UartClrFpe
//* Description   : This function disables the UART clock
//*
//* Parameters    : UART number
//* Returns       : if the UartClrFpe function is unsuccessful, a negative value is returned.
//* Globals       : none
//*
short UartClrFpe(unsigned char UartNum)
{
    unsigned short UartMmrOffset = 0;

    switch (UartNum) {
        case 0: UartMmrOffset = UART0_MMR_OFFSET; break;
        case 1: UartMmrOffset = UART1_MMR_OFFSET; break;
        default: printf("%s(): UART%d is not available.\n",__func__,UartNum); return -1;
    }

    volatile unsigned long *pUartCtl = (volatile unsigned long*) (UartMmrOffset + REG_UART0_CTL);

    *pUartCtl &= ~BITM_UART_CTL_FPE;

    return 0;
}


//***************************************
//*
//* Function Name : UartDmaBreak
//* Description   : This function breaks an ongoing UART-DMA transmission.
//*
//* Parameters    : UART Number, Direction (0 - Memory Read / TX, 1 - Memory Write / RX)
//* Returns       : NULL. If the UartDmaBreak function is unsuccessful, a negative value is returned.
//* Globals       : none
//*
short UartDmaBreak(unsigned char UartNum, bool Dir)
{
    unsigned short UartMmrOffset = 0;

    switch (UartNum) {
        case 0: UartMmrOffset = UART0_MMR_OFFSET; break;
        case 1: UartMmrOffset = UART1_MMR_OFFSET; break;
        default: printf("%s(): UART%d is not available.\n",__func__,UartNum); return -1;
    }

    volatile unsigned long *pUartImskClr  = (volatile unsigned long*) (UartMmrOffset + REG_UART0_IMSK_CLR);

    switch (Dir) {
        case 0: *pUartImskClr = BITM_UART_IMSK_ETBEI; break;
        case 1: *pUartImskClr = BITM_UART_IMSK_ERBFI; break;
        default: printf("%s(): Direction (%d) wrong.\n",__func__,Dir); return -1;
    }

    return 0;
}


//***************************************
//*
//* Function Name : UartDmaResume
//* Description   : This function resumes/continues an interrupted UART-DMA transmission.
//*
//* Parameters    : UART Number, Direction (0 - Memory Read / TX, 1 - Memory Write / RX)
//* Returns       : NULL. If the UartDmaResume function is unsuccessful, a negative value is returned.
//* Globals       : none
//*
short UartDmaResume(unsigned char UartNum, bool Dir)
{
    unsigned short UartMmrOffset = 0;

    switch (UartNum) {
        case 0: UartMmrOffset = UART0_MMR_OFFSET; break;
        case 1: UartMmrOffset = UART1_MMR_OFFSET; break;
        default: printf("%s(): UART%d is not available.\n",__func__,UartNum); return -1;
    }

    volatile unsigned long *pUartImskSet  = (volatile unsigned long*) (UartMmrOffset + REG_UART0_IMSK_SET);

    switch (Dir) {
        case 0: *pUartImskSet = BITM_UART_IMSK_ETBEI; break;
        case 1: *pUartImskSet = BITM_UART_IMSK_ERBFI; break;
        default: printf("%s(): Direction (%d) wrong.\n",__func__,Dir); return -1;
    }

    return 0;
}


//***************************************
//*
//* Function Name : UartDmaDisable
//* Description   : This function disables the UART clock and DMA,
//*                 but polls the TEMT bit and DMA Status before
//*
//* Parameters    : UART Number, Direction (0 - Memory Read / TX, 1 - Memory Write / RX)
//* Returns       : if the UartDmaDisable function is unsuccessful, a negative value is returned.
//* Globals       : none
//*
short UartDmaDisable(unsigned char UartNum, bool Dir)
{
    unsigned short UartMmrOffset = 0;
    unsigned  long DmaMmrOffset  = (UartNum | (Dir << 4));

    switch (DmaMmrOffset) {
        case 0x00: DmaMmrOffset = UART0_TXDMA_DSCPTR_NXT - UART0_TXDMA_DSCPTR_NXT; UartMmrOffset = UART0_MMR_OFFSET; break; // DMA17 UART0 TX
        case 0x01: DmaMmrOffset = UART0_RXDMA_DSCPTR_NXT - UART0_TXDMA_DSCPTR_NXT; UartMmrOffset = UART0_MMR_OFFSET; break; // DMA18 UART0 RX
        case 0x10: DmaMmrOffset = UART1_TXDMA_DSCPTR_NXT - UART0_TXDMA_DSCPTR_NXT; UartMmrOffset = UART1_MMR_OFFSET; break; // DMA19 UART1 TX
        case 0x11: DmaMmrOffset = UART1_RXDMA_DSCPTR_NXT - UART0_TXDMA_DSCPTR_NXT; UartMmrOffset = UART1_MMR_OFFSET; break; // DMA20 UART1 RX
        default: printf("%s(): UART%d unavailable and/or direction wrong.\n",__func__,UartNum); return -1;
    }

    volatile unsigned long *pDmaConfig    = (volatile unsigned long*) (DmaMmrOffset + UART0_TXDMA_CFG);
    volatile unsigned long *pDmaIrqStatus = (volatile unsigned long*) (DmaMmrOffset + UART0_TXDMA_STAT);

    ssync();

//    UartDmaWaitForTransmitCompletion(UartNum,DmaChan);
    while((*pDmaIrqStatus & BITM_DMA_STAT_RUN) != 0) { /* wait */ }

    *pDmaConfig &= ~BITM_DMA_CFG_EN;

    return 0;
}


//***************************************
//*
//* Function Name : UartGetc
//* Description   : This function receives a character
//*                 by polling the DR bit in the LSR register.
//*
//* Parameters    : UART number
//* Returns       : character received from the RBR. if the UartGetc function is unsuccessful, a negative value is returned.
//* Globals       : none
//*
char UartGetc(unsigned char UartNum)
{
    unsigned short UartMmrOffset = 0;

    switch (UartNum) {
        case 0: UartMmrOffset = UART0_MMR_OFFSET; break;
        case 1: UartMmrOffset = UART1_MMR_OFFSET; break;
        default: printf("%s(): UART%d is not available.\n",__func__,UartNum); return -1;
    }

    volatile unsigned long *pUartStat = (volatile unsigned long*) (UartMmrOffset + REG_UART0_STAT);
    volatile unsigned long *pUartRbr  = (volatile unsigned long*) (UartMmrOffset + REG_UART0_RBR);

    char c;

    while (!(*pUartStat & BITM_UART_STAT_DR)) { /* wait */}

    // read Data
    c = *pUartRbr;

    return c;
}


//***************************************
//*
//* Function Name : UartGets
//* Description   : This function receives a string and is terminated,
//*                 when a newline or carriage return character is detected or receive buffer is full
//*
//* Parameters    : UART number, pointer to the string
//* Returns       : if the UartGets function is unsuccessful, a negative value is returned.
//* Globals       : none
//*
short UartGets(unsigned char UartNum, char *c)
{
    unsigned short i;

    for(i = 0; i < STRINGSIZE; i++) {
        c[i] = UartGetc(UartNum);
//        if (c[i] == -1) { return -1; }
        MSG(2,"%c",c[i]);
        if ((c[i] == '\n')||(c[i] == '\r')) { break; }
        }

    return 0;
}


//***************************************
//*
//* Function Name : UartGetsn
//* Description   : This function receives a byte string of length NumChar
//*
//* Parameters    : UART number, pointer to the string, number of characters
//* Returns       : NULL. If the UartGetsn function is unsuccessful, a negative value is returned.
//* Globals       : none
//*
short UartGetsn(unsigned char UartNum, char *c, unsigned long NumChar)
{
    unsigned short i;

    if (NumChar < 1) { return -1; }
    if (STRINGSIZE < NumChar) { return -1; }

    for(i = 0; i < NumChar; i++) { c[i] = UartGetc(UartNum); }

    return 0;
}


//***************************************
//*
//* Function Name : UartGetsEcho
//* Description   : This function receives a string and is terminated,
//*                 when a newline or carriage return character is detected
//*                 or receive buffer is full and echoes each received characters individually
//*
//* Parameters    : UART number, pointer to the string
//* Returns       : NULL. If the UartGetsEcho function is unsuccessful, a negative value is returned.
//* Globals       : none
//*
short UartGetsEcho(unsigned char UartNum, char *c)
{
    unsigned short i;

    for(i = 0; i < STRINGSIZE; i++) {
        c[i] = UartGetc(UartNum);
//        if (c[i] == -1) { return -1; }
        MSG(1,"%c",c[i]);
        if ((c[i] == '\n')||(c[i] == '\r')) { break; }
    }

    return 0;
}


//***************************************
//*
//* Function Name : UartEcho
//* Description   : This function echoes one character (ping pong)
//*
//* Parameters    : UART number, pointer to the string
//* Returns       : NULL. If the UartEcho function is unsuccessful, a negative value is returned.
//* Globals       : none
//*
short UartEcho(unsigned char UartNum)
{
    char c = UartGetc(UartNum);

    switch(c) {
//        case -1:    return -1;
        default:    UartPutc(UartNum,c); break;
    }

    return 0;
}


//***************************************
//*
//* Function Name : UartEchoPrompt
//* Description   : This function echoes one character (ping pong)
//*                 and inserts a command line prompt every newline
//*
//* Parameters    : UART number, pointer to the string
//* Returns       : NULL. If the UartEchoPrompt function is unsuccessful, a negative value is returned.
//* Globals       : none
//*
short UartEchoPrompt(unsigned char UartNum)
{
    volatile unsigned short i = 0;
    char c[4];

//    while (i < STRINGSIZE) {
    if (i < STRINGSIZE) {
        c[0] = UartGetc(UartNum);
        switch(c[0]) {
//            case -1:    return -1;
            case '\e':  c[1] = UartGetc(UartNum);
                        c[2] = UartGetc(UartNum);
                        if (!strncmp(crsfw,c,3)) { UartPutsn(UartNum,c,3); i++; }
                        else if (!strncmp(crsbw,c,3)) { if(0<i) { UartPutsn(UartNum,c,3); i--; } }
                        else if (!strncmp(crsuw,c,3)) { }
                        else if (!strncmp(crsdw,c,3)) { }
                        else { UartPutsn(UartNum,c,3); }
                        break;
            case 0x7F:  if(0<i) { DEBUG(2,"%c",c[0]); i--; } break; // backspace
            case '\n':  DEBUG(2,"%c",c[0]); DEBUG(2,""_PROMPT_""); return 0; // newline
            case '\r':  DEBUG(2,"%c",c[0]); DEBUG(2,""_PROMPT_""); return 0; // carriage return
            default:    UartPutc(UartNum,c[0]); i++; break;
        }
    }
    else { return 0; }

    return 0;
}


//***************************************
//*
//* Function Name : UartGetBitrate
//* Description   : This function calculates and returns the current UART bitrate.
//*
//* Parameters    : UART number
//* Returns       : Current UART Bitrate. If the UartGetBitrate function
//*                 is unsuccessful, a negative value is returned.
//* Globals       : none
//*
long UartGetBitrate(unsigned char UartNum)
{
    unsigned short UartMmrOffset = 0;
    unsigned  long UartBitrate   = 0;
    unsigned  long UartDivisor   = 0;

    switch (UartNum) {
        case 0: UartMmrOffset = UART0_MMR_OFFSET; break;
        case 1: UartMmrOffset = UART1_MMR_OFFSET; break;
        default: printf("%s(): UART%d is not available.\n",__func__,UartNum); return -1;
    }

    volatile unsigned long *pUartCtl = (volatile unsigned long*) (UartMmrOffset + REG_UART0_CTL);
    volatile unsigned long *pUartClk = (volatile unsigned long*) (UartMmrOffset + REG_UART0_CLK);

    UartDivisor = (*pUartClk & 0xFFFF);
    if (UartDivisor == 0) { return -1; }

    UartBitrate = ( get_s0clk_hz() / UartDivisor );
    if (!(*pUartClk & BITM_UART_CLK_EDBO)) {
        UartBitrate += 8;
        UartBitrate >>= 4;
    }

    return UartBitrate;
}


//***************************************
//*
//* Function Name : UartSetBitrate
//* Description   : This function sets the UART bitrate.
//*
//* Parameters    : UART number, UART Bitrate
//* Returns       : NULL. If the UartSetBitrate function is unsuccessful, a negative value is returned.
//* Globals       : none
//*
short UartSetBitrate(unsigned char UartNum, unsigned long UartBitrate)
{
    unsigned short UartMmrOffset = 0;
    unsigned  long UartDivisor = 0;

    switch (UartNum) {
        case 0: UartMmrOffset = UART0_MMR_OFFSET; break;
        case 1: UartMmrOffset = UART1_MMR_OFFSET; break;
        default: printf("%s(): UART%d is not available.\n",__func__,UartNum); return -1;
    }

    volatile unsigned long *pUartCtl = (volatile unsigned long*) (UartMmrOffset + REG_UART0_CTL);
    volatile unsigned long *pUartClk = (volatile unsigned long*) (UartMmrOffset + REG_UART0_CLK);

    if (UartBitrate == 0) { return -1; }
    UartDivisor = ( get_s0clk_hz() / UartBitrate );
    if (!(*pUartClk & BITM_UART_CLK_EDBO)) {
        UartDivisor += 8;
        UartDivisor >>= 4;
    }

    *pUartClk &= ~BITM_UART_CLK_DIV;
    *pUartClk |= UartDivisor;

    return 0;
}


//***************************************
//*
//* Function Name : UartInsertPulse
//* Description   : This function inserts a pulse with polarity PulsePolarity and of length PulseLength.
//*                 PulsePolarity will be written to UARTx_TAIP[7], PulseLength to UARTx_TAIP[6:0].
//*                 UARTx_TAIP[6:0] is the number of bits, the duration is calculated as UARTx_TAIP[6:0] / Bit Rate
//*
//* Parameters    : UART number, UART PulseLength, PulsePolarity
//* Returns       : NULL. If the UartInsertPulse function is unsuccessful, a negative value is returned.
//* Globals       : none
//*
short UartInsertPulse(unsigned char UartNum, unsigned char PulseLength, bool PulsePolarity)
{
    unsigned short UartMmrOffset = 0;

    if (!(0 < PulseLength < 128)) { return -1; }

    switch (UartNum) {
        case 0: UartMmrOffset = UART0_MMR_OFFSET; break;
        case 1: UartMmrOffset = UART1_MMR_OFFSET; break;
        default: printf("%s(): UART%d is not available.\n",__func__,UartNum); return -1;
    }

    volatile unsigned long *pUartTaip = (volatile unsigned long*) (UartMmrOffset + REG_UART0_TAIP);

    *pUartTaip = (PulseLength & 0x7F) | (PulsePolarity << 7);

    unsigned long PulseLengthUs = ( (PulseLength * 1000000) / UartGetBitrate(UartNum) );
    printf("UART%d pulse with length %5d [us] (%4d [bits]), polarity %1d.\n", UartNum, PulseLengthUs, PulseLength, PulsePolarity);

    return 0;
}


/******************************** End of File *********************************/
