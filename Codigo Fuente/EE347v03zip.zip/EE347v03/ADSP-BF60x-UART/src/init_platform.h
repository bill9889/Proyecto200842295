/*******************************************************************************
*
*  Exported Constants/Definition Area
*
*******************************************************************************/
/*
#define __USEBFSYSCONTROL__ (1)
#define __EXTVOLTAGE__ (1)
#define __ACTIVATE_DPM__ (1)
#define __DDR2SDRAM__ (1)
*/
/*******************************************************************************
*
*  Exported Types Area
*
*******************************************************************************/

#ifdef _LANGUAGE_C
    typedef enum
    {
        NO_ERR,
        ERROR,
    } ERROR_CODE;

    typedef enum
    {
        NO,
        YES
    } TRUE;
#endif

/*******************************************************************************
*
*  Constants / Definitions Area
*
*******************************************************************************/

#define u32 unsigned long
#define u16 unsigned short
#define u8  unsigned char

#define s32 signed long
#define s16 signed short
#define s8  signed char

/*******************************************************************************
*
*  Include File Area
*
*******************************************************************************/

#include <stdio.h>
#include <stdlib.h>
#include <stdarg.h>
#include <string.h>

#include <ccblkfn.h>
#include <sysreg.h>
#include <sys/exception.h>

#include <defBF609.h>
#include <def_rom_base.h>
#include <defBF609_rom.h>
#include <cdefBF609.h>
#include <cdef_rom_base.h>
#include <cdefBF609_rom.h>

#include "system.h"
#include "led_sw.h"

#include "defBlackfin_Core.h"
#include "defBlackfin_SEC.h"
#include "cdefBlackfin_SEC.h"

#include "sec.h"
#include "defBF609Dma.h"

/****************************************************************************
 Include Section: Target Specific
*****************************************************************************/

#include "ezboardBF609_initcode.h"

/******************************** End of File *********************************/
