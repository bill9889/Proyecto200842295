#define REG_SEC_GCTL    0xffca4000
#define REG_SEC_GSTAT   0xffca4004
#define REG_SEC_RAISE   0xffca4008
#define REG_SEC_END     0xffca400c

#define REG_SEC_FCTRL   0xffca4010
#define REG_SEC_FSTAT   0xffca4014
#define REG_SEC_FPND    0xffca4018
#define REG_SEC_FSID    0xffca401c
#define REG_SEC_FDLYP   0xffca4020
#define REG_SEC_FDLYC   0xffca4024
#define REG_SEC_FCOPP   0xffca4028
#define REG_SEC_FCOPC   0xffca402c
#define REG_SEC_FEND    0xffca4030

#define REG_SEC_CCTL0   0xffca4400
#define REG_SEC_CSTAT0  0xffca4404
#define REG_SEC_CPND0   0xffca4408
#define REG_SEC_CACT0   0xffca440c
#define REG_SEC_CPMSK0  0xffca4410
#define REG_SEC_CGMSK0  0xffca4414
#define REG_SEC_CPLVL0  0xffca4418
#define REG_SEC_CSID0   0xffca441c

#define REG_SEC_CCTL1   0xffca4440
#define REG_SEC_CSTAT1  0xffca4444
#define REG_SEC_CPND1   0xffca4448
#define REG_SEC_CACT1   0xffca444c
#define REG_SEC_CPMSK1  0xffca4450
#define REG_SEC_CGMSK1  0xffca4454
#define REG_SEC_CPLVL1  0xffca4458
#define REG_SEC_CSID1   0xffca445c

#define REG_SEC_SCTL0   0xffca4800
#define REG_SEC_SSTAT0  0xffca4804
#define REG_SEC_SCTL1   0xffca4808
#define REG_SEC_SSTAT1  0xffca480c
#define REG_SEC_SCTL2   0xffca4810
#define REG_SEC_SSTAT2  0xffca4814
#define REG_SEC_SCTL3   0xffca4818
#define REG_SEC_SSTAT3  0xffca481c
#define REG_SEC_SCTL4   0xffca4820
#define REG_SEC_SSTAT4  0xffca4824

#define REG_SEC_SCTL86  0xffca4ab0
#define REG_SEC_SSTAT86 0xffca4ab4
#define REG_SEC_SCTL87  0xffca4ab8
#define REG_SEC_SSTAT87 0xffca4abc

#define REG_SEC_SCTL90  0xffca4ad0
#define REG_SEC_SSTAT90 0xffca4ad4
#define REG_SEC_SCTL91  0xffca4ad8
#define REG_SEC_SSTAT91 0xffca4adc

#define REG_SEC_SCTL127     0xffca4bf8
#define REG_SEC_SSTAT127    0xffca4bfc
