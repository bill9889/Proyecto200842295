/****************************************************************************
 Include Section
*****************************************************************************/

/*****************************************************************************
 Symbolic constants / definitions
******************************************************************************/

#define BITP_DDR_CTL_EN         0
#define BITP_DDR_CTL_PRECALL    7
#define BITP_DDR_CTL_PADDIS     14
#define BITM_DDR_CTL_EN         0x00000001
#define BITM_DDR_CTL_PRECALL    0x00000800
#define BITM_DDR_CTL_PADDIS     0x00008000

/*************************************************
* To activate PLL and Voltage Regulator settings *
* uncomment the following definition             *
*************************************************/

#define __ACTIVATE_DPM__ (1)


/********************************
* CGU Control Register Value    *
* Reset = 0x1000                *
* ADSP-BF609 EZ-KIT Lite:       *
* CLKIN = 25MHz                 *
* MSEL = 20                     *
* --> VCO = 25MHz x 20 = 500MHz *
********************************/

#define REG_CGU0_CTL_VAL    (\
                            (0  << BITP_CGU_CTL_LOCK ) | /* Lock              */\
                            (0  << BITP_CGU_CTL_WFI  ) | /* Wait For Idle     */\
                            (40 << BITP_CGU_CTL_MSEL ) | /* Multiplier Select */\
                            (0  << BITP_CGU_CTL_DF   ) | /* Divide Frequency  */\
                            0)

#define CLKIN_Hz              25000000  /* CLKIN [Hz]   */
#define CLKIN_ns (1000000000/CLKIN_Hz)  /* CLKIN [ns]   */
#define VCO_MAX_Hz          1000000000  /* VCOmax [Hz]  */
#define VCO_MIN_Hz           190000000  /* VCOmin [Hz]  */
#define PLLCLK_MAX_Hz        500000000  /* PLLCLKmax [Hz]  */


/************************************
* CGU Divide Register Value         *
* Reset = 0x____                    *
* ADSP-BF609 EZ-KIT Lite:           *
* Reset = 0x____                    *
************************************/

#define REG_CGU0_DIV_VAL    (\
                            (0 << BITP_CGU_DIV_LOCK     ) | /* Lock                  */\
                            (1 << BITP_CGU_DIV_UPDT     ) | /* Update Clock Divisors */\
                            (0 << BITP_CGU_DIV_ALGN     ) | /* Align                 */\
                            (8 << BITP_CGU_DIV_OSEL     ) | /* OUTCLK Divisor        */\
                            (4 << BITP_CGU_DIV_DSEL     ) | /* DCLK Divisor          */\
                            (2 << BITP_CGU_DIV_S1SEL    ) | /* SCLK 1 Divisor        */\
                            (4 << BITP_CGU_DIV_SYSSEL   ) | /* SYSCLK Divisor        */\
                            (2 << BITP_CGU_DIV_S0SEL    ) | /* SCLK 0 Divisor        */\
                            (2 << BITP_CGU_DIV_CSEL     ) | /* CCLK Divisor          */\
                            0)


/************************************
* CGU CLKOUTSEL Register Value      *
* Reset = 0x____                    *
* ADSP-BF609 EZ-KIT Lite:           *
* Reset = 0x____                    *
************************************/

#define REG_CGU0_CLKOUTSEL_VAL  (\
                                (0  << BITP_CGU_CLKOUTSEL_LOCK       ) | /* Lock          */\
                                (0  << BITP_CGU_CLKOUTSEL_USBCLKSEL  ) | /* USBCLK Select */\
                                (      ENUM_CGU_CLKOUTSEL_DCLKDIV2   ) | /* CLKOUT Select */\
                                0)


#define CCLK_MAX_Hz         500000000   /* Maximum Core Clock frequency [Hz]    */
#define SYSCLK_MAX_Hz       250000000   /* Maximum SYSCLK frequency [Hz]        */
#define SCLK0_MAX_Hz        125000000   /* Maximum SCLK0 frequency [Hz]         */
#define SCLK1_MAX_Hz        125000000   /* Maximum SCLK1 frequency [Hz]         */
#define DDRCLK_MIN_Hz       125000000   /* Minimum DDR2 frequency [Hz]          */
#define DDRCLK_MAX_Hz       250000000   /* Maximum DDR2 frequency[Hz]           */


/*****************************************************************************
 Static Memory Controller
*****************************************************************************/


/****************************************************
* Static Memory Control Register Value              *
* Reset = 0x____ ____                               *
****************************************************/

#define REG_SMC0_GCTL_VAL   (\
                            (0 << BITP_SMC_GCTL_BGDIS       ) | /* Bus Grant Diable */\
                            0)


/****************************************************
* Static Memory Bank0 Control Register Value        *
* Reset = 0x____ ____                               *
****************************************************/

#define REG_SMC0_B0CTL_VAL  (\
                            (0 << BITP_SMC_B0CTL_BTYPE      ) | /* Burst Type for Flash                 */\
                            (0 << BITP_SMC_B0CTL_BCLK       ) | /* CLK Frequency for Sync Burst Flash   */\
                            (0 << BITP_SMC_B0CTL_PGSZ       ) | /* Flash Page Size                      */\
                            (0 << BITP_SMC_B0CTL_RDYABTEN   ) | /* Bank0 ARDY Abort Counter Enable      */\
                            (0 << BITP_SMC_B0CTL_RDYPOL     ) | /* Bank0 ARDY Polarity                  */\
                            (0 << BITP_SMC_B0CTL_RDYEN      ) | /* Bank0 ARDY Enable                    */\
                            (0 << BITP_SMC_B0CTL_SELCTRL    ) | /* Select Control                       */\
                            (0 << BITP_SMC_B0CTL_MODE       ) | /* Static memory access mode            */\
                            (0 << BITP_SMC_B0CTL_EN         ) | /* Bank0 Enable                         */\
                            0)


/****************************************************
* Static Memory Bank0 Timing Register Value         *
* Reset = 0x____ ____                               *
****************************************************/

#define REG_SMC0_B0TIM_VAL  (\
                            (0 << BITP_SMC_B0TIM_RAT    ) | /* Read Access Time     */\
                            (0 << BITP_SMC_B0TIM_RHT    ) | /* Read Hold Time       */\
                            (0 << BITP_SMC_B0TIM_RST    ) | /* Read Setup Time      */\
                            (0 << BITP_SMC_B0TIM_WAT    ) | /* Write Access Time    */\
                            (0 << BITP_SMC_B0TIM_WHT    ) | /* Write Hold Time      */\
                            (0 << BITP_SMC_B0TIM_WST    ) | /* Write Setup Time     */\
                            0)


/*****************************************************
* Static Memory Bank0 Extended Timing Register Value *
* Reset = 0x____ ____                                *
*****************************************************/

#define REG_SMC0_B0ETIM_VAL (\
                            (0 << BITP_SMC_B0ETIM_PGWS  ) | /* Flash Page Mode Wait States  */\
                            (0 << BITP_SMC_B0ETIM_IT    ) | /* Memory Idle Time             */\
                            (0 << BITP_SMC_B0ETIM_TT    ) | /* Memory Transition Time       */\
                            (0 << BITP_SMC_B0ETIM_PREAT ) | /* Pre Access Time              */\
                            (0 << BITP_SMC_B0ETIM_PREST ) | /* Pre Setup Time               */\
                            0)


/****************************************************
* Static Memory Bank1 Control Register Value        *
* Reset = 0x____ ____                               *
****************************************************/

#define REG_SMC0_B1CTL_VAL  (\
                            (0 << BITP_SMC_B1CTL_BTYPE      ) | /* Burst Type for Flash                 */\
                            (0 << BITP_SMC_B1CTL_BCLK       ) | /* CLK Frequency for Sync Burst Flash   */\
                            (0 << BITP_SMC_B1CTL_PGSZ       ) | /* Flash Page Size                      */\
                            (0 << BITP_SMC_B1CTL_RDYABTEN   ) | /* Bank1 ARDY Abort Counter Enable      */\
                            (0 << BITP_SMC_B1CTL_RDYPOL     ) | /* Bank1 ARDY Polarity                  */\
                            (0 << BITP_SMC_B1CTL_RDYEN      ) | /* Bank1 ARDY Enable                    */\
                            (0 << BITP_SMC_B1CTL_SELCTRL    ) | /* Select Control                       */\
                            (0 << BITP_SMC_B1CTL_MODE       ) | /* Static memory access mode            */\
                            (0 << BITP_SMC_B1CTL_EN         ) | /* Bank1 Enable                         */\
                            0)


/****************************************************
* Static Memory Bank1 Timing Register Value         *
* Reset = 0x____ ____                               *
****************************************************/

#define REG_SMC0_B1TIM_VAL  (\
                            (0 << BITP_SMC_B1TIM_RAT    ) | /* Read Access Time     */\
                            (0 << BITP_SMC_B1TIM_RHT    ) | /* Read Hold Time       */\
                            (0 << BITP_SMC_B1TIM_RST    ) | /* Read Setup Time      */\
                            (0 << BITP_SMC_B1TIM_WAT    ) | /* Write Access Time    */\
                            (0 << BITP_SMC_B1TIM_WHT    ) | /* Write Hold Time      */\
                            (0 << BITP_SMC_B1TIM_WST    ) | /* Write Setup Time     */\
                            0)


/*****************************************************
* Static Memory Bank1 Extended Timing Register Value *
* Reset = 0x____ ____                                *
*****************************************************/

#define REG_SMC0_B1ETIM_VAL (\
                            (0 << BITP_SMC_B1ETIM_PGWS  ) | /* Flash Page Mode Wait States  */\
                            (0 << BITP_SMC_B1ETIM_IT    ) | /* Memory Idle Time             */\
                            (0 << BITP_SMC_B1ETIM_TT    ) | /* Memory Transition Time       */\
                            (0 << BITP_SMC_B1ETIM_PREAT ) | /* Pre Access Time              */\
                            (0 << BITP_SMC_B1ETIM_PREST ) | /* Pre Setup Time               */\
                            0)


/****************************************************
* Static Memory Bank2 Control Register Value        *
* Reset = 0x____ ____                               *
****************************************************/

#define REG_SMC0_B2CTL_VAL  (\
                            (0 << BITP_SMC_B2CTL_BTYPE      ) | /* Burst Type for Flash                 */\
                            (0 << BITP_SMC_B2CTL_BCLK       ) | /* CLK Frequency for Sync Burst Flash   */\
                            (0 << BITP_SMC_B2CTL_PGSZ       ) | /* Flash Page Size                      */\
                            (0 << BITP_SMC_B2CTL_RDYABTEN   ) | /* Bank2 ARDY Abort Counter Enable      */\
                            (0 << BITP_SMC_B2CTL_RDYPOL     ) | /* Bank2 ARDY Polarity                  */\
                            (0 << BITP_SMC_B2CTL_RDYEN      ) | /* Bank2 ARDY Enable                    */\
                            (0 << BITP_SMC_B2CTL_SELCTRL    ) | /* Select Control                       */\
                            (0 << BITP_SMC_B2CTL_MODE       ) | /* Static memory access mode            */\
                            (0 << BITP_SMC_B2CTL_EN         ) | /* Bank2 Enable                         */\
                            0)


/****************************************************
* Static Memory Bank2 Timing Register Value         *
* Reset = 0x____ ____                               *
****************************************************/

#define REG_SMC0_B2TIM_VAL  (\
                            (0 << BITP_SMC_B2TIM_RAT    ) | /* Read Access Time     */\
                            (0 << BITP_SMC_B2TIM_RHT    ) | /* Read Hold Time       */\
                            (0 << BITP_SMC_B2TIM_RST    ) | /* Read Setup Time      */\
                            (0 << BITP_SMC_B2TIM_WAT    ) | /* Write Access Time    */\
                            (0 << BITP_SMC_B2TIM_WHT    ) | /* Write Hold Time      */\
                            (0 << BITP_SMC_B2TIM_WST    ) | /* Write Setup Time     */\
                            0)


/*****************************************************
* Static Memory Bank2 Extended Timing Register Value *
* Reset = 0x____ ____                                *
*****************************************************/

#define REG_SMC0_B2ETIM_VAL (\
                            (0 << BITP_SMC_B2ETIM_PGWS  ) | /* Flash Page Mode Wait States  */\
                            (0 << BITP_SMC_B2ETIM_IT    ) | /* Memory Idle Time             */\
                            (0 << BITP_SMC_B2ETIM_TT    ) | /* Memory Transition Time       */\
                            (0 << BITP_SMC_B2ETIM_PREAT ) | /* Pre Access Time              */\
                            (0 << BITP_SMC_B2ETIM_PREST ) | /* Pre Setup Time               */\
                            0)


/****************************************************
* Static Memory Bank3 Control Register Value        *
* Reset = 0x____ ____                               *
****************************************************/

#define REG_SMC0_B3CTL_VAL  (\
                            (0 << BITP_SMC_B3CTL_BTYPE      ) | /* Burst Type for Flash                 */\
                            (0 << BITP_SMC_B3CTL_BCLK       ) | /* CLK Frequency for Sync Burst Flash   */\
                            (0 << BITP_SMC_B3CTL_PGSZ       ) | /* Flash Page Size                      */\
                            (0 << BITP_SMC_B3CTL_RDYABTEN   ) | /* Bank3 ARDY Abort Counter Enable      */\
                            (0 << BITP_SMC_B3CTL_RDYPOL     ) | /* Bank3 ARDY Polarity                  */\
                            (0 << BITP_SMC_B3CTL_RDYEN      ) | /* Bank3 ARDY Enable                    */\
                            (0 << BITP_SMC_B3CTL_SELCTRL    ) | /* Select Control                       */\
                            (0 << BITP_SMC_B3CTL_MODE       ) | /* Static memory access mode            */\
                            (0 << BITP_SMC_B3CTL_EN         ) | /* Bank3 Enable                         */\
                            0)


/****************************************************
* Static Memory Bank3 Timing Register Value         *
* Reset = 0x____ ____                               *
****************************************************/

#define REG_SMC0_B3TIM_VAL  (\
                            (0 << BITP_SMC_B3TIM_RAT    ) | /* Read Access Time     */\
                            (0 << BITP_SMC_B3TIM_RHT    ) | /* Read Hold Time       */\
                            (0 << BITP_SMC_B3TIM_RST    ) | /* Read Setup Time      */\
                            (0 << BITP_SMC_B3TIM_WAT    ) | /* Write Access Time    */\
                            (0 << BITP_SMC_B3TIM_WHT    ) | /* Write Hold Time      */\
                            (0 << BITP_SMC_B3TIM_WST    ) | /* Write Setup Time     */\
                            0)


/*****************************************************
* Static Memory Bank3 Extended Timing Register Value *
* Reset = 0x____ ____                                *
*****************************************************/

#define REG_SMC0_B3ETIM_VAL (\
                            (0 << BITP_SMC_B3ETIM_PGWS  ) | /* Flash Page Mode Wait States  */\
                            (0 << BITP_SMC_B3ETIM_IT    ) | /* Memory Idle Time             */\
                            (0 << BITP_SMC_B3ETIM_TT    ) | /* Memory Transition Time       */\
                            (0 << BITP_SMC_B3ETIM_PREAT ) | /* Pre Access Time              */\
                            (0 << BITP_SMC_B3ETIM_PREST ) | /* Pre Setup Time               */\
                            0)


/*****************************************************************************
 Dynamic Memory Controller
*****************************************************************************/

#define DLL_LOCK_PERIOD     4500

#define DDR_CTL_TR0_RCns    55
#define DDR_CTL_TR0_RASns   40
#define DDR_CTL_TR0_RPns    15
#define DDR_CTL_TR0_WTRns   8 // 7.5
#define DDR_CTL_TR0_RCDns   15

#define DDR_CTL_TR1_RRDns   10
#define DDR_CTL_TR1_RFCns   128 // 127.5
#define DDR_CTL_TR1_REFIns  7800

#define DDR_CTL_TR2_WRns    15
#define DDR_CTL_TR2_RTPns   8 // 7.5
#define DDR_CTL_TR2_FAWns   50


#undef BITP_DDR_STAT_INITDONE
#undef BITM_DDR_STAT_INITDONE

//#define BITP_DDR_STAT_MEMINITDONE         1           /* SDRAM Initialization Complete */
//#define BITM_DDR_STAT_MEMINITDONE         0x00000002  /* SDRAM Initialization Complete */


/*********************************************
* DMC Control Register                       *
* Reset = 0x0000 0000                        *
* ADSP-BF609-resets.xml = 0x0000 0404        *
* here: 0x0000 0405                          *
*********************************************/

#define REG_DDR0_CTL_VAL    (\
                            (1 << BITP_DDR_CTL_EN        ) | /* DMC enable                                              */\
                            (0 << BITP_DDR_CTL_LPDDR     ) | /* LPDDR Mode Enable                                       */\
                            (1 << BITP_DDR_CTL_INIT      ) | /* DRAM Initialization                                     */\
                            (0 << BITP_DDR_CTL_SRREQ     ) | /* Self Refresh Mode                                       */\
                            (0 << BITP_DDR_CTL_PDREQ     ) | /* Power Down Mode                                         */\
                            (0 << BITP_DDR_CTL_DPDREQ    ) | /* Deep Power Down Mode                                    */\
                            (0 << BITP_DDR_CTL_PREC      ) | /* Precharge                                               */\
                            (0 << BITP_DDR_CTL_PRECALL   ) | /* Precharge All Banks                                     */\
                            (0 << BITP_DDR_CTL_PADDIS    ) | /* Disable Command and Control Pads                        */\
                            (0 << BITP_DDR_CTL_DLLCAL    ) | /* Start PHY DLL Calibration Sequence                      */\
                            (0 << BITP_DDR_CTL_PPREF     ) | /* Postpone Sending Auto-Refresh Commands                  */\
                            (4 << BITP_DDR_CTL_RDTOWR    ) | /* Add extra cycles when a write follows read back to back */\
                            (0 << BITP_DDR_CTL_ADDRMODE  ) | /* Select Page or Bank Interleaving                        */\
                            0)


/*********************************************
* DMC Efficiency Control Register            *
* Reset = 0x0000 0000                        *
* here: 0x0000 0000                          *
*********************************************/

#define REG_DDR0_EFFCTL_VAL (\
                            (0 << BITP_DDR_EFFCTL_IDLECYC   ) | /* Number of cycles after which accumulated auto-refresh commands are issued    */\
                            (0 << BITP_DDR_EFFCTL_NUMREF    ) | /* Number of accumulated auto-refresh commands                                  */\
                            (0 << BITP_DDR_EFFCTL_PRECBANK  ) | /* Precharge                                                                    */\
                            0)


/*********************************************
* DMC SDRAM Configuration Register           *
* Reset = 0x0000 0000                        *
* ADSP-BF609-resets.xml = 0x0000 0422        *
* here: 0x0000 0422                          *
*********************************************/

#define REG_DDR0_CFG_VAL    (\
                            (ENUM_DDR_CFG_EXTBANK1 ) | /* Num External Banks                          */\
                            (ENUM_DDR_CFG_SDRSIZE1G) | /* SDRAM Size                                  */\
                            (ENUM_DDR_CFG_SDRWID16 ) | /* SDRAM Width                                 */\
                            (ENUM_DDR_CFG_IFWID16  ) | /* Interface Width                             */\
                            0)



/*********************************************
* DMC SDRAM Device Timing Register 0         *
* Reset = 0x0000 0000                        *
* ADSP-BF609-resets.xml = 0x20F0 C424        *
* here: 0x20E0 A424                          *
*********************************************/

#define REG_DDR0_TR0_VAL        (\
                                ( 2 << BITP_DDR_TR0_TMRD  ) | /* Mode register set-to-active    */\
                                (14 << BITP_DDR_TR0_TRC   ) | /* Active-to-Active time          */\
                                (10 << BITP_DDR_TR0_TRAS  ) | /* Active-to- Precharge time      */\
                                ( 4 << BITP_DDR_TR0_TRP   ) | /* Precharge-to-Active time       */\
                                ( 2 << BITP_DDR_TR0_TWTR  ) | /* Write-to-Read delay            */\
                                ( 4 << BITP_DDR_TR0_TRCD  ) | /* RAS to CAS delay time          */\
                                0)

#define REG_DDR0_TR0_DYN_VAL    (\
                                (                   2 << BITP_DDR_TR0_TMRD  ) | /* Mode register set-to-active    */\
                                ( usDDR_CTL_TR0_RCck  << BITP_DDR_TR0_TRC   ) | /* Active-to-Active time          */\
                                ( usDDR_CTL_TR0_RASck << BITP_DDR_TR0_TRAS  ) | /* Active-to- Precharge time      */\
                                ( usDDR_CTL_TR0_RPck  << BITP_DDR_TR0_TRP   ) | /* Precharge-to-Active time       */\
                                ( usDDR_CTL_TR0_WTRck << BITP_DDR_TR0_TWTR  ) | /* Write-to-Read delay            */\
                                ( usDDR_CTL_TR0_RCDck << BITP_DDR_TR0_TRCD  ) | /* RAS to CAS delay time          */\
                                0)

/*********************************************
* DMC SDRAM Device Timing Register 1         *
* Reset = 0x0000 0000                        *
* ADSP-BF609-resets.xml = 0x3020 078E        *
* here: 0x3020 03CF                          *
*********************************************/

#define REG_DDR0_TR1_VAL        (\
                                (   3 << BITP_DDR_TR1_TRRD  ) | /* Active-to-Active time             */\
                                (  32 << BITP_DDR_TR1_TRFC  ) | /* Refresh-to-Active command delay   */\
                                (1950 << BITP_DDR_TR1_TREF  ) | /* Refresh Interval                  */\
                                0)

#define REG_DDR0_TR1_DYN_VAL    (\
                                (                   2  << BITP_DDR_TR1_TRRD  ) | /* Active-to-Active time             */\
                                ( usDDR_CTL_TR1_RFCck  << BITP_DDR_TR1_TRFC  ) | /* Refresh-to-Active command delay   */\
                                ( usDDR_CTL_TR1_REFIck << BITP_DDR_TR1_TREF  ) | /* Refresh Interval                  */\
                                0)


/*********************************************
* DMC SDRAM Device Timing Register 2         *
* Reset = 0x0000 0000                        *
* ADSP-BF609-resets.xml = 0x0032 020D        *
* here: 0x0032 020D                          *
*********************************************/

#define REG_DDR0_TR2_VAL        (\
                                ( 3 << BITP_DDR_TR2_TCKE    ) | /* CKE Minimum Pulse Width                  */\
                                ( 2 << BITP_DDR_TR2_TXP     ) | /* Exit Power Down to Next Valid Command    */\
                                ( 4 << BITP_DDR_TR2_TWR     ) | /* Write Recovery Time (LPDDR only)         */\
                                ( 5 << BITP_DDR_TR2_TRTP    ) | /* Internal Read to Precharge               */\
                                (13 << BITP_DDR_TR2_TFAW    ) | /* Four Activate Window                     */\
                                0)

#define REG_DDR0_TR2_DYN_VAL    (\
                                (                   3 << BITP_DDR_TR2_TCKE    ) | /* CKE Minimum Pulse Width                  */\
                                (                   2 << BITP_DDR_TR2_TXP     ) | /* Exit Power Down to Next Valid Command    */\
                                ( usDDR_CTL_TR2_WRck  << BITP_DDR_TR2_TWR     ) | /* Write Recovery Time (LPDDR only)         */\
                                (                   5 << BITP_DDR_TR2_TRTP    ) | /* Internal Read to Precharge               */\
                                ( usDDR_CTL_TR2_FAWck << BITP_DDR_TR2_TFAW    ) | /* Four Activate Window                     */\
                                0)

/*********************************************
* DMC SDRAM Mode Register                    *
* Reset = 0x0000 0000                        *
* ADSP-BF609-resets.xml = 0x0000 0842        *
* here: 0x0000 0842                          *
*********************************************/

#define REG_DDR0_MR_VAL     (\
                            (0 << BITP_DDR_MR_PD        ) | /*  Active Power Down Exit time */\
                            (4 << BITP_DDR_MR_WRRECOV   ) | /*  Write Recovery              */\
                            (0 << BITP_DDR_MR_DLLRST    ) | /*  DLL Reset                   */\
                            (     ENUM_DDR_MR_CL4       ) | /*  CAS Latency                 */\
                            (     ENUM_DDR_MR_BLEN4     ) | /*  Burst Length                */\
                            0)


/*********************************************
* DMC SDRAM Extended Mode Register 1         *
* Reset = 0x0000 0000                        *
* ADSP-BF609-resets.xml = 0x0000 0004        *
* here: 0x0000 0004                          *
*********************************************/

#define REG_DDR0_EMR1_VAL   (\
                            (0 << BITP_DDR_EMR1_QOFF    ) | /*  Output Buffer Enable                        */\
                            (0 << BITP_DDR_EMR1_DQS     ) |                                                   \
                            (     ENUM_DDR_EMR1_RTT1_0  ) | /*  Termination Resistance 1.                   */\
                            (0 << BITP_DDR_EMR1_AL      ) | /*  Additive Latency                            */\
                            (     ENUM_DDR_EMR1_RTT0_1  ) | /*  Termination Resistance 0.                   */\
                            (0 << BITP_DDR_EMR1_DIC     ) | /*  Output Driver Impedance Control (D.I.C.)    */\
                            (0 << BITP_DDR_EMR1_DLLEN   ) | /*  DLL Enable                                  */\
                            0)


/*********************************************
* DMC SDRAM Extended Mode Register 2         *
* Reset = 0x0000 0000                        *
* here: 0x0000 0000                          *
*********************************************/

#define REG_DDR0_EMR2_VAL   (\
                            (0 << BITP_DDR_EMR2_SRF   ) | /*  High Temperature Self-Refresh Rate Enable */\
                            (0 << BITP_DDR_EMR2_PASR  ) | /*  Partial Array Self Refresh                */\
                            0)


/*********************************************
* DMC SDRAM Extended Mode Register 2         *
* must be written 0                          *
*********************************************/

#define REG_DDR0_EMR3_VAL   0


/*********************************************
* DMC SDRAM PAD Control Register             *
* Reset = 0x0004 4400                        *
* here: 0x0004 4400                          *
*********************************************/

#define REG_DDR0_PADCTL_VAL     (\
                                (0 << BITP_DDR_PADCTL_DQODS      ) | /*  DQS Pads Output Drive Strength Control              */\
                                (0 << BITP_DDR_PADCTL_DQPWD      ) | /*  DQ Pads Receiver Power Down                         */\
                                (0 << BITP_DDR_PADCTL_DQSODS     ) | /*  DQS Pads Output Drive Strength Control              */\
                                (0 << BITP_DDR_PADCTL_DQSPWD     ) | /*  DQ and DQS Pads Receiver Power Down                 */\
                                (0 << BITP_DDR_PADCTL_CLKODS     ) | /*  CLK Pads Output Drive Strength Control              */\
                                (1 << BITP_DDR_PADCTL_CLKPWD     ) | /*  CLK Pads Receiver Power Down                        */\
                                (0 << BITP_DDR_PADCTL_CLKOE      ) | /*  CLK Pads OE Value                                   */\
                                (0 << BITP_DDR_PADCTL_CMDODS     ) | /*  CMD/ADDR/CONTROL Pads Output Drive Strength Control */\
                                (1 << BITP_DDR_PADCTL_CMDPWD     ) | /*  CMD/ADDR/CONTROL Pads Receiver Power Down           */\
                                (0 << BITP_DDR_PADCTL_CMDOE      ) | /*  CMD Pads OE Value                                   */\
                                (0 << BITP_DDR_PADCTL_CKEODS     ) | /*  CKE Pad Output Drive Strength Control               */\
                                (1 << BITP_DDR_PADCTL_CKEPWD     ) | /*  CKE Pad Receiver Power Down                         */\
                                (0 << BITP_DDR_PADCTL_CKEOE      ) | /*  CKE Pad OE Value                                    */\
                                0)


/*********************************************
* DMC SDRAM DLL Control Register             *
* Reset = 0x0000 034B                        *
* ADSP-BF609-resets.xml = 0x0000 044B        *
* here: 0x0000 044B                          *
*********************************************/

#define REG_DDR0_DLLCTL_VAL     (\
                                ( 4 << BITP_DDR_DLLCTL_DATACYC     ) | /* Controller Latency */\
                                (75 << BITP_DDR_DLLCTL_DLLCALRDCNT ) | /* Number of Reads Required for DLL Calibration */\
                                0)


/*********************************************
* DMC SDRAM PHY Control Register 0           *
* Reset = 0x____ ____                        *
* ADSP-BF609-resets.xml = 0x____ ____        *
* here: 0x____ ____                          *
*********************************************/

#define REG_DDR0_PHY_CTL0_VAL   (\
                                ( 0 << 0 ) |\
                                0)


/*********************************************
* DMC SDRAM PHY Control Register 1           *
* Reset = 0x____ ____                        *
* ADSP-BF609-resets.xml = 0x____ ____        *
* here: 0x____ ____                          *
*********************************************/

#define REG_DDR0_PHY_CTL1_VAL   (\
                                ( ENUM_DDR_PHY_CTL1_ODT_75 ) |\
                                0)


/*********************************************
* DMC SDRAM PHY Control Register 2           *
* Reset = 0x____ ____                        *
* ADSP-BF609-resets.xml = 0x____ ____        *
* here: 0x____ ____                          *
*********************************************/

#define REG_DDR0_PHY_CTL2_VAL   (\
                                ( 0 << 0 ) |\
                                0)


/*********************************************
* DMC SDRAM PHY Control Register 3           *
* Reset = 0x____ ____                        *
* ADSP-BF609-resets.xml = 0x____ ____        *
* here: 0x____ ____                          *
*********************************************/

#define REG_DDR0_PHY_CTL3_VAL   (\
                                ( BITM_DDR_PHY_CTL3_ENODTDQ ) |\
                                ( BITM_DDR_PHY_CTL3_TMG0    ) |\
                                ( BITM_DDR_PHY_CTL3_TMG1    ) |\
                                ( BITM_DDR_PHY_CTL3_OFST0   ) |\
                                ( BITM_DDR_PHY_CTL3_OFST1   ) |\
                                0)


/**********************************************************
* BMODE_SPIMEM: Boot from SPI memory                      *
* This definition will modify the SPI_BAUD register value *
* and can in/decrease boot speed                          *
* Boot Rom default: 0x85                                  *
**********************************************************/

#define SPI_BAUD_VAL            0x85


/****************************************************************************
 EOF
*****************************************************************************/
