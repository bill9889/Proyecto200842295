/* ================================================================================

     Project      :   BLACKFIN_CORE
     Description  :   Register Definitions

     Version      :   0.0
     Date         :   Jan 1 1900

     Copyright (C) 08-07-2001 Analog Devices Inc., All Rights Reserved.

   ================================================================================ */

#ifndef _DEF_BLACKFIN_CORE_H
#define _DEF_BLACKFIN_CORE_H


/* =====================================================================================================================================
       Data Memory Unit Registers
   ===================================================================================================================================== */
#define REG_L1_DM_CTL                 0xffe00004            /*  Data memory control                                                      */
#define REG_L1_DM_STAT                0xffe00008            /*  Data Cacheability Protection Lookaside Buffer Status                     */
#define REG_L1_DM_CPLB_FAULT_ADDR     0xffe0000c            /*  Data Cacheability Protection Lookaside Buffer Fault Address              */
#define REG_L1_DM_CPLB_ADDR0          0xffe00100            /*  Data Cacheability Protection Lookaside Buffer Descriptor Address         */
#define REG_L1_DM_CPLB_ADDR1          0xffe00104            /*  Data Cacheability Protection Lookaside Buffer Descriptor Address         */
#define REG_L1_DM_CPLB_ADDR2          0xffe00108            /*  Data Cacheability Protection Lookaside Buffer Descriptor Address         */
#define REG_L1_DM_CPLB_ADDR3          0xffe0010c            /*  Data Cacheability Protection Lookaside Buffer Descriptor Address         */
#define REG_L1_DM_CPLB_ADDR4          0xffe00110            /*  Data Cacheability Protection Lookaside Buffer Descriptor Address         */
#define REG_L1_DM_CPLB_ADDR5          0xffe00114            /*  Data Cacheability Protection Lookaside Buffer Descriptor Address         */
#define REG_L1_DM_CPLB_ADDR6          0xffe00118            /*  Data Cacheability Protection Lookaside Buffer Descriptor Address         */
#define REG_L1_DM_CPLB_ADDR7          0xffe0011c            /*  Data Cacheability Protection Lookaside Buffer Descriptor Address         */
#define REG_L1_DM_CPLB_ADDR8          0xffe00120            /*  Data Cacheability Protection Lookaside Buffer Descriptor Address         */
#define REG_L1_DM_CPLB_ADDR9          0xffe00124            /*  Data Cacheability Protection Lookaside Buffer Descriptor Address         */
#define REG_L1_DM_CPLB_ADDR10         0xffe00128            /*  Data Cacheability Protection Lookaside Buffer Descriptor Address         */
#define REG_L1_DM_CPLB_ADDR11         0xffe0012c            /*  Data Cacheability Protection Lookaside Buffer Descriptor Address         */
#define REG_L1_DM_CPLB_ADDR12         0xffe00130            /*  Data Cacheability Protection Lookaside Buffer Descriptor Address         */
#define REG_L1_DM_CPLB_ADDR13         0xffe00134            /*  Data Cacheability Protection Lookaside Buffer Descriptor Address         */
#define REG_L1_DM_CPLB_ADDR14         0xffe00138            /*  Data Cacheability Protection Lookaside Buffer Descriptor Address         */
#define REG_L1_DM_CPLB_ADDR15         0xffe0013c            /*  Data Cacheability Protection Lookaside Buffer Descriptor Address         */
#define REG_L1_DM_CPLB_DATA0          0xffe00200            /*  Cacheability Protection Lookaside Buffer Descriptor Data                 */
#define REG_L1_DM_CPLB_DATA1          0xffe00204            /*  Cacheability Protection Lookaside Buffer Descriptor Data                 */
#define REG_L1_DM_CPLB_DATA2          0xffe00208            /*  Cacheability Protection Lookaside Buffer Descriptor Data                 */
#define REG_L1_DM_CPLB_DATA3          0xffe0020c            /*  Cacheability Protection Lookaside Buffer Descriptor Data                 */
#define REG_L1_DM_CPLB_DATA4          0xffe00210            /*  Cacheability Protection Lookaside Buffer Descriptor Data                 */
#define REG_L1_DM_CPLB_DATA5          0xffe00214            /*  Cacheability Protection Lookaside Buffer Descriptor Data                 */
#define REG_L1_DM_CPLB_DATA6          0xffe00218            /*  Cacheability Protection Lookaside Buffer Descriptor Data                 */
#define REG_L1_DM_CPLB_DATA7          0xffe0021c            /*  Cacheability Protection Lookaside Buffer Descriptor Data                 */
#define REG_L1_DM_CPLB_DATA8          0xffe00220            /*  Cacheability Protection Lookaside Buffer Descriptor Data                 */
#define REG_L1_DM_CPLB_DATA9          0xffe00224            /*  Cacheability Protection Lookaside Buffer Descriptor Data                 */
#define REG_L1_DM_CPLB_DATA10         0xffe00228            /*  Cacheability Protection Lookaside Buffer Descriptor Data                 */
#define REG_L1_DM_CPLB_DATA11         0xffe0022c            /*  Cacheability Protection Lookaside Buffer Descriptor Data                 */
#define REG_L1_DM_CPLB_DATA12         0xffe00230            /*  Cacheability Protection Lookaside Buffer Descriptor Data                 */
#define REG_L1_DM_CPLB_DATA13         0xffe00234            /*  Cacheability Protection Lookaside Buffer Descriptor Data                 */
#define REG_L1_DM_CPLB_DATA14         0xffe00238            /*  Cacheability Protection Lookaside Buffer Descriptor Data                 */
#define REG_L1_DM_CPLB_DATA15         0xffe0023c            /*  Cacheability Protection Lookaside Buffer Descriptor Data                 */
#define REG_L1_DM_TEST_CMD            0xffe00300            /*  Data Test Command Register                                               */
#define REG_L1_DM_TEST_DATA0          0xffe00400            /*  Data Test Data Register                                                  */
#define REG_L1_DM_TEST_DATA1          0xffe00404            /*  Data Test Data Register                                                  */

/* ===================================================================================================================================== 
       Data Memory Unit Register Field Definitions
   ===================================================================================================================================== */
/* -------------------------------------------------------------------------------------------------
        CTL                                 Bits              Description
   ------------------------------------------------------------------------------------------------- */
#define BITP_L1_DM_CTL_PPREF1               13            /*  DAG1 Port Preference                   */
#define BITP_L1_DM_CTL_PPREF0               12            /*  DAG0 Port Preference                   */
#define BITP_L1_DM_CTL_DCBS                  4            /*  L1 Data Cache Bank Select              */
#define BITP_L1_DM_CTL_CFG                   2            /*  Data Memory Configuration              */
#define BITP_L1_DM_CTL_ENCPLB                1            /*  Enable DCPLB                           */
/* -------------------------------------------------------------------------------------------------
        CTL                                 Masks 
   ------------------------------------------------------------------------------------------------- */
#define BITM_L1_DM_CTL_PPREF1               0x00002000
#define BITM_L1_DM_CTL_PPREF0               0x00001000
#define BITM_L1_DM_CTL_DCBS                 0x00000010
#define BITM_L1_DM_CTL_CFG                  0x0000000c
#define BITM_L1_DM_CTL_ENCPLB               0x00000002

/* -------------------------------------------------------------------------------------------------
        STAT                                Bits              Description
   ------------------------------------------------------------------------------------------------- */
#define BITP_L1_DM_STAT_ILLADDR             19            /*  Illegal Address                        */
#define BITP_L1_DM_STAT_DAG                 18            /*  Access DAG                             */
#define BITP_L1_DM_STAT_MODE                17            /*  Access Mode                            */
#define BITP_L1_DM_STAT_RW                  16            /*  Access Read/Write                      */
#define BITP_L1_DM_STAT_FAULT                0            /*  Fault Status                           */
/* -------------------------------------------------------------------------------------------------
        STAT                                Masks 
   ------------------------------------------------------------------------------------------------- */
#define BITM_L1_DM_STAT_ILLADDR             0x00080000
#define BITM_L1_DM_STAT_DAG                 0x00040000
#define BITM_L1_DM_STAT_MODE                0x00020000
#define BITM_L1_DM_STAT_RW                  0x00010000
#define BITM_L1_DM_STAT_FAULT               0x0000ffff

/* -------------------------------------------------------------------------------------------------
        CPLB_ADDRn                          Bits              Description
   ------------------------------------------------------------------------------------------------- */
#define BITP_L1_DM_CPLB_ADDR_ADDR           10            /*  Address for match                      */
/* -------------------------------------------------------------------------------------------------
        CPLB_ADDRn                          Masks 
   ------------------------------------------------------------------------------------------------- */
#define BITM_L1_DM_CPLB_ADDR_ADDR           0xfffffc00

/* -------------------------------------------------------------------------------------------------
        CPLB_DATAn                          Bits              Description
   ------------------------------------------------------------------------------------------------- */
#define BITP_L1_DM_CPLB_DATA_PSize          16            /*  Page Size                              */
#define BITP_L1_DM_CPLB_DATA_WT             14            /*  CPLB Write Through                     */
#define BITP_L1_DM_CPLB_DATA_L2_CHBL        13            /*  CPLB L2 Cachable                       */
#define BITP_L1_DM_CPLB_DATA_L1_CHBL        12            /*  CPLB L1 Cachable                       */
#define BITP_L1_DM_CPLB_DATA_Dirty           7            /*  CPLB DIRTY                             */
#define BITP_L1_DM_CPLB_DATA_DAGACC          6            /*  CPLB DAG Access                        */
#define BITP_L1_DM_CPLB_DATA_L1SRAM          5            /*  CPLB L1SRAM                            */
#define BITP_L1_DM_CPLB_DATA_SWrite          4            /*  CPLB Supervisor Write                  */
#define BITP_L1_DM_CPLB_DATA_UWrite          3            /*  CPLB User Write                        */
#define BITP_L1_DM_CPLB_DATA_URead           2            /*  CPLB User Read                         */
#define BITP_L1_DM_CPLB_DATA_Lock            1            /*  CPLB Lock                              */
#define BITP_L1_DM_CPLB_DATA_Valid           0            /*  CPLB Valid                             */
/* -------------------------------------------------------------------------------------------------
        CPLB_DATAn                          Masks 
   ------------------------------------------------------------------------------------------------- */
#define BITM_L1_DM_CPLB_DATA_PSize          0x00030000
#define BITM_L1_DM_CPLB_DATA_WT             0x00004000
#define BITM_L1_DM_CPLB_DATA_L2_CHBL        0x00002000
#define BITM_L1_DM_CPLB_DATA_L1_CHBL        0x00001000
#define BITM_L1_DM_CPLB_DATA_Dirty          0x00000080
#define BITM_L1_DM_CPLB_DATA_DAGACC         0x00000040
#define BITM_L1_DM_CPLB_DATA_L1SRAM         0x00000020
#define BITM_L1_DM_CPLB_DATA_SWrite         0x00000010
#define BITM_L1_DM_CPLB_DATA_UWrite         0x00000008
#define BITM_L1_DM_CPLB_DATA_URead          0x00000004
#define BITM_L1_DM_CPLB_DATA_Lock           0x00000002
#define BITM_L1_DM_CPLB_DATA_Valid          0x00000001

/* -------------------------------------------------------------------------------------------------
        TEST_CMD                            Bits              Description
   ------------------------------------------------------------------------------------------------- */
#define BITP_L1_DM_TEST_CMD_WAYSEL          26            /*  Access Way/Instruction Address Bit 11  */
#define BITP_L1_DM_TEST_CMD_IDSEL           24            /*  Instruction/Data Access                */
#define BITP_L1_DM_TEST_CMD_BNKSEL          23            /*  Data Bank Access                       */
#define BITP_L1_DM_TEST_CMD_SBNK            16            /*  Subbank Access                         */
#define BITP_L1_DM_TEST_CMD_SET              5            /*  Set Index                              */
#define BITP_L1_DM_TEST_CMD_DW               3            /*  Double Word Index                      */
#define BITP_L1_DM_TEST_CMD_TAGSELB          2            /*  Array Access                           */
#define BITP_L1_DM_TEST_CMD_RW               1            /*  Read/Write Access                      */
/* -------------------------------------------------------------------------------------------------
        TEST_CMD                            Masks 
   ------------------------------------------------------------------------------------------------- */
#define BITM_L1_DM_TEST_CMD_WAYSEL          0x04000000
#define BITM_L1_DM_TEST_CMD_IDSEL           0x01000000
#define BITM_L1_DM_TEST_CMD_BNKSEL          0x00800000
#define BITM_L1_DM_TEST_CMD_SBNK            0x00030000
#define BITM_L1_DM_TEST_CMD_SET             0x000007e0
#define BITM_L1_DM_TEST_CMD_DW              0x00000018
#define BITM_L1_DM_TEST_CMD_TAGSELB         0x00000004
#define BITM_L1_DM_TEST_CMD_RW              0x00000002


/* =====================================================================================================================================
       Instruction Memory Unit Registers
   ===================================================================================================================================== */
#define REG_L1_IM_CTL                 0xffe01004            /*  Instruction memory control                                               */
#define REG_L1_IM_STAT                0xffe01008            /*  Instruction Cacheability Protection Lookaside Buffer Status              */
#define REG_L1_IM_CPLB_FAULT_ADDR     0xffe0100c            /*  Instruction Cacheability Protection Lookaside Buffer Fault Address       */
#define REG_L1_IM_CPLB_ADDR0          0xffe01100            /*  Instruction Cacheability Protection Lookaside Buffer Descriptor Address  */
#define REG_L1_IM_CPLB_ADDR1          0xffe01104            /*  Instruction Cacheability Protection Lookaside Buffer Descriptor Address  */
#define REG_L1_IM_CPLB_ADDR2          0xffe01108            /*  Instruction Cacheability Protection Lookaside Buffer Descriptor Address  */
#define REG_L1_IM_CPLB_ADDR3          0xffe0110c            /*  Instruction Cacheability Protection Lookaside Buffer Descriptor Address  */
#define REG_L1_IM_CPLB_ADDR4          0xffe01110            /*  Instruction Cacheability Protection Lookaside Buffer Descriptor Address  */
#define REG_L1_IM_CPLB_ADDR5          0xffe01114            /*  Instruction Cacheability Protection Lookaside Buffer Descriptor Address  */
#define REG_L1_IM_CPLB_ADDR6          0xffe01118            /*  Instruction Cacheability Protection Lookaside Buffer Descriptor Address  */
#define REG_L1_IM_CPLB_ADDR7          0xffe0111c            /*  Instruction Cacheability Protection Lookaside Buffer Descriptor Address  */
#define REG_L1_IM_CPLB_ADDR8          0xffe01120            /*  Instruction Cacheability Protection Lookaside Buffer Descriptor Address  */
#define REG_L1_IM_CPLB_ADDR9          0xffe01124            /*  Instruction Cacheability Protection Lookaside Buffer Descriptor Address  */
#define REG_L1_IM_CPLB_ADDR10         0xffe01128            /*  Instruction Cacheability Protection Lookaside Buffer Descriptor Address  */
#define REG_L1_IM_CPLB_ADDR11         0xffe0112c            /*  Instruction Cacheability Protection Lookaside Buffer Descriptor Address  */
#define REG_L1_IM_CPLB_ADDR12         0xffe01130            /*  Instruction Cacheability Protection Lookaside Buffer Descriptor Address  */
#define REG_L1_IM_CPLB_ADDR13         0xffe01134            /*  Instruction Cacheability Protection Lookaside Buffer Descriptor Address  */
#define REG_L1_IM_CPLB_ADDR14         0xffe01138            /*  Instruction Cacheability Protection Lookaside Buffer Descriptor Address  */
#define REG_L1_IM_CPLB_ADDR15         0xffe0113c            /*  Instruction Cacheability Protection Lookaside Buffer Descriptor Address  */
#define REG_L1_IM_CPLB_DATA0          0xffe01200            /*  Cacheability Protection Lookaside Buffer Descriptor Status               */
#define REG_L1_IM_CPLB_DATA1          0xffe01204            /*  Cacheability Protection Lookaside Buffer Descriptor Status               */
#define REG_L1_IM_CPLB_DATA2          0xffe01208            /*  Cacheability Protection Lookaside Buffer Descriptor Status               */
#define REG_L1_IM_CPLB_DATA3          0xffe0120c            /*  Cacheability Protection Lookaside Buffer Descriptor Status               */
#define REG_L1_IM_CPLB_DATA4          0xffe01210            /*  Cacheability Protection Lookaside Buffer Descriptor Status               */
#define REG_L1_IM_CPLB_DATA5          0xffe01214            /*  Cacheability Protection Lookaside Buffer Descriptor Status               */
#define REG_L1_IM_CPLB_DATA6          0xffe01218            /*  Cacheability Protection Lookaside Buffer Descriptor Status               */
#define REG_L1_IM_CPLB_DATA7          0xffe0121c            /*  Cacheability Protection Lookaside Buffer Descriptor Status               */
#define REG_L1_IM_CPLB_DATA8          0xffe01220            /*  Cacheability Protection Lookaside Buffer Descriptor Status               */
#define REG_L1_IM_CPLB_DATA9          0xffe01224            /*  Cacheability Protection Lookaside Buffer Descriptor Status               */
#define REG_L1_IM_CPLB_DATA10         0xffe01228            /*  Cacheability Protection Lookaside Buffer Descriptor Status               */
#define REG_L1_IM_CPLB_DATA11         0xffe0122c            /*  Cacheability Protection Lookaside Buffer Descriptor Status               */
#define REG_L1_IM_CPLB_DATA12         0xffe01230            /*  Cacheability Protection Lookaside Buffer Descriptor Status               */
#define REG_L1_IM_CPLB_DATA13         0xffe01234            /*  Cacheability Protection Lookaside Buffer Descriptor Status               */
#define REG_L1_IM_CPLB_DATA14         0xffe01238            /*  Cacheability Protection Lookaside Buffer Descriptor Status               */
#define REG_L1_IM_CPLB_DATA15         0xffe0123c            /*  Cacheability Protection Lookaside Buffer Descriptor Status               */
#define REG_L1_IM_TEST_CMD            0xffe01300            /*  Instruction Test Command Register                                        */
#define REG_L1_IM_ITEST_DATA0         0xffe01400            /*  Instruction Test Data Register                                           */
#define REG_L1_IM_ITEST_DATA1         0xffe01404            /*  Instruction Test Data Register                                           */

/* ===================================================================================================================================== 
       Instruction Memory Unit Register Field Definitions
   ===================================================================================================================================== */
/* -------------------------------------------------------------------------------------------------
        CTL                                 Bits              Description
   ------------------------------------------------------------------------------------------------- */
#define BITP_L1_IM_CTL_LRUPRIORST           13            /*  LRU Priority Reset                     */
#define BITP_L1_IM_CTL_LOC                   3            /*  Cache Way Lock                         */
#define BITP_L1_IM_CTL_CFG                   2            /*  Configure L1 code memory as cache      */
#define BITP_L1_IM_CTL_ENCPLB                1            /*  Enable ICPLB                           */
/* -------------------------------------------------------------------------------------------------
        CTL                                 Masks 
   ------------------------------------------------------------------------------------------------- */
#define BITM_L1_IM_CTL_LRUPRIORST           0x00002000
#define BITM_L1_IM_CTL_LOC                  0x00000078
#define BITM_L1_IM_CTL_CFG                  0x00000004
#define BITM_L1_IM_CTL_ENCPLB               0x00000002

/* -------------------------------------------------------------------------------------------------
        STAT                                Bits              Description
   ------------------------------------------------------------------------------------------------- */
#define BITP_L1_IM_STAT_ILLADDR             19            /*  Illegal Address                        */
#define BITP_L1_IM_STAT_MODE                17            /*  Access Mode                            */
#define BITP_L1_IM_STAT_FAULT                0            /*  Fault Status                           */
/* -------------------------------------------------------------------------------------------------
        STAT                                Masks 
   ------------------------------------------------------------------------------------------------- */
#define BITM_L1_IM_STAT_ILLADDR             0x00080000
#define BITM_L1_IM_STAT_MODE                0x00020000
#define BITM_L1_IM_STAT_FAULT               0x0000ffff

/* -------------------------------------------------------------------------------------------------
        CPLB_ADDRn                          Bits              Description
   ------------------------------------------------------------------------------------------------- */
#define BITP_L1_IM_CPLB_ADDR_ADDR           10            /*  Address for match                      */
/* -------------------------------------------------------------------------------------------------
        CPLB_ADDRn                          Masks 
   ------------------------------------------------------------------------------------------------- */
#define BITM_L1_IM_CPLB_ADDR_ADDR           0xfffffc00

/* -------------------------------------------------------------------------------------------------
        CPLB_DATAn                          Bits              Description
   ------------------------------------------------------------------------------------------------- */
#define BITP_L1_IM_CPLB_DATA_L1_CHBL        12            /*  L1 Cacheable                           */
#define BITP_L1_IM_CPLB_DATA_LRUPRIO         8            /*  Least Recently Used Priority           */
#define BITP_L1_IM_CPLB_DATA_UREAD           2            /*  Allow User Read                        */
#define BITP_L1_IM_CPLB_DATA_LOCK            1            /*  CPLB Lock                              */
#define BITP_L1_IM_CPLB_DATA_VALID           0            /*  CPLB Valid                             */
/* -------------------------------------------------------------------------------------------------
        CPLB_DATAn                          Masks 
   ------------------------------------------------------------------------------------------------- */
#define BITM_L1_IM_CPLB_DATA_L1_CHBL        0x00001000
#define BITM_L1_IM_CPLB_DATA_LRUPRIO        0x00000100
#define BITM_L1_IM_CPLB_DATA_UREAD          0x00000004
#define BITM_L1_IM_CPLB_DATA_LOCK           0x00000002
#define BITM_L1_IM_CPLB_DATA_VALID          0x00000001

/* -------------------------------------------------------------------------------------------------
        TEST_CMD                            Bits              Description
   ------------------------------------------------------------------------------------------------- */
#define BITP_L1_IM_TEST_CMD_WAYSEL          26            /*  Access Way/Instruction Address Bit 11  */
#define BITP_L1_IM_TEST_CMD_SBNK            16            /*  Subbank Access                         */
#define BITP_L1_IM_TEST_CMD_SET              5            /*  Set Index                              */
#define BITP_L1_IM_TEST_CMD_DW               3            /*  Double Word Index                      */
#define BITP_L1_IM_TEST_CMD_TAGSELB          2            /*  Array Access                           */
#define BITP_L1_IM_TEST_CMD_RW               1            /*  Read/Write Access                      */
/* -------------------------------------------------------------------------------------------------
        TEST_CMD                            Masks 
   ------------------------------------------------------------------------------------------------- */
#define BITM_L1_IM_TEST_CMD_WAYSEL          0x04000000
#define BITM_L1_IM_TEST_CMD_SBNK            0x00030000
#define BITM_L1_IM_TEST_CMD_SET             0x000007e0
#define BITM_L1_IM_TEST_CMD_DW              0x00000018
#define BITM_L1_IM_TEST_CMD_TAGSELB         0x00000004
#define BITM_L1_IM_TEST_CMD_RW              0x00000002


/* =====================================================================================================================================
       Interrupt Controller Registers
   ===================================================================================================================================== */
#define REG_ICU_EVT0                  0xffe02000            /*  Event Vector                                                             */
#define REG_ICU_EVT1                  0xffe02004            /*  Event Vector                                                             */
#define REG_ICU_EVT2                  0xffe02008            /*  Event Vector                                                             */
#define REG_ICU_EVT3                  0xffe0200c            /*  Event Vector                                                             */
#define REG_ICU_EVT4                  0xffe02010            /*  Event Vector                                                             */
#define REG_ICU_EVT5                  0xffe02014            /*  Event Vector                                                             */
#define REG_ICU_EVT6                  0xffe02018            /*  Event Vector                                                             */
#define REG_ICU_EVT7                  0xffe0201c            /*  Event Vector                                                             */
#define REG_ICU_EVT8                  0xffe02020            /*  Event Vector                                                             */
#define REG_ICU_EVT9                  0xffe02024            /*  Event Vector                                                             */
#define REG_ICU_EVT10                 0xffe02028            /*  Event Vector                                                             */
#define REG_ICU_EVT11                 0xffe0202c            /*  Event Vector                                                             */
#define REG_ICU_EVT12                 0xffe02030            /*  Event Vector                                                             */
#define REG_ICU_EVT13                 0xffe02034            /*  Event Vector                                                             */
#define REG_ICU_EVT14                 0xffe02038            /*  Event Vector                                                             */
#define REG_ICU_EVT15                 0xffe0203c            /*  Event Vector                                                             */
#define REG_ICU_IMASK                 0xffe02104            /*  Interrupt Mask Register                                                  */
#define REG_ICU_IPEND                 0xffe02108            /*  Interrupts Pending Register                                              */
#define REG_ICU_ILAT                  0xffe0210c            /*  Interrupt Latch Register                                                 */
#define REG_ICU_IPRIO                 0xffe02110            /*  Interrupt Priority Register                                              */

/* ===================================================================================================================================== 
       Interrupt Controller Register Field Definitions
   ===================================================================================================================================== */
/* -------------------------------------------------------------------------------------------------
        IMASK                               Bits              Description
   ------------------------------------------------------------------------------------------------- */
#define BITP_ICU_IMASK_IVG15                15            /*  IVG15 interrupt bit position           */
#define BITP_ICU_IMASK_IVG14                14            /*  IVG14 interrupt bit position           */
#define BITP_ICU_IMASK_IVG13                13            /*  IVG13 interrupt bit position           */
#define BITP_ICU_IMASK_IVG12                12            /*  IVG12 interrupt bit position           */
#define BITP_ICU_IMASK_IVG11                11            /*  IVG11 interrupt bit position           */
#define BITP_ICU_IMASK_IVG10                10            /*  IVG10 interrupt bit position           */
#define BITP_ICU_IMASK_IVG9                  9            /*  IVG9 interrupt bit position            */
#define BITP_ICU_IMASK_IVG8                  8            /*  IVG8 interrupt bit position            */
#define BITP_ICU_IMASK_IVG7                  7            /*  IVG7 interrupt bit position            */
#define BITP_ICU_IMASK_IVTMR                 6            /*  Timer interrupt bit position           */
#define BITP_ICU_IMASK_IVHW                  5            /*  Hardware Error interrupt bit position  */
#define BITP_ICU_IMASK_UNMASKABLE            0            /*  Unmaskable interrupts                  */
/* -------------------------------------------------------------------------------------------------
        IMASK                               Masks 
   ------------------------------------------------------------------------------------------------- */
#define BITM_ICU_IMASK_IVG15                0x00008000
#define BITM_ICU_IMASK_IVG14                0x00004000
#define BITM_ICU_IMASK_IVG13                0x00002000
#define BITM_ICU_IMASK_IVG12                0x00001000
#define BITM_ICU_IMASK_IVG11                0x00000800
#define BITM_ICU_IMASK_IVG10                0x00000400
#define BITM_ICU_IMASK_IVG9                 0x00000200
#define BITM_ICU_IMASK_IVG8                 0x00000100
#define BITM_ICU_IMASK_IVG7                 0x00000080
#define BITM_ICU_IMASK_IVTMR                0x00000040
#define BITM_ICU_IMASK_IVHW                 0x00000020
#define BITM_ICU_IMASK_UNMASKABLE           0x0000001f

/* -------------------------------------------------------------------------------------------------
        IPEND                               Bits              Description
   ------------------------------------------------------------------------------------------------- */
#define BITP_ICU_IPEND_IVG15                15            /*  IVG15 interrupt bit position           */
#define BITP_ICU_IPEND_IVG14                14            /*  IVG14 interrupt bit position           */
#define BITP_ICU_IPEND_IVG13                13            /*  IVG13 interrupt bit position           */
#define BITP_ICU_IPEND_IVG12                12            /*  IVG12 interrupt bit position           */
#define BITP_ICU_IPEND_IVG11                11            /*  IVG11 interrupt bit position           */
#define BITP_ICU_IPEND_IVG10                10            /*  IVG10 interrupt bit position           */
#define BITP_ICU_IPEND_IVG9                  9            /*  IVG9 interrupt bit position            */
#define BITP_ICU_IPEND_IVG8                  8            /*  IVG8 interrupt bit position            */
#define BITP_ICU_IPEND_IVG7                  7            /*  IVG7 interrupt bit position            */
#define BITP_ICU_IPEND_IVTMR                 6            /*  Timer interrupt bit position           */
#define BITP_ICU_IPEND_IVHW                  5            /*  Hardware Error interrupt bit position  */
#define BITP_ICU_IPEND_IRPTEN                4            /*  Global interrupt enable bit position   */
#define BITP_ICU_IPEND_EVX                   3            /*  Exception bit position                 */
#define BITP_ICU_IPEND_NMI                   2            /*  Non Maskable interrupt bit position    */
#define BITP_ICU_IPEND_RST                   1            /*  Reset interrupt bit position           */
#define BITP_ICU_IPEND_EMU                   0            /*  Emulator interrupt bit position        */
/* -------------------------------------------------------------------------------------------------
        IPEND                               Masks 
   ------------------------------------------------------------------------------------------------- */
#define BITM_ICU_IPEND_IVG15                0x00008000
#define BITM_ICU_IPEND_IVG14                0x00004000
#define BITM_ICU_IPEND_IVG13                0x00002000
#define BITM_ICU_IPEND_IVG12                0x00001000
#define BITM_ICU_IPEND_IVG11                0x00000800
#define BITM_ICU_IPEND_IVG10                0x00000400
#define BITM_ICU_IPEND_IVG9                 0x00000200
#define BITM_ICU_IPEND_IVG8                 0x00000100
#define BITM_ICU_IPEND_IVG7                 0x00000080
#define BITM_ICU_IPEND_IVTMR                0x00000040
#define BITM_ICU_IPEND_IVHW                 0x00000020
#define BITM_ICU_IPEND_IRPTEN               0x00000010
#define BITM_ICU_IPEND_EVX                  0x00000008
#define BITM_ICU_IPEND_NMI                  0x00000004
#define BITM_ICU_IPEND_RST                  0x00000002
#define BITM_ICU_IPEND_EMU                  0x00000001

/* -------------------------------------------------------------------------------------------------
        ILAT                                Bits              Description
   ------------------------------------------------------------------------------------------------- */
#define BITP_ICU_ILAT_IVG15                 15            /*  IVG15 interrupt bit position           */
#define BITP_ICU_ILAT_IVG14                 14            /*  IVG14 interrupt bit position           */
#define BITP_ICU_ILAT_IVG13                 13            /*  IVG13 interrupt bit position           */
#define BITP_ICU_ILAT_IVG12                 12            /*  IVG12 interrupt bit position           */
#define BITP_ICU_ILAT_IVG11                 11            /*  IVG11 interrupt bit position           */
#define BITP_ICU_ILAT_IVG10                 10            /*  IVG10 interrupt bit position           */
#define BITP_ICU_ILAT_IVG9                   9            /*  IVG9 interrupt bit position            */
#define BITP_ICU_ILAT_IVG8                   8            /*  IVG8 interrupt bit position            */
#define BITP_ICU_ILAT_IVG7                   7            /*  IVG7 interrupt bit position            */
#define BITP_ICU_ILAT_IVTMR                  6            /*  Timer interrupt bit position           */
#define BITP_ICU_ILAT_IVHW                   5            /*  Hardware Error interrupt bit position  */
#define BITP_ICU_ILAT_EVX                    3            /*  Exception bit position                 */
#define BITP_ICU_ILAT_NMI                    2            /*  Non Maskable interrupt bit position    */
#define BITP_ICU_ILAT_RST                    1            /*  Reset interrupt bit position           */
#define BITP_ICU_ILAT_EMU                    0            /*  Emulator interrupt bit position        */
/* -------------------------------------------------------------------------------------------------
        ILAT                                Masks 
   ------------------------------------------------------------------------------------------------- */
#define BITM_ICU_ILAT_IVG15                 0x00008000
#define BITM_ICU_ILAT_IVG14                 0x00004000
#define BITM_ICU_ILAT_IVG13                 0x00002000
#define BITM_ICU_ILAT_IVG12                 0x00001000
#define BITM_ICU_ILAT_IVG11                 0x00000800
#define BITM_ICU_ILAT_IVG10                 0x00000400
#define BITM_ICU_ILAT_IVG9                  0x00000200
#define BITM_ICU_ILAT_IVG8                  0x00000100
#define BITM_ICU_ILAT_IVG7                  0x00000080
#define BITM_ICU_ILAT_IVTMR                 0x00000040
#define BITM_ICU_ILAT_IVHW                  0x00000020
#define BITM_ICU_ILAT_EVX                   0x00000008
#define BITM_ICU_ILAT_NMI                   0x00000004
#define BITM_ICU_ILAT_RST                   0x00000002
#define BITM_ICU_ILAT_EMU                   0x00000001

/* -------------------------------------------------------------------------------------------------
        IPRIO                               Bits              Description
   ------------------------------------------------------------------------------------------------- */
#define BITP_ICU_IPRIO_IPRIO_MARK            0            /*  Priority Watermark                     */
/* -------------------------------------------------------------------------------------------------
        IPRIO                               Masks 
   ------------------------------------------------------------------------------------------------- */
#define BITM_ICU_IPRIO_IPRIO_MARK           0x0000000f


/* =====================================================================================================================================
       Timer Registers
   ===================================================================================================================================== */
#define REG_TMR_CTL                   0xffe03000            /*  Timer Control Register                                                   */
#define REG_TMR_PERIOD                0xffe03004            /*  Timer Period Register                                                    */
#define REG_TMR_SCALE                 0xffe03008            /*  Timer Scale Register                                                     */
#define REG_TMR_CNT                   0xffe0300c            /*  Timer Count Register                                                     */

/* ===================================================================================================================================== 
       Timer Register Field Definitions
   ===================================================================================================================================== */
/* -------------------------------------------------------------------------------------------------
        CTL                                 Bits              Description
   ------------------------------------------------------------------------------------------------- */
#define BITP_TMR_CTL_INT                     3            /*  Timer generated interrupt (sticky)     */
#define BITP_TMR_CTL_AUTORLD                 2            /*  Timer auto reload                      */
#define BITP_TMR_CTL_EN                      1            /*  Timer enable                           */
#define BITP_TMR_CTL_PWR                     0            /*  Timer Low Power Control                */
/* -------------------------------------------------------------------------------------------------
        CTL                                 Masks 
   ------------------------------------------------------------------------------------------------- */
#define BITM_TMR_CTL_INT                    0x00000008
#define BITM_TMR_CTL_AUTORLD                0x00000004
#define BITM_TMR_CTL_EN                     0x00000002
#define BITM_TMR_CTL_PWR                    0x00000001

/* -------------------------------------------------------------------------------------------------
        SCALE                               Bits              Description
   ------------------------------------------------------------------------------------------------- */
#define BITP_TMR_SCALE_SCALE                 0            /*  Scaling factor                         */
/* -------------------------------------------------------------------------------------------------
        SCALE                               Masks 
   ------------------------------------------------------------------------------------------------- */
#define BITM_TMR_SCALE_SCALE                0x000000ff


/* =====================================================================================================================================
       Debug Unit Registers
   ===================================================================================================================================== */
#define REG_DBG_DSPID                 0xffe05000            /*  DSP Identification Register                                              */

/* ===================================================================================================================================== 
       Debug Unit Register Field Definitions
   ===================================================================================================================================== */
/* -------------------------------------------------------------------------------------------------
        DSPID                               Bits              Description
   ------------------------------------------------------------------------------------------------- */
#define BITP_DBG_DSPID_COMPANY              24            /*  Analog Devices, Inc.                   */
#define BITP_DBG_DSPID_MAJOR                16            /*  Major Architectural Change             */
#define BITP_DBG_DSPID_MINOR                 0            /*  Implementation                         */
/* -------------------------------------------------------------------------------------------------
        DSPID                               Masks 
   ------------------------------------------------------------------------------------------------- */
#define BITM_DBG_DSPID_COMPANY              0xff000000
#define BITM_DBG_DSPID_MAJOR                0x00ff0000
#define BITM_DBG_DSPID_MINOR                0x0000ffff


/* =====================================================================================================================================
       Trace Unit Registers
   ===================================================================================================================================== */
#define REG_TB_CTL                    0xffe06000            /*  Trace Buffer Control Register                                            */
#define REG_TB_STAT                   0xffe06004            /*  Trace Buffer Status Register                                             */
#define REG_TB_BUF                    0xffe06100            /*  Trace Buffer                                                             */

/* ===================================================================================================================================== 
       Trace Unit Register Field Definitions
   ===================================================================================================================================== */
/* -------------------------------------------------------------------------------------------------
        CTL                                 Bits              Description
   ------------------------------------------------------------------------------------------------- */
#define BITP_TB_CTL_COMPRESS                 3            /*  Trace Buffer Compression               */
#define BITP_TB_CTL_OVF                      2            /*  Trace Buffer Overflow                  */
#define BITP_TB_CTL_EN                       1            /*  Trace Buffer Enable                    */
#define BITP_TB_CTL_PWR                      0            /*  Trace Buffer Power                     */
/* -------------------------------------------------------------------------------------------------
        CTL                                 Masks 
   ------------------------------------------------------------------------------------------------- */
#define BITM_TB_CTL_COMPRESS                0x00000018
#define BITM_TB_CTL_OVF                     0x00000004
#define BITM_TB_CTL_EN                      0x00000002
#define BITM_TB_CTL_PWR                     0x00000001

/* -------------------------------------------------------------------------------------------------
        STAT                                Bits              Description
   ------------------------------------------------------------------------------------------------- */
#define BITP_TB_STAT_CNT                     0            /*  Trace Buffer Count                     */
/* -------------------------------------------------------------------------------------------------
        STAT                                Masks 
   ------------------------------------------------------------------------------------------------- */
#define BITM_TB_STAT_CNT                    0x0000001f


/* =====================================================================================================================================
       Watchpoint Unit Registers
   ===================================================================================================================================== */
#define REG_WP_IACTL                  0xffe07000            /*  Watchpoint Instruction Address Control Register 01                       */
#define REG_WP_IADDR0                 0xffe07040            /*  Watchpoint Instruction Address Register                                  */
#define REG_WP_IADDR1                 0xffe07044            /*  Watchpoint Instruction Address Register                                  */
#define REG_WP_IADDR2                 0xffe07048            /*  Watchpoint Instruction Address Register                                  */
#define REG_WP_IADDR3                 0xffe0704c            /*  Watchpoint Instruction Address Register                                  */
#define REG_WP_IADDR4                 0xffe07050            /*  Watchpoint Instruction Address Register                                  */
#define REG_WP_IADDR5                 0xffe07054            /*  Watchpoint Instruction Address Register                                  */
#define REG_WP_DADDR0                 0xffe07058            /*  Watchpoint Data Address Register                                         */
#define REG_WP_DADDR1                 0xffe0705c            /*  Watchpoint Data Address Register                                         */
#define REG_WP_IACNT0                 0xffe07080            /*  Watchpoint Instruction Address Count Register                            */
#define REG_WP_IACNT1                 0xffe07084            /*  Watchpoint Instruction Address Count Register                            */
#define REG_WP_IACNT2                 0xffe07088            /*  Watchpoint Instruction Address Count Register                            */
#define REG_WP_IACNT3                 0xffe0708c            /*  Watchpoint Instruction Address Count Register                            */
#define REG_WP_IACNT4                 0xffe07090            /*  Watchpoint Instruction Address Count Register                            */
#define REG_WP_IACNT5                 0xffe07094            /*  Watchpoint Instruction Address Count Register                            */
#define REG_WP_DACNT0                 0xffe07098            /*  Watchpoint Data Address Count Value Register                             */
#define REG_WP_DACNT1                 0xffe0709c            /*  Watchpoint Data Address Count Value Register                             */
#define REG_WP_DACTL                  0xffe07100            /*  Watchpoint Data Address Control Register                                 */
#define REG_WP_STAT                   0xffe07200            /*  Watchpoint Status Register                                               */

/* ===================================================================================================================================== 
       Watchpoint Unit Register Field Definitions
   ===================================================================================================================================== */
/* -------------------------------------------------------------------------------------------------
        IACTL                               Bits              Description
   ------------------------------------------------------------------------------------------------- */
#define BITP_WP_IACTL_WPAND                 25            /*  And Triggers                           */
#define BITP_WP_IACTL_ACT5                  24            /*  Action field for WPIA5                 */
#define BITP_WP_IACTL_ACT4                  23            /*  Action field for WPIA4                 */
#define BITP_WP_IACTL_ENCNT5                22            /*  Enable Counter for WPIA5               */
#define BITP_WP_IACTL_ENCNT4                21            /*  Enable Counter for WPIA4               */
#define BITP_WP_IACTL_ENIA5                 20            /*  Enable WPIA5                           */
#define BITP_WP_IACTL_ENIA4                 19            /*  Enable WPIA4                           */
#define BITP_WP_IACTL_INVIR45               18            /*  Invert Instruction Range 45            */
#define BITP_WP_IACTL_ENIR45                17            /*  Enable Instruction Range 45            */
#define BITP_WP_IACTL_ACT3                  16            /*  Action field for WPIA3                 */
#define BITP_WP_IACTL_ACT2                  15            /*  Action field for WPIA2                 */
#define BITP_WP_IACTL_ENCNT3                14            /*  Enable Counter for WPIA3               */
#define BITP_WP_IACTL_ENCNT2                13            /*  Enable Counter for WPIA2               */
#define BITP_WP_IACTL_ENIA3                 12            /*  Enable WPIA3                           */
#define BITP_WP_IACTL_ENIA2                 11            /*  Enable WPIA2                           */
#define BITP_WP_IACTL_INVIR23               10            /*  Invert Instruction Range 23            */
#define BITP_WP_IACTL_ENIR23                 9            /*  Enable Instruction Range 23            */
#define BITP_WP_IACTL_ACT1                   8            /*  Action field for WPIA1                 */
#define BITP_WP_IACTL_ACT0                   7            /*  Action field for WPIA0                 */
#define BITP_WP_IACTL_ENCNT1                 6            /*  Enable Counter for WPIA1               */
#define BITP_WP_IACTL_ENCNT0                 5            /*  Enable Counter for WPIA0               */
#define BITP_WP_IACTL_ENIA1                  4            /*  Enable WPIA1                           */
#define BITP_WP_IACTL_ENIA0                  3            /*  Enable WPIA0                           */
#define BITP_WP_IACTL_INVIR01                2            /*  Invert Instruction Range 01            */
#define BITP_WP_IACTL_ENIR01                 1            /*  Enable Instruction Range 01            */
#define BITP_WP_IACTL_PWR                    0            /*  Power                                  */
/* -------------------------------------------------------------------------------------------------
        IACTL                               Masks 
   ------------------------------------------------------------------------------------------------- */
#define BITM_WP_IACTL_WPAND                 0x02000000
#define BITM_WP_IACTL_ACT5                  0x01000000
#define BITM_WP_IACTL_ACT4                  0x00800000
#define BITM_WP_IACTL_ENCNT5                0x00400000
#define BITM_WP_IACTL_ENCNT4                0x00200000
#define BITM_WP_IACTL_ENIA5                 0x00100000
#define BITM_WP_IACTL_ENIA4                 0x00080000
#define BITM_WP_IACTL_INVIR45               0x00040000
#define BITM_WP_IACTL_ENIR45                0x00020000
#define BITM_WP_IACTL_ACT3                  0x00010000
#define BITM_WP_IACTL_ACT2                  0x00008000
#define BITM_WP_IACTL_ENCNT3                0x00004000
#define BITM_WP_IACTL_ENCNT2                0x00002000
#define BITM_WP_IACTL_ENIA3                 0x00001000
#define BITM_WP_IACTL_ENIA2                 0x00000800
#define BITM_WP_IACTL_INVIR23               0x00000400
#define BITM_WP_IACTL_ENIR23                0x00000200
#define BITM_WP_IACTL_ACT1                  0x00000100
#define BITM_WP_IACTL_ACT0                  0x00000080
#define BITM_WP_IACTL_ENCNT1                0x00000040
#define BITM_WP_IACTL_ENCNT0                0x00000020
#define BITM_WP_IACTL_ENIA1                 0x00000010
#define BITM_WP_IACTL_ENIA0                 0x00000008
#define BITM_WP_IACTL_INVIR01               0x00000004
#define BITM_WP_IACTL_ENIR01                0x00000002
#define BITM_WP_IACTL_PWR                   0x00000001

/* -------------------------------------------------------------------------------------------------
        IACNTn                              Bits              Description
   ------------------------------------------------------------------------------------------------- */
#define BITP_WP_IACNT_CNT                    0            /*  Count Value                            */
/* -------------------------------------------------------------------------------------------------
        IACNTn                              Masks 
   ------------------------------------------------------------------------------------------------- */
#define BITM_WP_IACNT_CNT                   0x0000ffff

/* -------------------------------------------------------------------------------------------------
        DACNTn                              Bits              Description
   ------------------------------------------------------------------------------------------------- */
#define BITP_WP_DACNT_CNT                    0            /*  Count Value                            */
/* -------------------------------------------------------------------------------------------------
        DACNTn                              Masks 
   ------------------------------------------------------------------------------------------------- */
#define BITM_WP_DACNT_CNT                   0x0000ffff

/* -------------------------------------------------------------------------------------------------
        DACTL                               Bits              Description
   ------------------------------------------------------------------------------------------------- */
#define BITP_WP_DACTL_ACC1                  12            /*  Access type for WPDA1                  */
#define BITP_WP_DACTL_SRC1                  10            /*  DAG Source for WPDA1                   */
#define BITP_WP_DACTL_ACC0                   8            /*  Access type for WPDA0                  */
#define BITP_WP_DACTL_SRC0                   6            /*  DAG Source for WPDA0                   */
#define BITP_WP_DACTL_ENCNT1                 5            /*  Enable WPDA1 Counter                   */
#define BITP_WP_DACTL_ENCNT0                 4            /*  Enable WPDA0 Counter                   */
#define BITP_WP_DACTL_ENDA1                  3            /*  Enable WPDA1                           */
#define BITP_WP_DACTL_ENDA0                  2            /*  Enable WPDA0                           */
#define BITP_WP_DACTL_INVR                   1            /*  Invert Range Comparision               */
#define BITP_WP_DACTL_ENR                    0            /*  Enable Range Comparison                */
/* -------------------------------------------------------------------------------------------------
        DACTL                               Masks 
   ------------------------------------------------------------------------------------------------- */
#define BITM_WP_DACTL_ACC1                  0x00003000
#define BITM_WP_DACTL_SRC1                  0x00000c00
#define BITM_WP_DACTL_ACC0                  0x00000300
#define BITM_WP_DACTL_SRC0                  0x000000c0
#define BITM_WP_DACTL_ENCNT1                0x00000020
#define BITM_WP_DACTL_ENCNT0                0x00000010
#define BITM_WP_DACTL_ENDA1                 0x00000008
#define BITM_WP_DACTL_ENDA0                 0x00000004
#define BITM_WP_DACTL_INVR                  0x00000002
#define BITM_WP_DACTL_ENR                   0x00000001

/* -------------------------------------------------------------------------------------------------
        STAT                                Bits              Description
   ------------------------------------------------------------------------------------------------- */
#define BITP_WP_STAT_DA1                     7            /*  WPDA1 match                            */
#define BITP_WP_STAT_DA0                     6            /*  WPDA0 or WPDA0:1 range match           */
#define BITP_WP_STAT_IA5                     5            /*  WPIA5 match                            */
#define BITP_WP_STAT_IA4                     4            /*  WPIA4 or WPIA4:5 range match           */
#define BITP_WP_STAT_IA3                     3            /*  WPIA3 match                            */
#define BITP_WP_STAT_IA2                     2            /*  WPIA2 or WPIA2:3 range match           */
#define BITP_WP_STAT_IA1                     1            /*  WPIA1 match                            */
#define BITP_WP_STAT_IA0                     0            /*  WPIA0 or WPIA0:1 range match           */
/* -------------------------------------------------------------------------------------------------
        STAT                                Masks 
   ------------------------------------------------------------------------------------------------- */
#define BITM_WP_STAT_DA1                    0x00000080
#define BITM_WP_STAT_DA0                    0x00000040
#define BITM_WP_STAT_IA5                    0x00000020
#define BITM_WP_STAT_IA4                    0x00000010
#define BITM_WP_STAT_IA3                    0x00000008
#define BITM_WP_STAT_IA2                    0x00000004
#define BITM_WP_STAT_IA1                    0x00000002
#define BITM_WP_STAT_IA0                    0x00000001


/* =====================================================================================================================================
       Performance Monitor Registers
   ===================================================================================================================================== */
#define REG_PF_CTL                    0xffe08000            /*  Performance Monitor Control Register                                     */
#define REG_PF_CNTR0                  0xffe08100            /*  Performance Monitor Counter 0                                            */
#define REG_PF_CNTR1                  0xffe08104            /*  Performance Monitor Counter 1                                            */

/* ===================================================================================================================================== 
       Performance Monitor Register Field Definitions
   ===================================================================================================================================== */
/* -------------------------------------------------------------------------------------------------
        CTL                                 Bits              Description
   ------------------------------------------------------------------------------------------------- */
#define BITP_PF_CTL_CNT1                    25            /*  Count Cycles or Edges 1                */
#define BITP_PF_CTL_CNT0                    24            /*  Count Cycles or Edges 0                */
#define BITP_PF_CTL_MON1                    16            /*  Monitor 1 Events                       */
#define BITP_PF_CTL_ENA1                    14            /*  Enable Monitor 1                       */
#define BITP_PF_CTL_EVT1                    13            /*  Emulator or Exception Event 1          */
#define BITP_PF_CTL_MON0                     5            /*  Monitor 0 Events                       */
#define BITP_PF_CTL_ENA0                     3            /*  Enable Monitor 0                       */
#define BITP_PF_CTL_EVT0                     2            /*  Emulator or Exception Event 0          */
#define BITP_PF_CTL_PWR                      0            /*  Power                                  */
/* -------------------------------------------------------------------------------------------------
        CTL                                 Masks 
   ------------------------------------------------------------------------------------------------- */
#define BITM_PF_CTL_CNT1                    0x02000000
#define BITM_PF_CTL_CNT0                    0x01000000
#define BITM_PF_CTL_MON1                    0x00ff0000
#define BITM_PF_CTL_ENA1                    0x0000c000
#define BITM_PF_CTL_EVT1                    0x00002000
#define BITM_PF_CTL_MON0                    0x00001fe0
#define BITM_PF_CTL_ENA0                    0x00000018
#define BITM_PF_CTL_EVT0                    0x00000004
#define BITM_PF_CTL_PWR                     0x00000001


#endif	/* end ifndef _DEF_BLACKFIN_CORE_H */
