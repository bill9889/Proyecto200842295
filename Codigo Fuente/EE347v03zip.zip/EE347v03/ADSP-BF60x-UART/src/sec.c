/****************************************************************************/
/*                                                                          */
/*  Include Definitions                                                     */
/*                                                                          */
/****************************************************************************/
#include <stdio.h>
#include <stdlib.h>
#include <stdarg.h>
#include <string.h>

#include <ccblkfn.h>
#include <sysreg.h>
#include <sys/exception.h>

#include <cdefBF609.h>

#include "defBlackfin_Core.h"
#include "defBlackfin_SEC.h"
#include "cdefBlackfin_SEC.h"

#include "sec.h"

/****************************************************************************/
/*                                                                          */
/*  External FunctionDeclarations                                           */
/*                                                                          */
/****************************************************************************/

extern unsigned long sec_ivt_entries[];

/****************************************************************************/
/*                                                                          */
/*  Global Data Declarations                                                */
/*                                                                          */
/****************************************************************************/

/****************************************************************************/
/*                                                                          */
/*  External Data Declarations                                              */
/*                                                                          */
/****************************************************************************/

/****************************************************************************/
/*                                                                          */
/*  Static Data Declarations                                                */
/*                                                                          */
/****************************************************************************/

typedef void (*SEC_HANDLER_FUNC)(void);

/****************************************************************************/
/*                                                                          */
/*  Functions                                                               */
/*                                                                          */
/****************************************************************************/

/****************************************************************************/
/*                                                                          */
/*  void sec_install_system_event_handler(void)                             */
/*                                                                          */
/****************************************************************************/
void sec_install_system_event_handler(void)
{
    // Install the main system event handler
//    register_handler_ex(ik_ivg11,sec_system_event_handler,EX_INT_ENABLE);
    *pREG_ICU_EVT11 = (unsigned long)sec_system_event_handler;

    // Enable the core to process system events
    *pREG_ICU_IMASK |= BITM_ICU_IMASK_IVG11;

    // Enable the SEC
    *pREG_SEC_GCTL = 1;

    // Check if it's enabled or for an error
//    #warning: TODO

    // Enable the SEC Core Interface
    *pREG_SEC_CCTL0 = 1;

    ssync();
}


/****************************************************************************/
/*                                                                          */
/*  void sec_install_irq_handler(long, long, long)                          */
/*                                                                          */
/*  Argument 1: IRQ Number                                                  */
/*  Argument 2: Priority                                                    */
/*  Argument 3: Pointer to ISR                                              */
/*                                                                          */
/****************************************************************************/
void sec_install_irq_handler(unsigned long IrqNum, unsigned long Prio, unsigned long Isr)
{
    volatile unsigned long *pRegSecCtl = (volatile unsigned long*) (REG_SEC_SCTL0 + (IrqNum << 3));
    sec_ivt_entries[IrqNum] = Isr;
    *pRegSecCtl = ( BITM_SEC_SCTL_IEN | BITM_SEC_SCTL_SEN | (Prio << BITP_SEC_SCTL_PRIO) );
    ssync();
}


/*******************************************************************************/
/*                                                                             */
/*  EX_INTERRUPT_HANDLER(sec_system_event_handler)                             */
/*                                                                             */
/*  All system events are issued on EVT11. This is the global event handler    */
/*  to deal with all those events that results in the appropriate service      */
/*  routine being called.                                                      */
/*                                                                             */
/* The general procedure for this event handler is:                            */
/*                                                                             */
/*  1) Read SEC_CSID to determine the interrupt source                         */
/*  2) Write SEC_CSID to acknowledge the interrupt,                            */
/*     SEC_CSTATn.PND cleared, SEC_CSTATn.ACT set                              */
/*  3) Fetch the ISR function pointer for the interrupt                        */
/*  4) Call the ISR                                                            */
/*  5) Clear the serviced interrupt by writing SEC_END, SEC_CSTATn.ACT cleared */
/*  6) Return from interrupt                                                   */
/*                                                                             */
/*******************************************************************************/
EX_INTERRUPT_HANDLER(sec_system_event_handler)
{
    SEC_HANDLER_FUNC SecHandler;
    unsigned char sid = (*pREG_SEC_CSID0 & BITM_SEC_CSID_SID);
    *pREG_SEC_CSID0 = sid; // any write generates an interrupt acknowledge
    SecHandler = (SEC_HANDLER_FUNC)sec_ivt_entries[sid];
    SecHandler();
    *pREG_SEC_END = sid;
    ssync();
}


/****************************************************************************/
/*                                                                          */
/*  void sec_unused_error_handler(void)                                     */
/*                                                                          */
/****************************************************************************/
void sec_unused_error_handler(void)
{
    while(0) { asm("EMUEXCPT;"); idle(); }
}
