#define EMUEXCPT() asm("EMUEXCPT;")

/*****************************************************************************
 Prototypes
******************************************************************************/

void full_on(void);
uint32_t get_pllclk_hz(uint32_t);
uint32_t get_pllclk_ns(uint32_t);
uint32_t get_cclk_hz(void);
uint32_t get_cclk_ns(void);
uint32_t get_sysclk_hz(uint32_t, uint32_t, uint32_t);
uint32_t get_s0clk_hz(void);
uint32_t get_s1clk_hz(void);
uint32_t get_ddrclk_hz(void);
uint32_t get_ddrclk_ns(void);

void smc_en(void);
void dll_lock_wait(void);
void dmc_en(void);
void dmc_en_dyn(void);
void dram_selfrefresh_enter(void);
void dram_selfrefresh_exit(void);

EX_EXCEPTION_HANDLER(HwErrorHandler);
EX_EXCEPTION_HANDLER(ExceptionHandler);

void CoreTimer(uint32_t count);
long CoreTimer2(unsigned long PosVal, const char *command);

long wait(unsigned long, const char*);
long wait2(unsigned long, const char*);

/****************************************************************************
 EOF
*****************************************************************************/
