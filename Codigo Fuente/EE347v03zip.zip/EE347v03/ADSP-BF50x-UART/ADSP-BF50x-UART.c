/*****************************************************************************
**                                                                          **
**  Name:   UART Software Interface                                         **
**                                                                          **
******************************************************************************

(C) Copyright 2009 - Analog Devices, Inc.  All rights reserved.

File Name:      ADSP-BF50x-UART.c

Date Modified:  08/10/2010

Processor:      ADSP-BF50x

Software:       VisualDSP++ 5.0

Purpose:        This file contains some library functions commonly used on UART processing.

******************************************************************************/

/*******************************************************************************
*
*  Include File Area
*
*******************************************************************************/

#include <blackfin.h>

#include <stdio.h>
#include <stdarg.h>
#include <string.h>

#include <sys/exception.h>

#include "..\Common Code\init_platform.h"
#include "..\Common Code\system.h"

#include "..\Common Code\BfDebugger.h"

#include "ADSP-BF50x-UART.h"

/*******************************************************************************
*
*  Internal Constants/Definitions Area
*
*******************************************************************************/

#define LOOP                0       /* only for test purposes */

#ifndef UART_LCR_VAL
#define UART_LCR_VAL WLS(8)
#endif

#define UART0TX             PG12
#define UART0RX             PG13
#define UART0RTS            PG14
#define UART0CTS            PG15

#define UART1TX             PF6
#define UART1RX             PF7
#define UART1CTS            PF8
#define UART1RTS            PF9

#define UART0_MMR_OFFSET    0x0000
#define UART1_MMR_OFFSET    0x1C00

#define UART0_TIMER         2
#define UART1_TIMER         3

#define DMA_MAX_COUNT       11

/*******************************************************************************
*
*  Internal Data Area
*
*******************************************************************************/

char UartRcvBuf[STRINGSIZE];

/*******************************************************************************
*
*  Internal Functions Area
*
*******************************************************************************/

EX_INTERRUPT_HANDLER(UartDmaInterruptsHandlerStatus);
EX_INTERRUPT_HANDLER(UartInterruptsHandlerStatus);
//EX_INTERRUPT_HANDLER(UartInterruptsHandlerData);
EX_REENTRANT_HANDLER(UartInterruptsHandlerData);

/*******************************************************************************
*
*  Functions Area
*
*******************************************************************************/

//***************************************
//*
//* Function Name : short UartGpioInit(unsigned char UartNum)
//* Description   : Setup Port Structure
//*
//* Parameters    : none
//* Returns       : NULL. If UartGpioInit is unsuccessful, a negative value is returned.
//* Globals       : none
//*
short UartGpioInit(unsigned char UartNum)
{
    switch (UartNum) {
        case 0: *pPORTG_MUX &= ~(0xF000);
                *pPORTG_FER |= (UART0TX|UART0RX|UART0RTS|UART0CTS);
                break;
        case 1: *pPORTF_MUX &= ~(0x03C0);
                *pPORTF_FER |= (UART1TX|UART1RX|UART1RTS|UART1CTS);
                break;
        default: return -1;
    }
    return 0;
}


/***************************************
 *
 * Function Name : UartDmaInterruptsHandlerStatus
 * Description   : Generic DMA Status Interrupts Handler
 *
 * Parameters    : none
 * Returns       : none
 * Globals       : none
 */
EX_INTERRUPT_HANDLER(UartDmaInterruptsHandlerStatus)
{
    unsigned char DmaChan = 0;
    volatile unsigned short *pDmaIrqStatus = 0;

    if (*pSIC_ISR0 & IRQ_DMA_ERR0) {
         for (DmaChan = 0 ; DmaChan <= DMA_MAX_COUNT ; DmaChan++) {
            pDmaIrqStatus = (volatile unsigned short*) (DMA0_IRQ_STATUS + DmaChan * 0x40);
            if (*pDmaIrqStatus & DMA_ERR) { printf("%s(): DMA%d Error\n",__func__,DmaChan); *pDmaIrqStatus = DMA_ERR; return; }
            }
         }
    else { asm("EMUEXCPT; jump 0;"); }
}


/***************************************
 *
 * Function Name : UartInterruptsHandlerStatus
 * Description   : Generic UART Status Interrupts Handler
 *
 * Parameters    : none
 * Returns       : none
 * Globals       : none
 */
EX_INTERRUPT_HANDLER(UartInterruptsHandlerStatus)
{
    unsigned short UartMmrOffset = 0;
    unsigned  char UartNum       = 0;
    unsigned  long SicIsr0       = 0;
    char c;

    SicIsr0 = *pSIC_ISR0;

         if (SicIsr0 & IRQ_UART0_ERR) { UartMmrOffset = UART0_MMR_OFFSET; UartNum = 0; }
    else if (SicIsr0 & IRQ_UART1_ERR) { UartMmrOffset = UART1_MMR_OFFSET; UartNum = 1; }
    else { asm("EMUEXCPT; jump 0;"); }

    volatile unsigned short *pUartMcr  = (volatile unsigned short*) (UART0_MCR + UartMmrOffset);
    volatile unsigned short *pUartLsr  = (volatile unsigned short*) (UART0_LSR + UartMmrOffset);
    volatile unsigned short *pUartMsr  = (volatile unsigned short*) (UART0_MSR + UartMmrOffset);

    if (*pUartLsr &  TFI) { *pUartLsr =  TFI; return; }

    if (*pUartLsr &   BI) { *pUartLsr =   BI; ERROR(1,"%s(): UART%d Break Interrupt\n",__func__,UartNum); }
    if (*pUartLsr &   FE) { *pUartLsr =   FE; ERROR(1,"%s(): UART%d Framing Error\n",__func__,UartNum); }
    if (*pUartLsr &   PE) { *pUartLsr =   PE; ERROR(1,"%s(): UART%d Parity Error\n",__func__,UartNum); }
    if (*pUartMsr & SCTS) { *pUartMsr = SCTS;  /*INFO(1,"%s(): UART%d_CTS transitioned from 0 to 1\n",__func__,UartNum);*/ }

    if (*pUartMsr & RFCS) {
        if (*pUartMcr & RFIT) { INFO(1,"%s(): UART%d Receive Buffer contains 4 or more entries\n",__func__,UartNum); }
        else                  { INFO(1,"%s(): UART%d Receive Buffer contains 2 or more entries\n",__func__,UartNum); }
        while (*pUartLsr & DR) { c = UartGetc(UartNum); } // just clear FIFO, more advanced handler required
    }
    if (*pUartLsr & OE) {
        *pUartLsr = OE;
        ERROR(1,"%s(): UART%d Overrun Error\n",__func__,UartNum);
        while (*pUartLsr & DR) { c = UartGetc(UartNum); } // just clear FIFO, more advanced handler required
    }
}


/***************************************
 *
 * Function Name : UartInterruptsHandlerData
 * Description   : Generic UART Data Interrupts Handler
 *
 * Parameters    : none
 * Returns       : none
 * Globals       : none
 */
//EX_INTERRUPT_HANDLER(UartInterruptsHandlerData)
EX_REENTRANT_HANDLER(UartInterruptsHandlerData)
{
    unsigned short UartMmrOffset = 0;
    unsigned  char UartNum = 0;
    unsigned  char DmaChan = 0;
    unsigned  long SicIsr0 = 0;

    SicIsr0 = *pSIC_ISR0;

    /* This is aligned with the (default) PMAP settings done in function 'UartInterruptsInit' */
         if (SicIsr0 & IRQ_DMA8 ) { UartMmrOffset = UART0_MMR_OFFSET; UartNum = 0; DmaChan =  8; }
    else if (SicIsr0 & IRQ_DMA10) { UartMmrOffset = UART1_MMR_OFFSET; UartNum = 1; DmaChan = 10; }
    else { asm("EMUEXCPT; jump 0;"); }

    volatile unsigned short *pUartLsr      = (volatile unsigned short*) (UART0_LSR + UartMmrOffset);
    volatile unsigned short *pDmaConfig    = (volatile unsigned short*) (DMA0_CONFIG     + DmaChan * 0x40);
    volatile unsigned short *pDmaIrqStatus = (volatile unsigned short*) (DMA0_IRQ_STATUS + DmaChan * 0x40);

//    if (*pUartLsr & DR) { UartGets(UartNum, UartRcvBuf); } // start to receive string from UART terminal. Stop when a carriage return is received (or buffer is full)
//    if (*pUartLsr & DR) { UartGetsEcho(UartNum, UartRcvBuf); } // start to receive string from UART terminal and bounce it back. Stop when a carriage return is received (or buffer is full)
//    if (*pUartLsr & DR) { UartEcho(UartNum); } // simple ping pong
    if (*pUartLsr & DR) { UartEchoPrompt(UartNum); } // start to receive string from UART terminal and bounce it back. Stop when a carriage return is received (or buffer is full)

    ssync();
}


//***************************************
//*
//* Function Name : short UartInterruptsInit(unsigned char UartNum)
//* Description   : Setup Interrupts and register handlers
//*
//* Parameters    : UART Number
//* Returns       : NULL. If UartInterruptsInit is unsuccessful, a negative value is returned.
//* Globals       : none
//*
short UartInterruptsInit(unsigned char UartNum)
{
    unsigned short UartMmrOffset = 0;

    switch (UartNum) {
        case 0: UartMmrOffset = UART0_MMR_OFFSET;
                *pSIC_IAR0      &= 0xFF0FFFFF;
                *pSIC_IAR0      |= P5_IVG(7);       // UART0 Status Interrupt
                *pSIC_IMASK0    |= IRQ_UART0_ERR;
                *pSIC_IAR2      &= 0xF0FFFFFF;
                *pSIC_IAR2      |= P22_IVG(IVG_UART_DATA);     // UART0 Rx Data Interrupt
                *pSIC_IMASK0    |= IRQ_DMA8;
                break;
        case 1: UartMmrOffset = UART1_MMR_OFFSET;
                *pSIC_IAR0      &= 0xF0FFFFFF;
                *pSIC_IAR0      |= P6_IVG(7);       // UART1 Status Interrupt
                *pSIC_IMASK0    |= IRQ_UART1_ERR;
                *pSIC_IAR3      &= 0xFFFFFFF0;
                *pSIC_IAR3      |= P24_IVG(IVG_UART_DATA);     // UART1 Rx Data Interrupt
                *pSIC_IMASK0    |= IRQ_DMA10;
                break;
        default: return -1;
    }

    *pSIC_IAR0      &= 0xFFFFFF0F;
    *pSIC_IAR0      |= P1_IVG(8);   // DMAC0 Status Interrupt
    *pSIC_IMASK0    |= IRQ_DMA_ERR0;

    register_handler_ex(ik_ivg7,UartInterruptsHandlerStatus,EX_INT_ENABLE);
    register_handler_ex(ik_ivg8,UartDmaInterruptsHandlerStatus,EX_INT_ENABLE);
    register_handler_ex(ik_ivg14,UartInterruptsHandlerData,EX_INT_ENABLE);

    volatile unsigned short *pUartIerSet = (volatile unsigned short*) (UART0_IER_SET + UartMmrOffset);
    volatile unsigned short *pUartMcr    = (volatile unsigned short*) (UART0_MCR     + UartMmrOffset);
    volatile unsigned short *pUartGctl   = (volatile unsigned short*) (UART0_GCTL    + UartMmrOffset);

    *pUartGctl &= ~EGLSI; // Do NOT activate redirection of TX and RX interrupts to status interrupt output
//    *pUartIerSet = (ERFCI|EDSSI|ELSI|ERBFI);
    *pUartIerSet = (ERFCI|ELSI|ERBFI);

#if (FIFO_IRQ_THRESHOLD == 1)
    *pUartMcr |= RFIT;
#else
    *pUartMcr &= ~RFIT;
#endif

    return 0;
}


//***************************************
//*
//* Function Name : long UartAutobaud(unsigned char UartNum)
//* Description   : Assuming 8 data bits, this functions expects a '@'
//*                 (ASCII 0x40) character on the UART RX pin.
//*
//*                 Timer TmrNum performs the autobaud detection.
//*                 Also special support for half-duplex systems is provided.
//*
//* Parameters    : UART Number
//* Returns       : The Timer Period Count. If UartAutobaud is unsuccessful, a negative value is returned.
//* Globals       : none
//*
long UartAutobaud(unsigned char UartNum)
{
    unsigned short UartMmrOffset     = 0;
    unsigned short TimerStatusOffset = 0;
    unsigned  long TimerPeriod       = 0;
    unsigned  char TmrNum            = 0;

    switch (UartNum) {
        case 0: UartMmrOffset = UART0_MMR_OFFSET; TmrNum = UART0_TIMER; break;
        case 1: UartMmrOffset = UART1_MMR_OFFSET; TmrNum = UART1_TIMER; break;
        default: printf("%s(): UART%d is not available.\n",__func__,UartNum); return -1;
    }

    volatile unsigned short *pUartGctl = (volatile unsigned short*) (UART0_GCTL + UartMmrOffset);
    volatile unsigned short *pUartMcr  = (volatile unsigned short*) (UART0_MCR  + UartMmrOffset);

    volatile unsigned short *pTimerConfig = (volatile unsigned short*) (TIMER0_CONFIG + TmrNum * 0x10);
    volatile unsigned  long *pTimerPeriod = (volatile unsigned  long*) (TIMER0_PERIOD + TmrNum * 0x10);

    if (TmrNum > 3) { TimerStatusOffset = TmrNum + 12; }
    else            { TimerStatusOffset = TmrNum; }


    // Setup Timer Controller to do the autobaud detection. Timer captures
    // duration between two falling edges. It expects a '@' (ASCII 0x40)
    // character. 8-bit, no parity assumed.
    // Disable Timer first, in case there was an unexpected history.
    *pTIMER_DISABLE = (TIMDIS0 << TmrNum);
    *pTIMER_STATUS  = ((TRUN0|TOVL_ERR0|TIMIL0) << TimerStatusOffset);

    // Capture from UART RxD pin. Select TimerPeriod capture from falling edge to
    // falling edge. Enable IRQ_ENA, but don't enable the interrupt at system
    // level (SIC).
    *pTimerConfig = (TIN_SEL|IRQ_ENA|PERIOD_CNT|WDTH_CAP);

    // Enable UART Clock
    *pUartGctl = UCEN;

    // Start the timer and wait until the according interrupt latch bit TIMILx
    // in the TIMER_STATUS register is set. Then, two falling edges on the RxD
    // pin have been detected.
    *pTIMER_ENABLE = (TIMEN0 << TmrNum);

    // Activate Loopback mode in order the receive channel is disconnected
    // from RX pin during autobaud detection.
#if (FLOW_CONTROL == 1)
    *pUartMcr = (FCPOL|LOOP_ENA);
#else
    *pUartMcr = LOOP_ENA;
#endif

    while (!(*pTIMER_STATUS & (TIMIL0 << TimerStatusOffset))) { /* wait */ }

    // Disable Timer again
    *pTIMER_DISABLE = (TIMDIS0 << TmrNum);
    *pTIMER_STATUS  = ((TRUN0|TOVL_ERR0|TIMIL0) << TimerStatusOffset);

    // Save TimerPeriod value
    TimerPeriod = *pTimerPeriod;

    // In order to support also half-duplex connections, we need to delay any
    // transmission, in order the sent character does not overlap the autobaud
    // pattern.
    // Use Timer to perform this delay. Note that the Period Register still
    // contains the proper value and the Width Register is not used.
    *pTimerConfig = (OUT_DIS|IRQ_ENA|PERIOD_CNT|PWM_OUT);
    *pTIMER_ENABLE = (TIMEN0 << TmrNum);

    while (!(*pTIMER_STATUS & (TIMIL0 << TimerStatusOffset))) { /* wait */ }

    // Disable Timer again
    *pTIMER_DISABLE = (TIMDIS0 << TmrNum);
    *pTIMER_STATUS  = ((TRUN0|TOVL_ERR0|TIMIL0) << TimerStatusOffset);

    // Deactivate Loopback mode again
    *pUartMcr &= ~(FCPOL|LOOP_ENA);

    // Return TimerPeriod
    return TimerPeriod;
}


//***************************************
//*
//* Function Name : long UartInitAutobaud(unsigned char UartNum)
//* Description   : Configures UART using Autobaud Detection.
//*
//* Parameters    : UART Number
//* Returns       : The UART Bitrate Value. If UartInitAutobaud is unsuccessful, a negative value is returned.
//* Globals       : none
//*
long UartInitAutobaud(unsigned char UartNum)
{
    unsigned short UartMmrOffset = 0;
    unsigned  long UartBitrate   = 0;
    unsigned short UartDivisor   = 0;
              long TimerPeriod   = 0;

    switch (UartNum) {
        case 0: UartMmrOffset = UART0_MMR_OFFSET; break;
        case 1: UartMmrOffset = UART1_MMR_OFFSET; break;
        default: printf("%s(): UART%d is not available.\n",__func__,UartNum); return -1;
    }

    printf("UART%d autobaud detection with character '@'.\n",UartNum);

    volatile unsigned short *pUartGctl = (volatile unsigned short*) (UART0_GCTL + UartMmrOffset);
    volatile unsigned short *pUartLcr  = (volatile unsigned short*) (UART0_LCR  + UartMmrOffset);
    volatile unsigned short *pUartMcr  = (volatile unsigned short*) (UART0_MCR  + UartMmrOffset);
    volatile unsigned short *pUartDll  = (volatile unsigned short*) (UART0_DLL  + UartMmrOffset);
    volatile unsigned short *pUartDlh  = (volatile unsigned short*) (UART0_DLH  + UartMmrOffset);

    if (*pUartGctl & UCEN) { return 0; } // UART already enabled

    UartGpioInit(UartNum);

    // Autobaud
    TimerPeriod = UartAutobaud(UartNum);
    if (TimerPeriod == -1) { return -1;}

    // Enable UART clock
    *pUartGctl |= UCEN;
//    if (TimerPeriod<=524288) { *pUartGctl |= EDBO; } // 2^19 -> 2^16 for the unsigned short value plus the shift by 3

    if (*pUartGctl & EDBO) {
        TimerPeriod += 4; // round up before divide by 8
        UartDivisor = ( TimerPeriod >> 3 );
        // UartDivisor is an unsigned short value whereby TimerPeriod is long
        // For very small bitrates, the period might be long when EDBO=1 and only a division by 8 is done
        // E.g. SCLK = 131.250.000 Hz + Bitrate = 1.200 will result in a calculated bitrate of about 3.000
    }
    else {
        TimerPeriod += 64; // round up before divide by 128
        UartDivisor = ( TimerPeriod >> 7 );
    }

    // Write Divisor to the two 8-bit DL registers (DLH:DLL).
    *pUartDll = ( UartDivisor & 0x00FF);
    *pUartDlh = ((UartDivisor & 0xFF00) >> 8);

    // Apply UART configuration
    *pUartLcr = UART_LCR_VAL;

#if (LOOP == 1) // In loopback mode, MRTS (de)activates the UART's transmitter and sets/clears the CTS bit
    *pUartMcr = (LOOP_ENA|MRTS);
#else // (LOOP == 0)
    #if (FLOW_CONTROL == 1)
        #if (FIFO_RTS_THRESHOLD == 1)
            *pUartMcr |= RFRT;
        #else
            *pUartMcr &= ~RFRT;
        #endif
        #if (FLOW_POLARITY == 1)
            *pUartMcr |= FCPOL;
        #else
            *pUartMcr &= ~FCPOL;
        #endif
        *pUartMcr |= (ARTS|ACTS);
        *pUartMcr &= ~MRTS;
    #else // (FLOW_CONTROL == 0)
        *pUartMcr &= ~(ARTS|ACTS|RFRT|FCPOL);
        *pUartMcr |= MRTS;
    #endif // (FLOW_CONTROL == 1)
#endif // (LOOP == 1)

    // return UartBitrate
    UartBitrate = ( get_sclk_hz() / UartDivisor );
    if (!(*pUartGctl & EDBO)) {
        UartBitrate += 8; // round up before divide by 16
        UartBitrate >>= 4;
    }

#if (LOOP == 0)
    UartInterruptsInit(UartNum);
#endif

    return UartBitrate;
}


//***************************************
//*
//* Function Name : short UartInit(unsigned char UartNum, unsigned long UartBitrate)
//* Description   : Configures UART.
//*
//* Parameters    : UART Number, UART Bitrate Value
//* Returns       : NULL. If the UartInit function is unsuccessful, a negative value is returned.
//* Globals       : none
//*
short UartInit(unsigned char UartNum, unsigned long UartBitrate)
{
    unsigned short UartMmrOffset = 0;
    unsigned  long UartDivisor   = 0;

    switch (UartNum) {
        case 0: UartMmrOffset = UART0_MMR_OFFSET; break;
        case 1: UartMmrOffset = UART1_MMR_OFFSET; break;
        default: printf("%s(): UART%d is not available.\n",__func__,UartNum); return -1;
    }

    volatile unsigned short *pUartGctl = (volatile unsigned short*) (UART0_GCTL + UartMmrOffset);
    volatile unsigned short *pUartLcr  = (volatile unsigned short*) (UART0_LCR  + UartMmrOffset);
    volatile unsigned short *pUartMcr  = (volatile unsigned short*) (UART0_MCR  + UartMmrOffset);

    if (*pUartGctl & UCEN) { return 0; } // UART already enabled

    UartGpioInit(UartNum);

    UartSetBitrate(UartNum, UartBitrate);

    // Enable UART clock
    *pUartGctl |= UCEN;

    // Apply UART configuration
    *pUartLcr = UART_LCR_VAL;

#if (LOOP == 1) // In loopback mode, MRTS (de)activates the UART's transmitter and sets/clears the CTS bit
    *pUartMcr = (LOOP_ENA|MRTS);
#else // (LOOP == 0)
    #if (FLOW_CONTROL == 1)
        #if (FIFO_RTS_THRESHOLD == 1)
            *pUartMcr |= RFRT;
        #else
            *pUartMcr &= ~RFRT;
        #endif
        #if (FLOW_POLARITY == 1)
            *pUartMcr |= FCPOL;
        #else
            *pUartMcr &= ~FCPOL;
        #endif
        *pUartMcr |= (ARTS|ACTS);
        *pUartMcr &= ~MRTS;
    #else // (FLOW_CONTROL == 0)
        *pUartMcr &= ~(ARTS|ACTS|RFRT|FCPOL);
        *pUartMcr |= MRTS;
    #endif // (FLOW_CONTROL == 1)
#endif // (LOOP == 1)

#if (LOOP == 0)
    UartInterruptsInit(UartNum);
#endif

    return 0;
}


//***************************************
//*
//* Function Name : short UartInitTerminal(unsigned char UartNum, unsigned long UartBitrate)
//* Description   : Configures UART for PC Terminal output: 8 bits, no parity, 1 stop bit.
//*
//* Parameters    : UART Number, UART Bitrate Value
//* Returns       : NULL. If the UartInitTerminal function is unsuccessful, a negative value is returned.
//* Globals       : none
//*
short UartInitTerminal(unsigned char UartNum, unsigned long UartBitrate)
{
    unsigned short UartMmrOffset = 0;
    unsigned  long UartDivisor   = 0;

    switch (UartNum) {
        case 0: UartMmrOffset = UART0_MMR_OFFSET; break;
        case 1: UartMmrOffset = UART1_MMR_OFFSET; break;
        default: printf("%s(): UART%d is not available.\n",__func__,UartNum); return -1;
    }

    volatile unsigned short *pUartGctl = (volatile unsigned short*) (UART0_GCTL + UartMmrOffset);
    volatile unsigned short *pUartLcr  = (volatile unsigned short*) (UART0_LCR  + UartMmrOffset);
    volatile unsigned short *pUartMcr  = (volatile unsigned short*) (UART0_MCR  + UartMmrOffset);

    if (*pUartGctl & UCEN) { return 0; } // UART already enabled

    UartGpioInit(UartNum);

    UartSetBitrate(UartNum, UartBitrate);

    // Enable UART clock
    *pUartGctl |= UCEN;

    // Ensure that Loopback mode is disabled by clearing LOOP_ENA bit
    *pUartMcr &= ~LOOP_ENA;

    // Set UART frame to 8 bits, no parity, 1 stop bit.
    *pUartLcr = WLS(8);

    UartInterruptsInit(UartNum);

    return 0;
}


//***************************************
//*
//* Function Name : short UartDmaInitTx(unsigned char UartNum, unsigned char DmaChan)
//* Description   : Configures UART.
//*
//*                 Pre-Configures DMA channel
//*
//*                 The Peripheral Map of the default DMA channel must be unassigned first.
//*
//* Parameters    : UART Number, DMA channel
//* Returns       : NULL. If the UartDmaInitTx function is unsuccessful, a negative value is returned.
//* Globals       : none
//*
short UartDmaInitTx(unsigned char UartNum, unsigned char DmaChan)
{
    if (DmaChan > DMA_MAX_COUNT) { printf("%s(): DMA%d is not available.\n",__func__,DmaChan); return -1; }

    volatile unsigned  long *pDmaNextDescPtr   = (volatile unsigned  long*) (DMA0_NEXT_DESC_PTR  + DmaChan * 0x40);
    volatile unsigned  long *pDmaStartAddr     = (volatile unsigned  long*) (DMA0_START_ADDR     + DmaChan * 0x40);
    volatile unsigned short *pDmaConfig        = (volatile unsigned short*) (DMA0_CONFIG         + DmaChan * 0x40);
    volatile unsigned short *pDmaXCount        = (volatile unsigned short*) (DMA0_X_COUNT        + DmaChan * 0x40);
    volatile unsigned short *pDmaXModify       = (volatile unsigned short*) (DMA0_X_MODIFY       + DmaChan * 0x40);
    volatile unsigned short *pDmaYCount        = (volatile unsigned short*) (DMA0_Y_COUNT        + DmaChan * 0x40);
    volatile unsigned short *pDmaYModify       = (volatile unsigned short*) (DMA0_Y_MODIFY       + DmaChan * 0x40);
    volatile unsigned  long *pDmaCurrDescPtr   = (volatile unsigned  long*) (DMA0_CURR_DESC_PTR  + DmaChan * 0x40);
    volatile unsigned  long *pDmaCurrAddr      = (volatile unsigned  long*) (DMA0_CURR_ADDR      + DmaChan * 0x40);
    volatile unsigned short *pDmaIrqStatus     = (volatile unsigned short*) (DMA0_IRQ_STATUS     + DmaChan * 0x40);
    volatile unsigned short *pDmaPeripheralMap = (volatile unsigned short*) (DMA0_PERIPHERAL_MAP + DmaChan * 0x40);
    volatile unsigned short *pDmaCurrXCount    = (volatile unsigned short*) (DMA0_CURR_X_COUNT   + DmaChan * 0x40);
    volatile unsigned short *pDmaCurrYCount    = (volatile unsigned short*) (DMA0_CURR_Y_COUNT   + DmaChan * 0x40);

    switch (UartNum) {
        case 0: *pDmaConfig = 0; *pDmaPeripheralMap = PMAP_UART0TX; break;
        case 1: *pDmaConfig = 0; *pDmaPeripheralMap = PMAP_UART1TX; break;
        default: return -1;
    }

    *pDmaNextDescPtr   = 0;
    *pDmaStartAddr     = 0xFF804000;
    *pDmaXCount        = 0;
    *pDmaXModify       = 1;
    *pDmaYCount        = 0;
    *pDmaYModify       = 0;
    *pDmaCurrDescPtr   = 0;
    *pDmaCurrAddr      = 0;
    *pDmaCurrXCount    = 0;
    *pDmaCurrYCount    = 0;

    ssync();

    return 0;
}


//***************************************
//*
//* Function Name : short UartDmaInitRx(unsigned char UartNum, unsigned char DmaChan)
//* Description   : Configures UART.
//*
//*                 Pre-Configures DMA channel
//*
//*                 The Peripheral Map of the default DMA channel must be unassigned first.
//*
//* Parameters    : UART Number, DMA channel
//* Returns       : NULL. If the UartDmaInitRx function is unsuccessful, a negative value is returned.
//* Globals       : none
//*
short UartDmaInitRx(unsigned char UartNum, unsigned char DmaChan)
{
    if (DmaChan > DMA_MAX_COUNT) { printf("%s(): DMA%d is not available.\n",__func__,DmaChan); return -1; }

    volatile unsigned  long *pDmaNextDescPtr   = (volatile unsigned  long*) (DMA0_NEXT_DESC_PTR  + DmaChan * 0x40);
    volatile unsigned  long *pDmaStartAddr     = (volatile unsigned  long*) (DMA0_START_ADDR     + DmaChan * 0x40);
    volatile unsigned short *pDmaConfig        = (volatile unsigned short*) (DMA0_CONFIG         + DmaChan * 0x40);
    volatile unsigned short *pDmaXCount        = (volatile unsigned short*) (DMA0_X_COUNT        + DmaChan * 0x40);
    volatile unsigned short *pDmaXModify       = (volatile unsigned short*) (DMA0_X_MODIFY       + DmaChan * 0x40);
    volatile unsigned short *pDmaYCount        = (volatile unsigned short*) (DMA0_Y_COUNT        + DmaChan * 0x40);
    volatile unsigned short *pDmaYModify       = (volatile unsigned short*) (DMA0_Y_MODIFY       + DmaChan * 0x40);
    volatile unsigned  long *pDmaCurrDescPtr   = (volatile unsigned  long*) (DMA0_CURR_DESC_PTR  + DmaChan * 0x40);
    volatile unsigned  long *pDmaCurrAddr      = (volatile unsigned  long*) (DMA0_CURR_ADDR      + DmaChan * 0x40);
    volatile unsigned short *pDmaIrqStatus     = (volatile unsigned short*) (DMA0_IRQ_STATUS     + DmaChan * 0x40);
    volatile unsigned short *pDmaPeripheralMap = (volatile unsigned short*) (DMA0_PERIPHERAL_MAP + DmaChan * 0x40);
    volatile unsigned short *pDmaCurrXCount    = (volatile unsigned short*) (DMA0_CURR_X_COUNT   + DmaChan * 0x40);
    volatile unsigned short *pDmaCurrYCount    = (volatile unsigned short*) (DMA0_CURR_Y_COUNT   + DmaChan * 0x40);

    switch (UartNum) {
        case 0: *pDmaConfig = 0; *pDmaPeripheralMap = PMAP_UART0RX; break;
        case 1: *pDmaConfig = 0; *pDmaPeripheralMap = PMAP_UART1RX; break;
        default: return -1;
    }

    *pDmaNextDescPtr   = 0;
    *pDmaStartAddr     = 0xFF804000;
    *pDmaXCount        = 0;
    *pDmaXModify       = 1;
    *pDmaYCount        = 0;
    *pDmaYModify       = 0;
    *pDmaCurrDescPtr   = 0;
    *pDmaCurrAddr      = 0;
    *pDmaCurrXCount    = 0;
    *pDmaCurrYCount    = 0;

    ssync();

    return 0;
}


//***************************************
//*
//* Function Name : short UartWaitForTransmitCompletion(unsigned char UartNum)
//* Description   : Waits for THRE (TEMT) bit set in UART LSR register
//*
//* Parameters    : UART number
//* Returns       : If the UartWaitForTransmitCompletion function is unsuccessful, a negative value is returned
//* Globals       : none
//*
short UartWaitForTransmitCompletion(unsigned char UartNum)
{
    unsigned short UartMmrOffset  = 0;

    switch (UartNum) {
        case 0: UartMmrOffset = UART0_MMR_OFFSET; break;
        case 1: UartMmrOffset = UART1_MMR_OFFSET; break;
        default: printf("%s(): UART%d is not available.\n",__func__,UartNum); return -1;
    }

    volatile unsigned short *pUartLsr  = (volatile unsigned short*) (UART0_LSR + UartMmrOffset);

    ssync();

    while (!(*pUartLsr & THRE)) { /* wait */ }
//    while (!(*pUartLsr & TEMT)) { /* wait */ }

    *pUartLsr = TFI;

    return 0;
}


//***************************************
//*
//* Function Name : short UartDmaWaitForTransmitCompletion(unsigned char UartNum, unsigned char DmaChan)
//* Description   : This functions makes sure that a current DMA transmission (memory read)
//*                 is completed (DMA_DONE set) and the UART transfer is finished (TEMT set).
//*                 DMA_DONE is cleared.
//*
//* Parameters    : UART number, DMA channel
//* Returns       : If the UartDmaWaitForTransmitCompletion function is unsuccessful, a negative value is returned
//* Globals       : none
//*
short UartDmaWaitForTransmitCompletion(unsigned char UartNum, unsigned char DmaChan)
{
    unsigned short UartMmrOffset  = 0;

    switch (UartNum) {
        case 0: UartMmrOffset = UART0_MMR_OFFSET; break;
        case 1: UartMmrOffset = UART1_MMR_OFFSET; break;
        default: printf("%s(): UART%d is not available.\n",__func__,UartNum); return -1;
    }

    if (DmaChan > DMA_MAX_COUNT) { printf("%s(): DMA%d is not available.\n",__func__,DmaChan); return -1; }

    volatile unsigned short *pDmaIrqStatus = (volatile unsigned short*) (DMA0_IRQ_STATUS + DmaChan * 0x40);
    volatile unsigned short *pDmaConfig    = (volatile unsigned short*) (DMA0_CONFIG     + DmaChan * 0x40);
    volatile unsigned short *pUartLsr      = (volatile unsigned short*) (UART0_LSR       + UartMmrOffset);

    ssync();

    if (*pDmaConfig & DMAEN) {
//        while(  *pDmaIrqStatus & DMA_RUN)   { /* wait */ }
        while(!(*pDmaIrqStatus & DMA_DONE)) { /* if (!(*pDmaIrqStatus & DMA_RUN)) break; */ }
        *pDmaIrqStatus = DMA_DONE;
    }

    while(!(*pUartLsr & TEMT)) { /* wait */ }

    *pUartLsr = TFI;

    return 0;
}


//***************************************
//*
//* Function Name : short UartDmaWaitForDmaDone(unsigned char DmaChan)
//* Description   : This functions makes sure that a current DMA transmission (memory read)
//*                 is completed (DMA_DONE set).
//*                 DMA_DONE is cleared.
//*
//* Parameters    : DMA channel
//* Returns       : NULL. If the UartDmaWaitForDmaDone function is unsuccessful, a negative value is returned.
//* Globals       : none
//*
short UartDmaWaitForDmaDone(unsigned char DmaChan)
{
    if (DmaChan > DMA_MAX_COUNT) { printf("%s(): DMA%d is not available.\n",__func__,DmaChan); return -1; }

    volatile unsigned short *pDmaIrqStatus = (volatile unsigned short*) (DMA0_IRQ_STATUS + DmaChan * 0x40);
    volatile unsigned short *pDmaConfig    = (volatile unsigned short*) (DMA0_CONFIG     + DmaChan * 0x40);

    ssync();

    if (*pDmaConfig & DMAEN) {
        while(!(*pDmaIrqStatus & DMA_DONE)) { /* if (!(*pDmaIrqStatus & DMA_RUN)) break; */ }
        *pDmaIrqStatus = DMA_DONE;
        }

    return 0;
}


//***************************************
//*
//* Function Name : short UartTxOn(unsigned char UartNum)
//* Description   : This function enables the UART Transmitter
//*                 (ignored if ACTS = 1)
//*
//* Parameters    : UART number
//* Returns       : NULL. If the UartTxOn function is unsuccessful, a negative value is returned.
//* Globals       : none
//*
short UartTxOn(unsigned char UartNum)
{
    unsigned short UartMmrOffset = 0;

    switch (UartNum) {
        case 0: UartMmrOffset = UART0_MMR_OFFSET; break;
        case 1: UartMmrOffset = UART1_MMR_OFFSET; break;
        default: printf("%s(): UART%d is not available.\n",__func__,UartNum); return -1;
    }

    volatile unsigned short *pUartMcr = (volatile unsigned short*) (UART0_MCR + UartMmrOffset);

    *pUartMcr &= ~XOFF;

    return 0;
}


//***************************************
//*
//* Function Name : short UartTxOff(unsigned char UartNum)
//* Description   : This function enables the UART Transmitter
//*                 (ignored if ACTS = 1)
//*
//* Parameters    : UART number
//* Returns       : NULL. If the UartTxOff function is unsuccessful, a negative value is returned.
//* Globals       : none
//*
short UartTxOff(unsigned char UartNum)
{
    unsigned short UartMmrOffset = 0;

    switch (UartNum) {
        case 0: UartMmrOffset = UART0_MMR_OFFSET; break;
        case 1: UartMmrOffset = UART1_MMR_OFFSET; break;
        default: printf("%s(): UART%d is not available.\n",__func__,UartNum); return -1;
    }

    volatile unsigned short *pUartMcr = (volatile unsigned short*) (UART0_MCR + UartMmrOffset);

    if (*pUartMcr&ACTS) { printf("%s(): XOFF bit is ignored, Hardware Flow Control is enabled on UART%d.\n",__func__,UartNum); }
    else { *pUartMcr |= XOFF; }

    return 0;
}


//***************************************
//*
//* Function Name : short UartDmaBreak(unsigned char UartNum)
//* Description   : This function breaks an ongoing UART-DMA transmission.
//*
//* Parameters    : UART number
//* Returns       : NULL. If the UartDmaBreak function is unsuccessful, a negative value is returned.
//* Globals       : none
//*
short UartDmaBreak(unsigned char UartNum)
{
    unsigned short UartMmrOffset  = 0;

    switch (UartNum) {
        case 0: UartMmrOffset = UART0_MMR_OFFSET; break;
        case 1: UartMmrOffset = UART1_MMR_OFFSET; break;
        default: printf("%s(): UART%d is not available.\n",__func__,UartNum); return -1;
    }

    volatile unsigned short *pUartIerClr = (volatile unsigned short*) (UART0_IER_CLEAR + UartMmrOffset);

    *pUartIerClr = ETBEI;

    return 0;
}


//***************************************
//*
//* Function Name : short UartDmaResume(unsigned char UartNum)
//* Description   : This function resumes/continues an interrupted UART-DMA transmission.
//*
//* Parameters    : UART number
//* Returns       : NULL. If the UartDmaResume function is unsuccessful, a negative value is returned.
//* Globals       : none
//*
short UartDmaResume(unsigned char UartNum)
{
    unsigned short UartMmrOffset  = 0;

    switch (UartNum) {
        case 0: UartMmrOffset = UART0_MMR_OFFSET; break;
        case 1: UartMmrOffset = UART1_MMR_OFFSET; break;
        default: printf("%s(): UART%d is not available.\n",__func__,UartNum); return -1;
    }

    volatile unsigned short *pUartIerSet = (volatile unsigned short*) (UART0_IER_SET + UartMmrOffset);

    *pUartIerSet = ETBEI;

    return 0;
}


//***************************************
//*
//* Function Name : short UartClockDisable(unsigned char UartNum)
//* Description   : This function disables the UART clock,
//*                 the TEMT bit in the LSR register is polled to ensure UART is disabled safely.
//*
//* Parameters    : UART number
//* Returns       : NULL. If the UartDisable function is unsuccessful, a negative value is returned.
//* Globals       : none
//*
short UartClockDisable(unsigned char UartNum)
{
    unsigned short UartMmrOffset  = 0;

    switch (UartNum) {
        case 0: UartMmrOffset = UART0_MMR_OFFSET; break;
        case 1: UartMmrOffset = UART1_MMR_OFFSET; break;
        default: printf("%s(): UART%d is not available.\n",__func__,UartNum); return -1;
    }

    volatile unsigned short *pUartGctl = (volatile unsigned short*) (UART0_GCTL + UartMmrOffset);
    volatile unsigned short *pUartLsr  = (volatile unsigned short*) (UART0_LSR  + UartMmrOffset);

    ssync();

    while (!(*pUartLsr & TEMT)) { /* wait */ }

    *pUartGctl &= ~UCEN;

    return 0;
}


//***************************************
//*
//* Function Name : short UartDmaDisable(unsigned char UartNum, unsigned char DmaChan)
//* Description   : This function disables the DMA,
//*                 the DMA RUN Status is polled to ensure DMA is disabled safely.
//*
//* Parameters    : UART number
//* Returns       : NULL. If the UartDmaDisable function is unsuccessful, a negative value is returned.
//* Globals       : none
//*
short UartDmaDisable(unsigned char UartNum, unsigned char DmaChan)
{
    unsigned short UartMmrOffset  = 0;

    switch (UartNum) {
        case 0: UartMmrOffset = UART0_MMR_OFFSET; break;
        case 1: UartMmrOffset = UART1_MMR_OFFSET; break;
        default: printf("%s(): UART%d is not available.\n",__func__,UartNum); return -1;
    }

    if (DmaChan > DMA_MAX_COUNT) { printf("%s(): DMA%d is not available.\n",__func__,DmaChan); return -1; }

    volatile unsigned short *pDmaIrqStatus = (volatile unsigned short*) (DMA0_IRQ_STATUS + DmaChan * 0x40);
    volatile unsigned short *pDmaConfig    = (volatile unsigned short*) (DMA0_CONFIG     + DmaChan * 0x40);

    ssync();

//    UartDmaWaitForTransmitCompletion(UartNum,DmaChan);
    while(*pDmaIrqStatus & DMA_RUN) { /* wait */ }

    *pDmaConfig &= ~DMAEN;

    return 0;
}


//***************************************
//*
//* Function Name : short UartPutc(unsigned char UartNum, char c)
//* Description   : This function transmits a character,
//*                 the THRE bit in the LSR register is polled to ensure that THR is empty.
//*
//* Parameters    : UART number, the character to transmit
//* Returns       : NULL. If the UartPutc function is unsuccessful, a negative value is returned.
//* Globals       : none
//*
short UartPutc(unsigned char UartNum, char c)
{
    unsigned short UartMmrOffset  = 0;

    switch (UartNum) {
        case 0: UartMmrOffset = UART0_MMR_OFFSET; break;
        case 1: UartMmrOffset = UART1_MMR_OFFSET; break;
        default: printf("%s(): UART%d is not available.\n",__func__,UartNum); return -1;
    }

    volatile unsigned short *pUartLsr = (volatile unsigned short*) (UART0_LSR + UartMmrOffset);
    volatile unsigned short *pUartMsr = (volatile unsigned short*) (UART0_MSR + UartMmrOffset);
    volatile unsigned short *pUartThr = (volatile unsigned short*) (UART0_THR + UartMmrOffset);

#if (FLOW_CONTROL == 1)
    while (!(*pUartMsr &  CTS)) { /* wait */ }
#endif

    while (!(*pUartLsr & THRE)) { /* wait */ }
    *pUartThr = c;

#if (LOOP == 1)
    unsigned short dummy;
    dummy = UartGetc(UartNum);
#endif

    return 0;
}


//***************************************
//*
//* Function Name : short UartPuts(unsigned char UartNum, char *c)
//* Description   : This function transmits a byte string.
//*                 The string must be NULL-terminated (C-style).
//*                 A newline / carriage return character will terminate the transfer as well.
//*
//* Parameters    : UART number, pointer to the string to transmit
//* Returns       : NULL. If the UartPuts function is unsuccessful, a negative value is returned.
//* Globals       : none
//*
short UartPuts(unsigned char UartNum, char *c)
{
    while (*c) {
        UartPutc(UartNum, *c);
#if(0) // This is taken care by uprintf
        if (*c == '\n') { // 0x0A = newline?
            UartPutc(UartNum, '\r'); // 0x0D = insert carriage return
            return 0;
            }
        else if (*c == '\r') { // 0x0D = carriage return?
            UartPutc(UartNum, '\n'); // 0x0A = insert newline
            return 0;
            }
        else { c++; }
#else
        c++;
#endif
        }

    return 0;
}

//***************************************
//*
//* Function Name : short UartPutsn(unsigned char UartNum, char *c, unsigned long NumChar)
//* Description   : This function transmits a byte string of length NumChar.
//*
//* Parameters    : UART number, pointer to the string to transmit, number of characters
//* Returns       : NULL. If the UartPutsn function is unsuccessful, a negative value is returned.
//* Globals       : none
//*
short UartPutsn(unsigned char UartNum, char *c, unsigned long NumChar)
{
    unsigned long i;

    if (NumChar < 1) { return -1; }

    for ( i = 0; i < NumChar ; i++ ) { UartPutc(UartNum, c[i]); }

    return 0;
}


//***************************************
//*
//* Function Name : short UartDmaPuts(unsigned char UartNum, unsigned char DmaChan, char *c)
//* Description   : This function transmits a byte string by DMA.
//*                 The string must be NULL-terminated (C-style).
//*
//* Parameters    : UART number, DMA channel, pointer to the string to transmit
//* Returns       : NULL. If the UartDmaPuts function is unsuccessful, a negative value is returned.
//* Globals       : none
//*
short UartDmaPuts(unsigned char UartNum, unsigned char DmaChan, char *c)
{
    unsigned short UartMmrOffset  = 0;

    switch (UartNum) {
        case 0: UartMmrOffset = UART0_MMR_OFFSET; break;
        case 1: UartMmrOffset = UART1_MMR_OFFSET; break;
        default: printf("%s(): UART%d is not available.\n",__func__,UartNum); return -1;
    }

    if (DmaChan > DMA_MAX_COUNT) { printf("%s(): DMA%d is not available.\n",__func__,DmaChan); return -1; }

    volatile unsigned short *pDmaIrqStatus = (volatile unsigned short*) (DMA0_IRQ_STATUS + DmaChan * 0x40);
    volatile unsigned  long *pDmaStartAddr = (volatile unsigned  long*) (DMA0_START_ADDR + DmaChan * 0x40);
    volatile unsigned short *pDmaConfig    = (volatile unsigned short*) (DMA0_CONFIG     + DmaChan * 0x40);
    volatile unsigned short *pDmaXCount    = (volatile unsigned short*) (DMA0_X_COUNT    + DmaChan * 0x40);
    volatile unsigned short *pUartIerSet   = (volatile unsigned short*) (UART0_IER_SET   + UartMmrOffset);
    volatile unsigned short *pUartIerClr   = (volatile unsigned short*) (UART0_IER_CLEAR + UartMmrOffset);

    while ( (*pDmaConfig & DMAEN) && (*pDmaIrqStatus & DMA_RUN) ) { /* wait */ }

    *pUartIerClr   = ETBEI;
    *pDmaStartAddr = (unsigned long) c;
    *pDmaXCount    = (unsigned short) strlen(c);
    *pDmaConfig    = (FLOW_STOP|WDSIZE_8|SYNC|DI_EN|DMAEN);
    *pUartIerSet   = ETBEI;

    return 0;
}


//***************************************
//*
//* Function Name : short UartDmaPutsn(unsigned char UartNum, unsigned char DmaChan, char *c, unsigned short NumChar)
//* Description   : This function transmits a byte string by DMA of length NumChar
//*
//* Parameters    : UART number, DMA channel, pointer to the string to transmit, number of characters
//* Returns       : NULL. If the UartDmaPutsn function is unsuccessful, a negative value is returned.
//* Globals       : none
//*
short UartDmaPutsn(unsigned char UartNum, unsigned char DmaChan, char *c, unsigned short NumChar)
{
    unsigned short UartMmrOffset  = 0;

    if (NumChar < 1) { return -1; }
    if (STRINGSIZE < NumChar) { return -1; }

    switch (UartNum) {
        case 0: UartMmrOffset = UART0_MMR_OFFSET; break;
        case 1: UartMmrOffset = UART1_MMR_OFFSET; break;
        default: printf("%s(): UART%d is not available.\n",__func__,UartNum); return -1;
    }

    if (DmaChan > DMA_MAX_COUNT) { printf("%s(): DMA%d is not available.\n",__func__,DmaChan); return -1; }

    volatile unsigned short *pDmaIrqStatus = (volatile unsigned short*) (DMA0_IRQ_STATUS + DmaChan * 0x40);
    volatile unsigned  long *pDmaStartAddr = (volatile unsigned  long*) (DMA0_START_ADDR + DmaChan * 0x40);
    volatile unsigned short *pDmaConfig    = (volatile unsigned short*) (DMA0_CONFIG     + DmaChan * 0x40);
    volatile unsigned short *pDmaXCount    = (volatile unsigned short*) (DMA0_X_COUNT    + DmaChan * 0x40);
    volatile unsigned short *pUartIerSet   = (volatile unsigned short*) (UART0_IER_SET   + UartMmrOffset);
    volatile unsigned short *pUartIerClr   = (volatile unsigned short*) (UART0_IER_CLEAR + UartMmrOffset);

    while ( (*pDmaConfig & DMAEN) && (*pDmaIrqStatus & DMA_RUN) ) { /* wait */ }

    *pUartIerClr   = ETBEI;
    *pDmaStartAddr = (unsigned long) c;
    *pDmaXCount    = (unsigned short) NumChar;
    *pDmaConfig    = (FLOW_STOP|WDSIZE_8|SYNC|DI_EN|DMAEN);
    *pUartIerSet   = ETBEI;

    return 0;
}


//***************************************
//*
//* Function Name : short UartDmaGetsn(unsigned char UartNum, unsigned char DmaChan, char *c, unsigned short NumChar)
//* Description   : This function receives a byte string by DMA of length NumChar.
//*
//* Parameters    : UART number, DMA channel, pointer to the string to transmit, number of characters
//* Returns       : NULL. If the UartDmaGetsn function is unsuccessful, a negative value is returned.
//* Globals       : none
//*
short UartDmaGetsn(unsigned char UartNum, unsigned char DmaChan, char *c, unsigned short NumChar)
{
    unsigned short UartMmrOffset = 0;

    if (NumChar < 1) { return -1; }
    if (STRINGSIZE < NumChar) { return -1; }

    switch (UartNum) {
        case 0: UartMmrOffset = UART0_MMR_OFFSET; break;
        case 1: UartMmrOffset = UART1_MMR_OFFSET; break;
        default: printf("%s(): UART%d is not available.\n",__func__,UartNum); return -1;
    }

    if (DmaChan > DMA_MAX_COUNT) { printf("%s(): DMA%d is not available.\n",__func__,DmaChan); return -1; }

    volatile unsigned short *pDmaIrqStatus = (volatile unsigned short*) (DMA0_IRQ_STATUS + DmaChan * 0x40);
    volatile unsigned  long *pDmaStartAddr = (volatile unsigned  long*) (DMA0_START_ADDR + DmaChan * 0x40);
    volatile unsigned short *pDmaConfig    = (volatile unsigned short*) (DMA0_CONFIG     + DmaChan * 0x40);
    volatile unsigned short *pDmaXCount    = (volatile unsigned short*) (DMA0_X_COUNT    + DmaChan * 0x40);
    volatile unsigned short *pUartIerSet   = (volatile unsigned short*) (UART0_IER_SET   + UartMmrOffset);
    volatile unsigned short *pUartIerClr   = (volatile unsigned short*) (UART0_IER_CLEAR + UartMmrOffset);

    while ( (*pDmaConfig & DMAEN) && (*pDmaIrqStatus & DMA_RUN) ) { /* wait */ }

    *pUartIerClr   = ERBFI;
    *pDmaStartAddr = (unsigned long) c;
    *pDmaXCount    = (unsigned short) NumChar;
//    *pDmaConfig    = (FLOW_STOP|WDSIZE_8|SYNC|DI_EN|DMAEN|WNR);
    *pDmaConfig    = (FLOW_STOP|WDSIZE_8|SYNC|DMAEN|WNR);
    *pUartIerSet   = ERBFI;

    return 0;
}


//***************************************
//*
//* Function Name : char UartGetc(unsigned char UartNum)
//* Description   : This function receives a character
//*                 by polling the DR bit in the LSR register.
//*
//* Parameters    : UART number
//* Returns       : The character received from the RBR. If the UartGetc function is unsuccessful, a negative value is returned.
//* Globals       : none
//*
char UartGetc(unsigned char UartNum)
{
    unsigned short UartMmrOffset  = 0;

    switch (UartNum) {
        case 0: UartMmrOffset = UART0_MMR_OFFSET; break;
        case 1: UartMmrOffset = UART1_MMR_OFFSET; break;
        default: printf("%s(): UART%d is not available.\n",__func__,UartNum); return -1;
    }

    volatile unsigned short *pUartLsr = (volatile unsigned short*) (UART0_LSR + UartMmrOffset);
    volatile unsigned short *pUartRbr = (volatile unsigned short*) (UART0_RBR + UartMmrOffset);

    char c;

    while (!(*pUartLsr & DR)) { /* wait */}

    // read Data
    c = *pUartRbr;

    return c;
}


//***************************************
//*
//* Function Name : short UartGets(unsigned char UartNum, char *c)
//* Description   : This function receives a string and is terminated,
//*                 when a newline or carriage return character is detected or receive buffer is full
//*
//* Parameters    : UART number, pointer to the string
//* Returns       : NULL. If the UartGets function is unsuccessful, a negative value is returned.
//* Globals       : none
//*
short UartGets(unsigned char UartNum, char *c)
{
    unsigned short i;

    for(i = 0; i < STRINGSIZE; i++) {
        c[i] = UartGetc(UartNum);
//        if (c[i] == -1) { return -1; }
        if ((c[i] == '\n')||(c[i] == '\r')) { break; }
        }

    return 0;
}


//***************************************
//*
//* Function Name : short UartGetsn(unsigned char UartNum, char *c, unsigned long NumChar)
//* Description   : This function receives a byte string of length NumChar
//*
//* Parameters    : UART number, pointer to the string, number of characters
//* Returns       : NULL. If the UartGetsn function is unsuccessful, a negative value is returned.
//* Globals       : none
//*
short UartGetsn(unsigned char UartNum, char *c, unsigned long NumChar)
{
    unsigned short i;

    if (NumChar < 1) { return -1; }
    if (STRINGSIZE < NumChar) { return -1; }

    for(i = 0; i < NumChar; i++) { c[i] = UartGetc(UartNum); }

    return 0;
}


//***************************************
//*
//* Function Name : short UartGetsEcho(unsigned char UartNum, char *c)
//* Description   : This function receives a string and is terminated,
//*                 when a newline or carriage return character is detected
//*                 or receive buffer is full and echoes each received characters individually
//*
//* Parameters    : UART number, pointer to the string
//* Returns       : NULL. If the UartGetsEcho function is unsuccessful, a negative value is returned.
//* Globals       : none
//*
short UartGetsEcho(unsigned char UartNum, char *c)
{
    unsigned short i;

    for(i = 0; i < STRINGSIZE; i++) {
        c[i] = UartGetc(UartNum);
//        if (c[i] == -1) { return -1; }
        MSG(1,"%c",c[i]);
        if ((c[i] == '\n')||(c[i] == '\r')) { break; }
        }

    return 0;
}


//***************************************
//*
//* Function Name : short UartEcho(unsigned char UartNum)
//* Description   : This function echoes one character (ping pong)
//*
//* Parameters    : UART number, pointer to the string
//* Returns       : NULL. If the UartEcho function is unsuccessful, a negative value is returned.
//* Globals       : none
//*
short UartEcho(unsigned char UartNum)
{
    char c = UartGetc(UartNum);

    switch(c) {
//        case -1:    return -1;
        default:    UartPutc(UartNum,c); break;
    }

    return 0;
}


//***************************************
//*
//* Function Name : short UartEchoPrompt(unsigned char UartNum)
//* Description   : This function echoes one character (ping pong)
//*                 and inserts a command line prompt every newline
//*
//* Parameters    : UART number, pointer to the string
//* Returns       : NULL. If the UartEchoPrompt function is unsuccessful, a negative value is returned.
//* Globals       : none
//*
short UartEchoPrompt(unsigned char UartNum)
{
    unsigned short i = 0;
    char c[3];

    while (i < STRINGSIZE) {
        c[0] = UartGetc(UartNum);
        switch(c[0]) {
//            case -1:    return -1;
            case '\e':  c[1] = UartGetc(UartNum);
                        c[2] = UartGetc(UartNum);
                        if (!strncmp(crsfw,c,3)) { UartPutsn(UartNum,c,3); i++; }
                        else if (!strncmp(crsbw,c,3)) { if(0<i) { UartPutsn(UartNum,c,3); i--; } }
                        else if (!strncmp(crsuw,c,3)) { }
                        else if (!strncmp(crsdw,c,3)) { }
                        else { UartPutsn(UartNum,c,3); }
                        break;
            case 0x7F:  if(0<i) { DEBUG(2,"%c",c[0]); i--; } break; // backspace
            case '\n':  DEBUG(2,"%c",c[0]); DEBUG(2,""_PROMPT_""); return 0; // newline
            case '\r':  DEBUG(2,"%c",c[0]); DEBUG(2,""_PROMPT_""); return 0; // carriage return
            default:    UartPutc(UartNum,c[0]); i++; break;
        }
    }

    return 0;
}


//***************************************
//*
//* Function Name : long UartGetBitrate(unsigned char UartNum)
//* Description   : This function calculates and returns the current UART bitrate.
//*
//* Parameters    : UART number
//* Returns       : The current UART Bitrate. If the UartGetBitrate function is unsuccessful, a negative value is returned.
//* Globals       : none
//*
long UartGetBitrate(unsigned char UartNum)
{
    unsigned short UartMmrOffset = 0;
    unsigned  long UartBitrate   = 0;
    unsigned short UartDivisor   = 0;

    switch (UartNum) {
        case 0: UartMmrOffset = UART0_MMR_OFFSET; break;
        case 1: UartMmrOffset = UART1_MMR_OFFSET; break;
        default: printf("%s(): UART%d is not available.\n",__func__,UartNum); return -1;
    }

    volatile unsigned short *pUartGctl = (volatile unsigned short*) (UART0_GCTL + UartMmrOffset);
    volatile unsigned short *pUartDlh  = (volatile unsigned short*) (UART0_DLH  + UartMmrOffset);
    volatile unsigned short *pUartDll  = (volatile unsigned short*) (UART0_DLL  + UartMmrOffset);

    UartDivisor = ( (*pUartDlh << 8) | *pUartDll );
    if (UartDivisor == 0) { return -1; }

    UartBitrate = ( get_sclk_hz() / UartDivisor );
    if (!(*pUartGctl & EDBO)) {
        UartBitrate += 8;
        UartBitrate >>= 4;
    }

    return UartBitrate;
}


//***************************************
//*
//* Function Name : short UartSetBitrate(unsigned char UartNum, unsigned long UartBitrate)
//* Description   : This function sets the UART bitrate.
//*
//* Parameters    : UART number, UART Bitrate
//* Returns       : Uart Divisor. If the UartSetBitrate function is unsuccessful, a negative value is returned.
//* Globals       : none
//*
short UartSetBitrate(unsigned char UartNum, unsigned long UartBitrate)
{
    unsigned short UartMmrOffset = 0;
    unsigned  long UartDivisor   = 0;

    if (UartBitrate == 0) { return -1; }

    switch (UartNum) {
        case 0: UartMmrOffset = UART0_MMR_OFFSET; break;
        case 1: UartMmrOffset = UART1_MMR_OFFSET; break;
        default: printf("%s(): UART%d is not available.\n",__func__,UartNum); return -1;
    }

    volatile unsigned short *pUartGctl = (volatile unsigned short*) (UART0_GCTL + UartMmrOffset);
    volatile unsigned short *pUartDlh  = (volatile unsigned short*) (UART0_DLH  + UartMmrOffset);
    volatile unsigned short *pUartDll  = (volatile unsigned short*) (UART0_DLL  + UartMmrOffset);

    UartDivisor = ( get_sclk_hz() / UartBitrate );

    if (UartDivisor > 65536) { *pUartGctl &= ~EDBO; } // ensure EDBO being cleared when the calculated divisor is larger than 2^16, divide by 16 operation performed afterwards
//    else { *pUartGctl |= EDBO; } // It is recommended to use EDBO=1 mode only when bit rate accuracy is not acceptable in EDBO=0 mode

    if (!(*pUartGctl & EDBO)) {
        UartDivisor += 8; // round up before divide by 16
        UartDivisor >>= 4;
        }

    // Write Divisor to the two 8-bit DL registers (DLH:DLL).
    *pUartDlh = ((UartDivisor & 0xFF00) >> 8);
    *pUartDll = ( UartDivisor & 0x00FF);

    return (short) UartDivisor;
}


/******************************** End of File *********************************/
