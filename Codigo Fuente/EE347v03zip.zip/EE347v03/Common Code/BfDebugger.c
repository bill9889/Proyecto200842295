/*****************************************************************************
**                                                                          **
**  Name:   BfUartDebugger                                                  **
**                                                                          **
******************************************************************************

(C) Copyright 2009 - 2012 Analog Devices, Inc.  All rights reserved.

File Name:      BfDebugger.c

Date Modified:  03/29/2012

Processor:      Blackfin

Software:       VisualDSP++ 5.0

Purpose:        This header files includes the target specific ADSP-BF5xx-UART.c files,
                depending the predefined preprocessor processor target macros. These files
                contain target individual settings.

******************************************************************************/


/*******************************************************************************
*
*  Include File Area
*
*******************************************************************************/

#include <blackfin.h>

#include <stdio.h>
#include <stdarg.h>
#include <string.h>

#include <sys/exception.h>

#include "init_platform.h"
#include "system.h"

#include "BfDebugger.h"

/*******************************************************************************
*
*  Exported Constants/Definitions Area
*
*******************************************************************************/

/*******************************************************************************
*
*  Exported Types Area
*
*******************************************************************************/

/*******************************************************************************
*
*  Exported Macros Area
*
*******************************************************************************/

/*******************************************************************************
*
*  Exported Function Prototypes Area
*
*******************************************************************************/

/*******************************************************************************
*
*  Internal Function Prototypes Area
*
*******************************************************************************/

#if (__UART_IO_DEVICE__ == 1)

int  uart_console_init(struct DevEntry *dev);
int  uart_console_open(const char *name, int mode);
int  uart_console_close(int fd);
int  uart_console_write(int fd, unsigned char *buf, int size);
int  uart_console_read(int fd, unsigned char *buf, int size);
long uart_console_seek(int fd, long offset, int whence);

#endif /* (__UART_IO_DEVICE__ == 1) */

/*******************************************************************************
*
*  Internal Data Area
*
*******************************************************************************/

char strbuf[STRINGSIZE];
// BUFSIZ defined in stdio.h
//char strbuf[BUFSIZ];

/*******************************************************************************
*
*  Exported Data Area
*
*******************************************************************************/

#if (__UART_IO_DEVICE__ == 1)

struct DevEntry UartIODevice = {
    UartIOFileId,       /* Device ID for libIO purposes */
    NULL,               /* Data area */
    uart_console_init,  /* init function point */
    uart_console_open,  /* open function pointer */
    uart_console_close, /* close function pointer */
    uart_console_write, /* write function pointer */
    uart_console_read,  /* read function pointer */
    uart_console_seek,  /* seek function pointer */
#if (__PRE_REGISTERING_DEVICE__ == 1)
    NULL,
    NULL,
    NULL
#else
    dev_not_claimed,
    dev_not_claimed,
    dev_not_claimed
#endif
};

#endif /* (__UART_IO_DEVICE__ == 1) */

/*******************************************************************************
*
*  Function Area
*
*******************************************************************************/


#if ( (__DEBUG_UART_DMA__ == 1) || (__DEBUG_UART__ == 1) )

//***************************************
//*
//* Function Name : short uprintf(unsigned char UartNum, const char *format, /* args */ ...)
//* Description   : The uprintf function places output on the UART in a form
//*                 specified by format. The uprintf function is equivalent to
//*                 udprintf with DMA based UART transfer. The argument format
//*                 contains a set of conversion specifiers, directives, and
//*                 ordinary characters that are used to control how the data
//*                 is formatted. Refer to 'fprintf' in the C Run-Time Library
//*                 Reference for a description of the valid format specifiers.
//*
//* Parameters    : uchar UartNum, const char *format, arguments
//* Returns       : The uprintf function returns the number of
//*                 characters transmitted, excluding 'carriage return'.
//*                 If the uprintf function is unsuccessful, a negative value is returned.
//* Globals       : char strbuf[STRINGSIZE]
//*
//* Control Commands:
//*                     '\e' escape character. It maps to the ASCII Escape code, 27
//*                     '\f' form feed/flush screen
//*                     '\n' new line
//*                     '\r' carriage return
//*                     '\t' horizontal tab
//*                     '\v' vertical tab
//*
short uprintf(unsigned char UartNum, const char *fmt, ...)
{
    short outsize;
    va_list ap;

    /* return failure if format is NULL pointer */
    if (!fmt) { return -1; }
    /* return failure if string exceeds buffer size, two additional characters required: carriage return & NULL termination */
    if (sizeof(strbuf)<(strlen(fmt)-1)) { return -1; }

    va_start (ap,fmt);
    outsize = vsprintf(strbuf,fmt,ap);
    /* insert carriage return, if newline is detected */
    if (strbuf[outsize-1] == '\n') { strbuf[outsize] = '\r'; }
    /* insert newline, if only carriage return is detected */
    else if (strbuf[outsize-1] == '\r') { strbuf[outsize] = '\n'; }
    /* ensure NULL-termination (C-style) */
    strbuf[outsize+1] = NULL;
    va_end (ap);

    UartPuts(UartNum,strbuf);
//    UartPutsn(UartNum,strbuf,outsize+1);

    return outsize;
}


//***************************************
//*
//* Function Name : short udprintf(unsigned char UartNum, unsigned char DmaChan, const char *format, /* args */ ...)
//* Description   : The udprintf function places output on the UART in a form
//*                 specified by format. The uprintf function is equivalent to
//*                 uprintf with CORE based UART transfer. The argument format
//*                 contains a set of conversion specifiers, directives, and
//*                 ordinary characters that are used to control how the data
//*                 is formatted. Refer to 'fprintf' in the C Run-Time Library
//*                 Reference for a description of the valid format specifiers.
//*
//* Parameters    : uchar UartNum, uchar DmaChan, const char *format, arguments
//* Returns       : The udprintf function returns the number of
//*                 characters transmitted, excluding 'carriage return'.
//*                 If the udprintf function is unsuccessful, a negative value is returned.
//* Globals       : char strbuf[STRINGSIZE]
//*
//* Control Commands:
//*                     '\e' escape character. It maps to the ASCII Escape code, 27
//*                     '\f' form feed/flush screen
//*                     '\n' new line
//*                     '\r' carriage return
//*                     '\t' horizontal tab
//*                     '\v' vertical tab
//*
short udprintf(unsigned char UartNum, unsigned char DmaChan, const char *fmt, ...)
{
    short outsize;
    va_list ap;

    /* return failure if format is NULL pointer */
    if (!fmt) { return -1; }
    /* return failure if string exceeds buffer size, two additional characters required: carriage return & NULL termination */
    if (sizeof(strbuf)<(strlen(fmt)-1)) { return -1; }

//    UartDmaWaitForTransmitCompletion(UartNum,DmaChan);
    UartDmaWaitForDmaDone(DmaChan);

    va_start (ap,fmt);
    outsize = vsprintf(strbuf,fmt,ap);
    /* insert carriage return, if newline is detected */
    if (strbuf[outsize-1] == '\n') { strbuf[outsize] = '\r'; }
    /* insert newline, if only carriage return is detected */
    else if (strbuf[outsize-1] == '\r') { strbuf[outsize] = '\n'; }
    /* ensure NULL-termination (C-style) */
    strbuf[outsize+1] = NULL;
    va_end (ap);

    UartDmaPuts(UartNum,DmaChan,strbuf);
//    UartDmaPutsn(UartNum,DmaChan,strbuf,outsize+1);

    return outsize;
}


#endif /* (__DEBUG_UART_DMA__ == 1) || (__DEBUG_UART__ == 1) */


//***************************************
//*
//* Function Name : short fileprintf(const char *filename, const char *format, /* args */ ...)
//* Description   : The fileprintf function places output on the filename in a form
//*                 specified by format. The argument format
//*                 contains a set of conversion specifiers, directives, and
//*                 ordinary characters that are used to control how the data
//*                 is formatted. Refer to 'fprintf' in the C Run-Time Library
//*                 Reference for a description of the valid format specifiers.
//*
//* Parameters    : const char *filename, const char *format, arguments
//* Returns       : The uprintf function returns the number of
//*                 characters transmitted.
//* Globals       : none
//*
//* Control Commands:
//*                     '\e' escape character. It maps to the ASCII Escape code, 27
//*                     '\f' form feed/flush screen
//*                     '\n' new line
//*                     '\r' carriage return
//*                     '\t' horizontal tab
//*                     '\v' vertical tab
//*
short fileprintf(const char *filename, const char *fmt, ...)
{
    short outsize;
    va_list ap;
    FILE *pDebugFile;

    // return failure if format is NULL pointer
    if (!fmt) { return -1; }

    pDebugFile = fopen("debug.txt","a");
    if (pDebugFile != NULL) {
        va_start (ap,fmt);
        outsize = vfprintf(pDebugFile, fmt, ap);
        fclose(pDebugFile);
        va_end (ap);
        }
    else {
        fclose(pDebugFile);
        return -1;
        }
    return outsize;
}


#if (__UART_IO_DEVICE__ == 1)


//***************************************
//*
//* Function Name : int uart_console_init(struct DevEntry *pDevEntry)
//* Description   : Assigns/Initializes the Device Manager
//*                 The init field is a pointer to an initialization function.
//*                 The run-time library calls this function when the device
//*                 is first registered, passing in the address of this
//*                 structure (and thus giving the init function access to
//*                 DeviceID and the field data).
//*
//* Parameters    : struct DevEntry *pDevEntry
//* Returns       : If the init function encounters an error, it must return -1;
//*                 otherwise, it returns a positive value to indicate success.
//* Globals       : none
//*
int uart_console_init(struct DevEntry *pDevEntry)
{
    return 1;
}


//***************************************
//*
//* Function Name : int uart_console_write(int fd, unsigned char *buf, int size)
//* Description   : writes given buffer to current file position
//*                 The write field is a pointer to a function that performs the
//*                 "write to file" operation on the device. The run-time library
//*                 calls the write function in response to requests, such as
//*                 fwrite(), fprintf(), and so on, that act on streams that were
//*                 opened on the device.
//*
//* Parameters    : int fd, unsigned char *buf, int size
//* Returns       : - A positive value from 1 to size inclusive, indicating how many
//*                   bytes from buf were successfully written to the file
//*                 - Zero, indicating that the file has been closed, for whatever reason
//*                   (for example, the network connection dropped)
//*                 - A negative value, indicating an error
//* Globals       : none
//*
int uart_console_write(int fd, unsigned char *buf, int size)
{
    /* return failure if string exceeds buffer size */
    if (BUFSIZ<(size-2)) { return -1; }

    /* insert carriage return, if newline is detected */
    if (buf[size-1] == '\n') { buf[size] = '\r'; }
    /* ensure NULL-termination (C-style) */
    buf[size+1] = NULL;

#if (__DEBUG_UART__ == 1)
    if (UartPuts(USE_UART_NR,(char*) buf) == -1) { return -1; }
    return size;
#elif (__DEBUG_UART_DMA__ == 1)
    if (UartDmaPuts(USE_UART_NR,USE_UART_DMA_NR,(char*) buf) == -1) { return -1; }
    // This is to avoid overwriting the transmit buffer with the next message
    // before sending out the previous message
//    if (UartDmaWaitForTransmitCompletion(USE_UART_NR,USE_UART_DMA_NR) == -1) { return -1; }
    if (UartDmaWaitForDmaDone(USE_UART_DMA_NR) == -1) { return -1; }
    return size;
#else
    #error either "__DEBUG_UART_DMA__" or "__DEBUG_UART__" is missing
    return -1;
#endif
}


//***************************************
//*
//* Function Name : int uart_console_open(const char *name, int mode)
//* Description   : Opens the named file for access according to the
//*                 mode argument. Returns File Descriptor Handle
//*                 The open field is a pointer to a function that performs
//*                 the "open file" operation upon the device. The run-time
//*                 library calls this function in response to requests such
//*                 as fopen(), when the device is the currently selected
//*                 default device. The name parameter is the path name to
//*                 the file to be opened, and the mode parameter is a bitmask
//*                 that indicates how the file is to be opened.
//*                 Bits 0-1 indicate reading and/or writing.
//*
//* Parameters    : const char *name, int mode
//* Returns       : The open function must return a positive "file descriptor"
//*                 if it succeeds in opening the file; this file descriptor
//*                 is used to identify the file to the device in subsequent
//*                 operations. The file descriptor must be unique for all files
//*                 currently open for the device, but need not be distinct from
//*                 file descriptors returned by other devices - the run-time
//*                 library identifies the file by the combination of device and
//*                 file descriptor.
//*                 If the open function fails, it must return -1 to indicate failure.
//* Globals       : none
//*
int uart_console_open(const char *name, int mode)
{
    DEBUG_OPEN();
    return 1;
}


//***************************************
//*
//* Function Name : int uart_console_close(int fd)
//* Description   : Closes the file, and frees memory
//*                 The close field is a pointer to a function that performs
//*                 the "close file" operation on the device. The run-time
//*                 library calls the close function in response to requests
//*                 such as fclose() on a stream that was opened on the device.
//*                 The fd parameter is a file descriptor previously returned
//*                 by a call to the open function.
//*
//* Parameters    : int fd
//* Returns       : The close function must return a zero value for success
//*                 and must return a non-zero value for failure.
//* Globals       : none
//*
int uart_console_close(int fd)
{
    DEBUG_CLOSE();
    return 1;
}


//***************************************
//*
//* Function Name : int uart_console_read(int fd, unsigned char *buf, int size)
//* Description   : reads into given buffer from current file position
//*                 The read field is a pointer to a function that performs
//*                 the "read from file" operation on the device. The run-time
//*                 library calls the read function in response to requests,
//*                 such as fread(), fscanf(), and so on, that act on streams
//*                 that were opened on the device.
//*
//* Parameters    : int fd, unsigned char *buf, int size
//* Returns       : The read function must return one of the following values:
//*                 - A positive value from 1 to size inclusive, indicating how
//*                   many bytes were read from the file into buf
//*                 - Zero, indicating end-of-file
//*                 - A negative value, indicating an error
//*                 The run-time library expects the read function to
//*                 return 0xa (10) as the newline character.
//* Globals       : none
//*
int uart_console_read(int fd, unsigned char *buf, int size)
{
    return -1;
}


//***************************************
//*
//* Function Name : long uart_console_seek(int fd, long offset, int whence)
//* Description   : seeks to new position according to arguments
//*                 The seek field is a pointer to a function that performs
//*                 dynamic access on the file. The run-time library calls
//*                 the seek function in response to requests such as rewind(),
//*                 fseek(), and so on that act on streams that were opened on
//*                 the device.
//*
//* Parameters    : int fd, long offset, int whence
//* Returns       : The seek function returns a positive value that is the
//*                 new (absolute) position of the read/write pointer within
//*                 the file. If an error is encountered, the seek function
//*                 must return a negative value.
//* Globals       : none
//*
long uart_console_seek(int fd, long offset, int whence)
{
    return -1;
}


#endif /* (__UART_IO_DEVICE__ == 1) */


//***************************************
//*
//* Function Name : void WelcomeMessage(void) / void WelcomeMessage2(FILE* fp)
//* Description   : print a "welcome message" to the selected screen
//*
//* Parameters    : none / FILE* fp
//* Returns       : none
//* Globals       : none
//*

#if (__OTP__ == 0)


void WelcomeMessage(void)
{
    DEBUG(1,""_RESETSCREEN_"");
    DEBUG(1,"                                         ,8888oo."_NL_"");
    DEBUG(1,"                                          Y8888888o."_NL_"");
    DEBUG(1,"                                           Y888888888L"_NL_"");
    DEBUG(1,"                                            Y8888888888L"_NL_"");
    DEBUG(1,"                                             888888888888L"_NL_"");
    DEBUG(1,"                                             d8888888888888."_NL_"");
    DEBUG(1,"                                             ]888888888888888."_NL_"");
    DEBUG(1,"                                             ]888888888PP''''"_NL_"");
    DEBUG(1,"                                             ]8888888P'          ."_NL_"");
    DEBUG(1,"    ,ooooo.                                  ]88888P    ,ooooooo88b."_NL_"");
    DEBUG(1,"   ,8888888p                                 ]8888P   ,8888888888888o"_NL_"");
    DEBUG(1,"   d88P'888[ ooo'    oooo.  _oooo.  ooo  oop ]888P    `'' ,888P8888888o"_NL_"");
    DEBUG(1,"  ,888 J88P J88P    d8P88  d88P888 ,88P,88P  `P''       ,88P' ,888888888L"_NL_"");
    DEBUG(1,"  d888o88P' 888'   ,8P,88 ,88P 88P d88b88P    __    d88888[ _o8888888P8888."_NL_"");
    DEBUG(1," ,8888888. J88P    88'd8P d88  '' ,88888P    d8'   d888888888888888P   88PYb."_NL_"");
    DEBUG(1," d88P 888P 888'   d8P 88[,88P ,o_ d88888.   ,8P   d8888P'  88888P'    P'   ]8b_"_NL_"");
    DEBUG(1,",888']888'J88P   d888888 d88'J88',88Pd88b   JP   d888P     888P',op    ,   d88P"_NL_"");
    DEBUG(1,"d8888888P d88bo.,88P'Y8P 888o88P d88']88b   d'  ,8P'_odb   ''',d8P  _o8P  ,P',,d8L"_NL_"");
    DEBUG(1,"PPPPPPP' `PPPPP YPP  PPP `PPPP' <PPP `PPP  ,P   88o88888.  ,o888'  o888     d888888."_NL_"");
    DEBUG(1,"                                           d'  d888888888888888L_o88888L_,o888888888b."_NL_"");
    DEBUG(1,"                                          dP  d888888888888888888888888888888888888888o"_NL_"");
    DEBUG(1,"                                        dd8' ,888888888888888888888888888888888888888888L"_NL_"");
    DEBUG(1,"                                       d88P  d88888888888888888888888888888888888888888888."_NL_"");
    DEBUG(1,""_VTAB_"");
    DEBUG(1,"File: %s | Line: %d | Function: %s"_NL_"",__FILE__,__LINE__,__func__);
    DEBUG(1,"Build Date: %s | Build Time: %s"_NL_"",__DATE__,__TIME__);
    DEBUG(1,""_VTAB_"");

    INFO(1,"Core    Clock: %9d Hz"_NL_"",get_cclk_hz());
    INFO(1,"System  Clock: %9d Hz"_NL_"",get_sclk_hz());

#if ( (__DEBUG_UART__ == 1) || (__DEBUG_UART_DMA__ == 1) )
#if (AUTOBAUD == 1)
    INFO(1,"UART%d Bitrate: %9d Bit/s"_NL_"", USE_UART_NR, UartGetBitrate(USE_UART_NR));
#else
    INFO(1,"UART%d Bitrate: %9d Bit/s (%d Bit/s)"_NL_"", USE_UART_NR, UartGetBitrate(USE_UART_NR),USE_UART_BITRATE);
#endif
#endif

    DEBUG(1,"\n");
}


void WelcomeMessage2(FILE* fp)
{
//    if (fp->fileID != UartIOFileId) { fprintf(fp,""_RESETSCREEN_""); } else { fprintf(fp,"\n"); }
    fprintf(fp,""_RESETSCREEN_"");
    fprintf(fp,"                                         ,8888oo.\n");
    fprintf(fp,"                                          Y8888888o.\n");
    fprintf(fp,"                                           Y888888888L\n");
    fprintf(fp,"                                            Y8888888888L\n");
    fprintf(fp,"                                             888888888888L\n");
    fprintf(fp,"                                             d8888888888888.\n");
    fprintf(fp,"                                             ]888888888888888.\n");
    fprintf(fp,"                                             ]888888888PP''''\n");
    fprintf(fp,"                                             ]8888888P'          .\n");
    fprintf(fp,"    ,ooooo.                                  ]88888P    ,ooooooo88b.\n");
    fprintf(fp,"   ,8888888p                                 ]8888P   ,8888888888888o\n");
    fprintf(fp,"   d88P'888[ ooo'    oooo.  _oooo.  ooo  oop ]888P    `'' ,888P8888888o\n");
    fprintf(fp,"  ,888 J88P J88P    d8P88  d88P888 ,88P,88P  `P''       ,88P' ,888888888L\n");
    fprintf(fp,"  d888o88P' 888'   ,8P,88 ,88P 88P d88b88P    __    d88888[ _o8888888P8888.\n");
    fprintf(fp," ,8888888. J88P    88'd8P d88  '' ,88888P    d8'   d888888888888888P   88PYb.\n");
    fprintf(fp," d88P 888P 888'   d8P 88[,88P ,o_ d88888.   ,8P   d8888P'  88888P'    P'   ]8b_\n");
    fprintf(fp,",888']888'J88P   d888888 d88'J88',88Pd88b   JP   d888P     888P',op    ,   d88P\n");
    fprintf(fp,"d8888888P d88bo.,88P'Y8P 888o88P d88']88b   d'  ,8P'_odb   ''',d8P  _o8P  ,P',,d8L\n");
    fprintf(fp,"PPPPPPP' `PPPPP YPP  PPP `PPPP' <PPP `PPP  ,P   88o88888.  ,o888'  o888     d888888.\n");
    fprintf(fp,"                                           d'  d888888888888888L_o88888L_,o888888888b.\n");
    fprintf(fp,"                                          dP  d888888888888888888888888888888888888888o\n");
    fprintf(fp,"                                        dd8' ,888888888888888888888888888888888888888888L\n");
    fprintf(fp,"                                       d88P  d88888888888888888888888888888888888888888888.\n");
    fprintf(fp,"\n");
    fprintf(fp,"File: %s | Line: %d | Function: %s\n",__FILE__,__LINE__,__func__);
    fprintf(fp,"Build Date: %s | Build Time: %s\n",__DATE__,__TIME__);
    fprintf(fp,"\n");

    fprintf(fp,"Core    Clock: %9d Hz"_NL_"",get_cclk_hz());
    fprintf(fp,"System  Clock: %9d Hz"_NL_"",get_sclk_hz());
    fprintf(fp,"\n");
}


#else /* (__OTP__ == 1) */


void WelcomeMessage(void)
{
#if defined(__ADSPBF51x__)
    #define OTP_INIT_VALUE_READ 0x14548750
#elif defined(__ADSPBF52x__)
    #define OTP_INIT_VALUE_READ 0x00001485
#elif defined(__ADSPBF54x__)
    #define OTP_INIT_VALUE_READ 0x0A009464
#else
    #error Processor not supported
#endif
    long part[4]; //Two 64-bit elements to hold the upper & lower halves of the partnumber
    u64 idupper, idlower; //Two 64-bit elements to hold the upper & lower halves of the unique chip id
    u32 return_code;

    return_code = bfrom_OtpCommand( OTP_INIT, OTP_INIT_VALUE_READ);
    return_code = bfrom_OtpRead(FPS03, OTP_LOWER_HALF, (u64*)part);
    return_code = bfrom_OtpRead(FPS03, OTP_UPPER_HALF, (u64*)part+1);
    return_code = bfrom_OtpRead(FPS00, OTP_LOWER_HALF, &idlower);
    return_code = bfrom_OtpRead(FPS00, OTP_UPPER_HALF, &idupper);
    return_code = bfrom_OtpCommand( OTP_CLOSE, 0);

    DEBUG(1,""_RESETSCREEN_"");
    DEBUG(1,"                                         ,8888oo."_NL_"");
    DEBUG(1,"                                          Y8888888o."_NL_"");
    DEBUG(1,"                                           Y888888888L"_NL_"");
    DEBUG(1,"                                            Y8888888888L"_NL_"");
    DEBUG(1,"                                             888888888888L"_NL_"");
    DEBUG(1,"                                             d8888888888888."_NL_"");
    DEBUG(1,"                                             ]888888888888888."_NL_"");
    DEBUG(1,"                                             ]888888888PP''''"_NL_"");
    DEBUG(1,"                                             ]8888888P'          ."_NL_"");
    DEBUG(1,"    ,ooooo.     Model: %16s      ]88888P    ,ooooooo88b."_NL_"", part);
    DEBUG(1,"   ,8888888p                                 ]8888P   ,8888888888888o"_NL_"");
    DEBUG(1,"   d88P'888[ ooo'    oooo.  _oooo.  ooo  oop ]888P    `'' ,888P8888888o"_NL_"");
    DEBUG(1,"  ,888 J88P J88P    d8P88  d88P888 ,88P,88P  `P''       ,88P' ,888888888L"_NL_"");
    DEBUG(1,"  d888o88P' 888'   ,8P,88 ,88P 88P d88b88P    __    d88888[ _o8888888P8888."_NL_"");
    DEBUG(1," ,8888888. J88P    88'd8P d88  '' ,88888P    d8'   d888888888888888P   88PYb."_NL_"");
    DEBUG(1," d88P 888P 888'   d8P 88[,88P ,o_ d88888.   ,8P   d8888P'  88888P'    P'   ]8b_"_NL_"");
    DEBUG(1,",888']888'J88P   d888888 d88'J88',88Pd88b   JP   d888P     888P',op    ,   d88P"_NL_"");
    DEBUG(1,"d8888888P d88bo.,88P'Y8P 888o88P d88']88b   d'  ,8P'_odb   ''',d8P  _o8P  ,P',,d8L"_NL_"");
    DEBUG(1,"PPPPPPP' `PPPPP YPP  PPP `PPPP' <PPP `PPP  ,P   88o88888.  ,o888'  o888     d888888."_NL_"");
    DEBUG(1,"                                           d'  d888888888888888L_o88888L_,o888888888b."_NL_"");
    DEBUG(1," idl: 0x%016llX                  dP  d888888888888888888888888888888888888888o"_NL_"", idlower);
    DEBUG(1," idh: 0x%016llX                dd8' ,888888888888888888888888888888888888888888L"_NL_"", idupper);
    DEBUG(1,"                                       d88P  d88888888888888888888888888888888888888888888."_NL_"");
    DEBUG(1,""_VTAB_"");
    DEBUG(1,"File: %s | Line: %d | Function: %s"_NL_"",__FILE__,__LINE__,__func__);
    DEBUG(1,"Build Date: %s | Build Time: %s"_NL_"",__DATE__,__TIME__);
    DEBUG(1,""_VTAB_"");

    INFO(1,"Core    Clock: %9d Hz"_NL_"",get_cclk_hz());
    INFO(1,"System  Clock: %9d Hz"_NL_"",get_sclk_hz());

#if ( (__DEBUG_UART__ == 1) || (__DEBUG_UART_DMA__ == 1) )
#if (AUTOBAUD == 1)
    INFO(1,"UART%d Bitrate: %9d Bit/s"_NL_"", USE_UART_NR, UartGetBitrate(USE_UART_NR));
#else
    INFO(1,"UART%d Bitrate: %9d Bit/s (%d Bit/s)"_NL_"", USE_UART_NR, UartGetBitrate(USE_UART_NR),USE_UART_BITRATE);
#endif
#endif

    DEBUG(1,"\n");
}


void WelcomeMessage2(FILE* fp)
{
#if defined(__ADSPBF51x__)
    #define OTP_INIT_VALUE_READ 0x14548750
#elif defined(__ADSPBF52x__)
    #define OTP_INIT_VALUE_READ 0x00001485
#elif defined(__ADSPBF54x__)
    #define OTP_INIT_VALUE_READ 0x0A009464
#else
    #error Processor not supported
#endif
    long part[4]; //Two 64-bit elements to hold the upper & lower halves of the partnumber
    u64 idupper, idlower; //Two 64-bit elements to hold the upper & lower halves of the unique chip id
    u32 return_code;

    return_code = bfrom_OtpCommand( OTP_INIT, OTP_INIT_VALUE_READ);
    return_code = bfrom_OtpRead(FPS03, OTP_LOWER_HALF, (u64*)part);
    return_code = bfrom_OtpRead(FPS03, OTP_UPPER_HALF, (u64*)part+1);
    return_code = bfrom_OtpRead(FPS00, OTP_LOWER_HALF, &idlower);
    return_code = bfrom_OtpRead(FPS00, OTP_UPPER_HALF, &idupper);
    return_code = bfrom_OtpCommand( OTP_CLOSE, 0);

//    if (fp->fileID == UartIOFileId) { fprintf(fp,""_RESETSCREEN_""); } else { fprintf(fp,"\n"); }
    fprintf(fp,""_RESETSCREEN_"");
    fprintf(fp,"                                         ,8888oo.\n");
    fprintf(fp,"                                           Y888888888L\n");
    fprintf(fp,"                                            Y8888888888L\n");
    fprintf(fp,"                                             888888888888L\n");
    fprintf(fp,"                                             d8888888888888.\n");
    fprintf(fp,"                                             ]888888888888888.\n");
    fprintf(fp,"                                             ]888888888PP''''\n");
    fprintf(fp,"                                             ]8888888P'          .\n");
    fprintf(fp,"    ,ooooo.     Model: %16s      ]88888P    ,ooooooo88b.\n", part);
    fprintf(fp,"   ,8888888p                                 ]8888P   ,8888888888888o\n");
    fprintf(fp,"   d88P'888[ ooo'    oooo.  _oooo.  ooo  oop ]888P    `'' ,888P8888888o\n");
    fprintf(fp,"  ,888 J88P J88P    d8P88  d88P888 ,88P,88P  `P''       ,88P' ,888888888L\n");
    fprintf(fp,"  d888o88P' 888'   ,8P,88 ,88P 88P d88b88P    __    d88888[ _o8888888P8888.\n");
    fprintf(fp," ,8888888. J88P    88'd8P d88  '' ,88888P    d8'   d888888888888888P   88PYb.\n");
    fprintf(fp," d88P 888P 888'   d8P 88[,88P ,o_ d88888.   ,8P   d8888P'  88888P'    P'   ]8b_\n");
    fprintf(fp,",888']888'J88P   d888888 d88'J88',88Pd88b   JP   d888P     888P',op    ,   d88P\n");
    fprintf(fp,"d8888888P d88bo.,88P'Y8P 888o88P d88']88b   d'  ,8P'_odb   ''',d8P  _o8P  ,P',,d8L\n");
    fprintf(fp,"PPPPPPP' `PPPPP YPP  PPP `PPPP' <PPP `PPP  ,P   88o88888.  ,o888'  o888     d888888.\n");
    fprintf(fp,"                                           d'  d888888888888888L_o88888L_,o888888888b.\n");
    fprintf(fp," idl: 0x%016llX                  dP  d888888888888888888888888888888888888888o\n", idlower);
    fprintf(fp," idh: 0x%016llX                dd8' ,888888888888888888888888888888888888888888L\n", idupper);
    fprintf(fp,"                                       d88P  d88888888888888888888888888888888888888888888.\n");
    fprintf(fp,"\n");
    fprintf(fp,"File: %s | Line: %d | Function: %s\n",__FILE__,__LINE__,__func__);
    fprintf(fp,"Build Date: %s | Build Time: %s\n",__DATE__,__TIME__);
    fprintf(fp,"\n");

    fprintf(fp,"Core    Clock: %9d Hz"_NL_"",get_cclk_hz());
    fprintf(fp,"System  Clock: %9d Hz"_NL_"",get_sclk_hz());
    fprintf(fp,"\n");
}


#endif /* (__OTP__ == 0) */


/******************************** End of File *********************************/
