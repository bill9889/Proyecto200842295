/*****************************************************************************
**                                                                          **
**  Name:   SYSTEM                                                          **
**                                                                          **
******************************************************************************

(C) Copyright 2009 - Analog Devices, Inc.  All rights reserved.

File Name:      system.c

Date Modified:  03/29/2012

Processor:      Blackfin

Software:       VisualDSP++ 5.0

Purpose:        

******************************************************************************/

/*******************************************************************************
*
*  Include File Area
*
*******************************************************************************/

#include <blackfin.h>

#include <stdio.h>
#include <stdlib.h>
#include <stdarg.h>
#include <string.h>

#include <sys/exception.h>
#include <cplb.h>
#include <cplbtab.h>

#include <btc.h>

#include "init_platform.h"
#include "system.h"

#if (__ADSPBF54x__ == 1)
    #include "NOR_FLASH.h"
#endif

#if (__EXTVOLTAGE__ == 1)
    #include "VR_DIGIPOT.h"
#endif

#include "BfDebugger.h"

/*******************************************************************************
*
*  Internal Constants Area
*
*******************************************************************************/

/*******************************************************************************
*
*  Internal Definition Area
*
*******************************************************************************/

/*******************************************************************************
*
*  Internal Types Area
*
*******************************************************************************/

/*******************************************************************************
*
*  Internal Macros Area
*
*******************************************************************************/

/*******************************************************************************
*
*  Internal Function Prototypes Area
*
*******************************************************************************/

/*******************************************************************************
*
*  Global Variables
*
*******************************************************************************/

#if defined (__BTC__)
    unsigned long SequencerStatus;
    unsigned long tbuf[32];
#endif


/*******************************************************************************
*
*  BTC Definitions
*
*******************************************************************************/

#if defined (__BTC__)
    BTC_MAP_BEGIN
    //             Channel Name,        Starting Address,                   Length
    BTC_MAP_ENTRY("Sequencer Status",   (unsigned long)&SequencerStatus,    sizeof(SequencerStatus))
    BTC_MAP_ENTRY("Trace Buffer",       (unsigned long)&tbuf,               sizeof(tbuf))
    BTC_MAP_END
#endif


/*******************************************************************************
*
*  Functions Area
*
*******************************************************************************/


#if (__USEBFSYSCONTROL__ == 1)


#if (__EXTVOLTAGE__ == 1)


/***************************************
 *
 * Function Name : full_on
 * Description   : set Voltage Regulator and PLL Registers
 *
 * Parameters    : none
 * Returns       : none
 * Globals       : none
 */
void full_on(void)
{
    ADI_SYSCTRL_VALUES init;
    TRUE SkipVr;
    ERROR_CODE Result;
    u32 ulCnt = 0;
    u8 usRdac = 0;
    #if (__WORKAROUND_05000432__ == 1)
        u32 SIC_IWR1_reg;
        SIC_IWR1_reg = *pSIC_IWR1;  /* Save value of SIC_IWR1 */
        *pSIC_IWR1 = 0;             /* Disable wakeups from SIC_IWR1 */
    #endif


    /*****************************************************************************
     If you change VDDint without putting the PLL into bypass / active mode, you
     risk running at excessive speed. As in Active mode or in the transition phase
     to other modes, changes to MSEL are not latched by the PLL, the PLL registers
     will be pre-programmed with the desired values when entering Active mode.
     When the PLL is in bypass, the external voltage regulator can be programmed
     ( vr_digipot_program() ) and the active mode can be left afterwards.
    *****************************************************************************/

    usRdac = vr_digipot_rdac_read();

    if ( usRdac == RDAC_STEP_VAL ) {
        init.uwPllCtl = PLL_CTL_VAL;
        SkipVr = YES;
    }
    else {
        init.uwPllCtl = ( PLL_CTL_VAL | BYPASS ); /* pre-load PLL_CTL register with new values as changes to MSEL will not be latched when in or leaving active mode */
        SkipVr = NO;
    }

    init.uwPllLockCnt = PLL_LOCKCNT_VAL;

    #if (__WORKAROUND_05000440__ == 1)
        *pPLL_DIV = PLL_DIV_VAL;
        bfrom_SysControl( SYSCTRL_EXTVOLTAGE | SYSCTRL_PLLCTL |                  SYSCTRL_LOCKCNT | SYSCTRL_WRITE, &init, NULL );
    #else
        init.uwPllDiv = PLL_DIV_VAL;
        bfrom_SysControl( SYSCTRL_EXTVOLTAGE | SYSCTRL_PLLCTL | SYSCTRL_PLLDIV | SYSCTRL_LOCKCNT | SYSCTRL_WRITE, &init, NULL );
    #endif


    /*****************************************************************************
     The external voltage regulator on the
     ADSP-BF518F EZ-Board and
     ADSP-BF526 EZ-Board
     requires about 100us to stabilize. We keep the core in the meantime in a
     delay loop until we can safely leave active mode. As we bypass the PLL, the 
     core needs to wait 100*(10^-6)*CLKIN cycles. When VDDint is stable, the PLL
     needs additionally 0x0200 (512) CLKIN cycles to re-lock (please see the data
     sheet of your product for required PLL_LOCKCNT value).
     The compiler (no optimization enabled) will create a loop that takes about
     10 cylces -> ( CLKIN[Hz] / ( 10 * 10,000 ) ) or CLKIN_Hz >> 16.
     That is no perfect but robust calculation. It safes execution time.
    *****************************************************************************/

    if ( SkipVr == NO ) {
        Result = vr_digipot_program();
//        if ( Result == ERROR ) { asm("EMUEXCPT;"); while(1); }

        ulCnt = ( ( CLKIN_Hz >> 16 ) + 0x0200 );
        while (ulCnt != 0) {ulCnt--;}

        init.uwPllCtl = PLL_CTL_VAL;
        bfrom_SysControl( SYSCTRL_EXTVOLTAGE | SYSCTRL_PLLCTL | SYSCTRL_WRITE, &init, NULL );
    }


    #if (__WORKAROUND_05000432__ == 1)
        *pSIC_IWR1 = SIC_IWR1_reg;  /* Restore original SIC_IWR1 register value */
    #endif


    return;
}


#else /* (__EXTVOLTAGE__ == 0) */


/***************************************
 *
 * Function Name : full_on
 * Description   : set Voltage Regulator and PLL Registers
 *
 * Parameters    : none
 * Returns       : none
 * Globals       : none
 */
void full_on(void)
{
    ADI_SYSCTRL_VALUES init;
    #if (__WORKAROUND_05000432__ == 1)
        u32 SIC_IWR1_reg;
        SIC_IWR1_reg = *pSIC_IWR1;  /* Save value of SIC_IWR1 */
        *pSIC_IWR1 = 0;             /* Disable wakeups from SIC_IWR1 */
    #endif


    init.uwVrCtl = VR_CTL_VAL;
    init.uwPllCtl = PLL_CTL_VAL;
    init.uwPllLockCnt = PLL_LOCKCNT_VAL;


    #if (__WORKAROUND_05000440__ == 1)
        *pPLL_DIV = PLL_DIV_VAL;
        bfrom_SysControl( SYSCTRL_VRCTL | SYSCTRL_INTVOLTAGE | SYSCTRL_PLLCTL |                  SYSCTRL_LOCKCNT | SYSCTRL_WRITE, &init, NULL );
    #else
        init.uwPllDiv = PLL_DIV_VAL;
        bfrom_SysControl( SYSCTRL_VRCTL | SYSCTRL_INTVOLTAGE | SYSCTRL_PLLCTL | SYSCTRL_PLLDIV | SYSCTRL_LOCKCNT | SYSCTRL_WRITE, &init, NULL );
    #endif


    #if (__WORKAROUND_05000432__ == 1)
        *pSIC_IWR1 = SIC_IWR1_reg;  /* Restore original SIC_IWR1 register value */
    #endif


    return;
}


#endif /* (__EXTVOLTAGE__ == 1) */


/***************************************
 *
 * Function Name : get_vco_hz
 * Description   : get current PLL VCO clock frequency in Hz
 *
 * Parameters    : none
 * Returns       : u32 VCO [Hz]
 * Globals       : none
 */
u32 get_vco_hz(void)
{
    u32 udMSEL = 0;
    u32 udVCO_Hz = 0;
    ADI_SYSCTRL_VALUES vco;

    bfrom_SysControl ( SYSCTRL_READ | SYSCTRL_PLLCTL, &vco, NULL );

    udMSEL = ( (vco.uwPllCtl & MSEL) >> 9 );
    if ( udMSEL == 0 ) { udMSEL = 64; }
    udVCO_Hz = ( udMSEL * CLKIN_Hz );

    return ( udVCO_Hz >> (DF & vco.uwPllCtl) );
}


/***************************************
 *
 * Function Name : get_cclk_hz
 * Description   : get current core clock frequency in Hz
 *
 * Parameters    : none
 * Returns       : u32 CCLK [Hz]
 * Globals       : none
 */
u32 get_cclk_hz(void)
{
    u32 udCSEL = 0;
    ADI_SYSCTRL_VALUES cclk;

    bfrom_SysControl ( SYSCTRL_READ | SYSCTRL_PLLCTL | SYSCTRL_PLLDIV, &cclk, NULL );

    if (cclk.uwPllCtl & BYPASS) { return CLKIN_Hz; }

    udCSEL = ( (cclk.uwPllDiv & CSEL) >> 4);

    return ( get_vco_hz() >> udCSEL );
}


/***************************************
 *
 * Function Name : get_sclk_hz
 * Description   : get current system clock frequency in Hz
 *
 * Parameters    : none
 * Returns       : u32 SCLK [Hz]
 * Globals       : none
 */
u32 get_sclk_hz(void)
{
    ADI_SYSCTRL_VALUES sclk;

    bfrom_SysControl ( SYSCTRL_READ | SYSCTRL_PLLCTL | SYSCTRL_PLLDIV, &sclk, NULL );

    if (sclk.uwPllCtl & BYPASS) { return CLKIN_Hz; }

    return ( get_vco_hz() / ( sclk.uwPllDiv & SSEL ) );
}


#else /* (__USEBFSYSCONTROL__ == 0) */


/***************************************
 *
 * Function Name : full_on
 * Description   : set Voltage Regulator and PLL Registers
 *
 * Parameters    : none
 * Returns       : none
 * Globals       : none
 */
void full_on(void)
{
    u16 uwIMASK_reg = 0;


    IWR_SAVE;

    /*****************************************************************************************
     Description:   Dynamic Power Managment

     Important Notice:
     Depending on increasing/decreasing speed (core clock (CCLK) and/or system clock (SCLK)),
     the order of the registers PLL_CTL, PLL_DIV (and VR_CTL) have to be adapted!
     - Increase speed: 1.  VR_CTL, 2. PLL_DIV, 3. PLL_CTL
     - Decrease speed: 1. PLL_CTL, 2. PLL_DIV, 3.  VR_CTL
     If SCLK is changed and SDRAM is enabled, the value for RDIV in the EBIU_SDRRC register has to be re-calculated
    *****************************************************************************************/

    /**************************
    * PLL Lock Count Register *
    **************************/

    *pPLL_LOCKCNT = PLL_LOCKCNT_VAL;


    /*****************************************************************************
     If the new value written to the PLL_CTL or VR_CTL register is the same as the
     previous value, the PLL wake-up occurs immediately (PLL is already locked),
     but the core and system clock are bypassed for the PLL_LOCKCNT duration. For
     this interval, code executes at the CLKIN rate instead of the expected CCLK
     rate. Software guards against this condition by comparing the current value
     to the new value before writing the new value.
    ******************************************************************************/


    /*****************************************************************************
     Description:   Configure Voltage Regulator Control Register
    ******************************************************************************/

    if ( *pVR_CTL != VR_CTL_VAL )
    {
        uwIMASK_reg = cli();    /* disable interrupts, copy IMASK to uwIMASK_reg */
        *pVR_CTL = VR_CTL_VAL;  /* write new value to VR_CTL */
        idle();                 /* drain pipeline, enter idled state, wait for PLL wakeup */
        sti(uwIMASK_reg);       /* after PLL wakeup occurs, restore interrupts and IMASK */
    }


    /*********************************
    * PLL Divide Register            *
    * Can be configured on the fly   *
    * First configure divider,       *
    * than configure MSEL in PLL_CTL *
    *********************************/

    *pPLL_DIV = PLL_DIV_VAL;


    /*****************************************************************************
     Description:   Configure PLL Control Register
    ******************************************************************************/

    if ( *pPLL_CTL != PLL_CTL_VAL )
    {
        uwIMASK_reg = cli();        /* disable interrupts, copy IMASK to uwIMASK_reg */
        *pPLL_CTL = PLL_CTL_VAL;    /* write new value to PLL_CTL */
        idle();                     /* drain pipeline, enter idled state, wait for PLL wakeup */
        sti(uwIMASK_reg);           /* after PLL wakeup occurs, restore interrupts and IMASK */
    }


    IWR_RESTORE;

    return;
}


/***************************************
 *
 * Function Name : get_vco_hz
 * Description   : get current PLL VCO clock frequency in Hz
 *
 * Parameters    : none
 * Returns       : u32 VCO [Hz]
 * Globals       : none
 */
u32 get_vco_hz(void)
{
    u32 udMSEL = 0;
    u32 udVCO_Hz = 0;

    udMSEL = ( (*pPLL_CTL & MSEL) >> 9 );
    if ( udMSEL == 0 ) { udMSEL = 64; }
    udVCO_Hz = ( udMSEL * CLKIN_Hz );

    return ( udVCO_Hz >> (DF & *pPLL_CTL) );
}


/***************************************
 *
 * Function Name : get_cclk_hz
 * Description   : get current core clock frequency in Hz
 *
 * Parameters    : none
 * Returns       : u32 CCLK [Hz]
 * Globals       : none
 */
u32 get_cclk_hz(void)
{
    u32 udCSEL = 0;

    if (*pPLL_CTL & BYPASS) { return CLKIN_Hz; }

    udCSEL = ( (*pPLL_DIV & CSEL) >> 4);

    return ( get_vco_hz() >> udCSEL );   
}


/***************************************
 *
 * Function Name : get_sclk_hz
 * Description   : get current system clock frequency in Hz
 *
 * Parameters    : none
 * Returns       : u32 SCLK [Hz]
 * Globals       : none
 */
u32 get_sclk_hz(void)
{
    if (*pPLL_CTL & BYPASS) { return CLKIN_Hz; }

    return ( get_vco_hz() / ( *pPLL_DIV & SSEL ) );
}


#endif /* (__USEBFSYSCONTROL__ == 1) */


/***************************************
 *
 * Function Name : verify_clocks
 * Description   : verify desired VCO/CCLK/SCLK clock settings
 *                 if the definitions PLL_CTL_VAL & PLL_DIV_VAL should be verified
 *                 the parameters usMSEL & usSSEL must be 0
 *
 * Parameters    : u8 usMSEL, u8 usCSEL, u8 usSSEL
 * Returns       : ERROR_CODE
 * Globals       : none
 */
ERROR_CODE verify_clocks(u8 usMSEL, u8 usCSEL, u8 usSSEL)
{
    u32 udVCO_Hz  = 0;
    u32 udCCLK_Hz = 0;
    u32 udSCLK_Hz = 0;

    if ( usMSEL == 0 && usSSEL == 0 ) {
        usMSEL = ( (PLL_CTL_VAL & MSEL) >> 9 );
        usCSEL = ( (PLL_CTL_VAL & CSEL) >> 4 );
        usSSEL = ( (PLL_DIV_VAL & SSEL) >> 0 );
    }

    if ( usMSEL == 0 || usSSEL == 0 ) { return ERROR; }
    if ( usCSEL >  4 ) { return ERROR; }
    if ( usSSEL > 64 ) { return ERROR; }

    udVCO_Hz  = ( CLKIN_Hz * usMSEL );
    udCCLK_Hz = ( udVCO_Hz >> usCSEL );
    udSCLK_Hz = ( udVCO_Hz / usSSEL );

    if ( (udVCO_Hz < VCO_MIN_Hz) || (udVCO_Hz > VCO_MAX_Hz) )
        return ERROR;
    else if ( udCCLK_Hz > CCLK_MAX_Hz )
        return ERROR;
    else if ( udSCLK_Hz > SCLK_MAX_Hz )
        return ERROR;
    else return NO_ERR;
}


#ifndef __ADSPBF59x__


/***************************************
 *
 * Function Name : async_mem_en
 * Description   : enable asynchronous memory
 *
 * Parameters    : none
 * Returns       : none
 * Globals       : none
 */
void async_mem_en(void)
{
    /**********************************************
    * Asynchronous Memory Bank Control 0 Register *
    **********************************************/

    *pEBIU_AMBCTL0 = EBIU_AMBCTL0_VAL;


    /**********************************************
    * Asynchronous Memory Bank Control 1 Register *
    **********************************************/

#ifndef __ADSPBF50x__
        *pEBIU_AMBCTL1 = EBIU_AMBCTL1_VAL;
#endif


#if (__ADSPBF54x__ == 1)
    /*****************************************
    * Configure FLASH Mode                   *
    * Choose ONE of the following options    *
    *****************************************/

//    SetToAsyncMode(); /* default mode */
//    SetToFlashMode();
//    SetToPageMode();
//    SetToBurstMode();
#else
    /**********************************************
    * Asynchronous Memory Global Control Register *
    ***********************************************/

    *pEBIU_AMGCTL = EBIU_AMGCTL_VAL;
#endif

    return;
}


#endif // !__ADSPBF59x__


#if (__SDRSDRAM__ == 1)


/***************************************
 *
 * Function Name : sdram_en
 * Description   : enable SDR-SDRAM
 *
 * Parameters    : none
 * Returns       : none
 * Globals       : none
 */
void sdram_en(void)
{
    u16 *pTmp = 0;

    /* already powered up? */
    if (!(*pEBIU_SDSTAT & SDRS)) { return; }


    /*****************************************************************************
     Description:   Configure and enable SDRAM

     1. Ensure the clock to the SDRAM is stable after the power has stabilized
        for the proper amount of time (typically 100 us).
     2. Write to the SDRAM refresh rate control register (EBIU_SDRRC).
     3. Write to the SDRAM memory bank control register (EBIU_SDBCTL).
     4. Write to and SDRAM memory global control register (EBIU_SDGCTL).
     5. Perform SDRAM access.
    ******************************************************************************/

    /********************************
    * SDRAM Control Status Register *
    ********************************/

    /* Is SDC busy performing an access or an Auto-Refresh? */
    while( !(*pEBIU_SDSTAT & SDCI) ) { /* wait */ }

    /* clear SDRAM EAB sticky error status (W1C) */
    *pEBIU_SDSTAT |= SDEASE;


    /****************************************************************************
    * SDRAM Refresh Rate Control Register                                       *
    * RDIV has always to be re-calculated according to the actual system clock  *
    * You can either use the pre-defined value that fits to the PLL settings or *
    * call get_rdiv() to calculate RDIV 'on the fly'                            *
    ****************************************************************************/

    #if defined (EBIU_SDRRC_VAL)
        *pEBIU_SDRRC = EBIU_SDRRC_VAL;
    #else
        *pEBIU_SDRRC = get_rdiv();
    #endif


    /*************************************
    * SDRAM Memory Bank Control Register *
    **************************************/

    *pEBIU_SDBCTL = EBIU_SDBCTL_VAL;


    /***************************************
    * SDRAM Memory Global Control Register *
    ***************************************/

    *pEBIU_SDGCTL = EBIU_SDGCTL_VAL;


    /******************************
    * Finalize SDC initialization *
    ******************************/

    ssync();

    /**************************************************************************
     Once the PSSE bit in the EBIU_SDGCTL register is set to 1, and a transfer
     occurs to enabled SDRAM address space, the SDC initiates the SDRAM
     powerup sequence. The exact sequence is determined by the PSM bit in the
     EBIU_SDGCTL register. The transfer used to trigger the SDRAM powerup
     sequence can be either a read or a write. This transfer occurs when the
     SDRAM powerup sequence has completed. This initial transfer takes
     many cycles to complete since the SDRAM powerup sequence must take place.
    **************************************************************************/

    pTmp = (u16*) 0x0;
    *pTmp = 0xBEEF;


    /* wait until the SDC has powered up */
    while( !(*pEBIU_SDSTAT & SDRS) ) { /* wait */ }

    return;
}


/***************************************
 *
 * Function Name : get_rdiv
 * Description   : Calculate RDIV value for SDRAM Refresh Rate Control Register
 *                 RDIV = ( ( SCLK[MHz] * tREF[ms] ) / NRA ) - ( tRAS + tRP ) [clock cycles]
 *                 RDIV = ( ( SCLK * 10^6 * 1/s * tREF * 10^-3 s ) / NRA ) - ( tRAS + tRP ) [clock cycles]
 *                 SCLK = ( CLKIN * MSEL ) / SSEL = VCO / SSEL
 *                 VCO = _get_vco_hz
 *                 SCLK = _get_sclk_hz
 *                 MSEL = Extracted from PLL_CTL register
 *                 SSEL = Extracted from PLL_DIV register
 *                 tREF = Definition
 *                 NRA  = Definition
 *                 tRAS = Extracted from EBIU_SDGCTL_VAL
 *                 tRP = Extracted from EBIU_SDGCTL_VAL
 *
 * Parameters    : none
 * Returns       : u16 RDIV value
 * Globals       : none
 */
u16 get_rdiv (void)
{
    return (( (get_sclk_hz()/1000) * tREF ) / NRA ) - ( ( (EBIU_SDGCTL_VAL & TRAS) >> 6 ) + ( (EBIU_SDGCTL_VAL & TRP) >> 11 ) );
}


#endif /* (__SDRSDRAM__ == 1) */


#if (__DDRSDRAM__ == 1)


/***************************************
 *
 * Function Name : sdram_en
 * Description   : enable DDR-SDRAM
 *
 * Parameters    : none
 * Returns       : none
 * Globals       : none
 */
void sdram_en(void)
{
    /******************************************************************************************************
     IMPORTANT:
     According to general DDR-SDRAM specification, a frequency of at least 83MHz is necessary !
     Therefore the PLL has to be set before releasing the DDR controller from reset !
     Do not modify reserved bits in this registers!
    ******************************************************************************************************/

    /******************************************************************************************************
     Programming Model:
     Access to the DDR controller registers ONLY can be made after releasing the DDR controller soft reset
     bit in the  reset control register by writing a 1 in bit[0] in the register.
     The user may write to the DDR control registers as long as the controller is not accessing memory
     devices. Otherwise, the controller responds to any writes to its registers after it finishes any
     ongoing memory accesses.
    ******************************************************************************************************/

    /*************************
    * Reset Control Register *
    **************************/

    *pEBIU_RSTCTL |= DDRSRESET;     /* release the DDR controller from reset as per spec */


    /****************************
    * Memory Control 0 Register *
    ****************************/

    *pEBIU_DDRCTL0 = EBIU_DDRCTL0_VAL;


    /****************************
    * Memory Control 1 Register *
    ****************************/

    *pEBIU_DDRCTL1 = EBIU_DDRCTL1_VAL;


    /****************************
    * Memory Control 2 Register *
    ****************************/

    *pEBIU_DDRCTL2 = EBIU_DDRCTL2_VAL;

    return;
}


#endif /* (__DDRSDRAM__ == 1) */



/***************************************
 *
 * Function Name : cplb_mgr_return_handler
 * Description   : CPLB Manager Return Code Handler
 *
 * Parameters    : none
 * Returns       : none
 * Globals       : none
 */
void cplb_mgr_return_handler(unsigned short cplb_mgr_return)
{
    switch (cplb_mgr_return) {
        case CPLB_RELOADED:         INFO(3,"Successfully updated CPLB table."_NL_""); return;
        case CPLB_NO_UNLOCKED:      ERROR(1,"All CPLBs are locked; thus, they cannot be evicted."_NL_"");
                                    ERROR(1,"This indicates that the CPLBs in the configuration table"_NL_"");
                                    ERROR(1,"are badly configured, as this should never occur."_NL_"");
                                    asm("EMUEXCPT; cplb_miss_all_locked: jump cplb_miss_all_locked;");
                                    break;
        case CPLB_NO_ADDR_MATCH:    ERROR(1,"The address being accessed, that triggered the exception,"_NL_"");
                                    ERROR(1,"is not covered by any of the CPLBs in the configuration table."_NL_"");
                                    ERROR(1,"The application is presumably misbehaving."_NL_"");
                                    asm("EMUEXCPT; cplb_miss_without_replacement: jump cplb_miss_without_replacement;");
                                    break;
        case CPLB_PROT_VIOL:        ERROR(1,"The address being accessed, that triggered the exception, is not a"_NL_"");
                                    ERROR(1,"first-write to a clean write-back data page, and so presumably is a"_NL_"");
                                    ERROR(1,"genuine violation of the page�s protection attributes."_NL_"");
                                    ERROR(1,"The application is misbehaving."_NL_"");
                                    asm("EMUEXCPT; cplb_protection_violation: jump cplb_protection_violation;");
                                    break;
        default:                    asm("EMUEXCPT; strange_return_from_cplb_mgr: jump strange_return_from_cplb_mgr;"); break;
    }
}


/***************************************
 *
 * Function Name : ErrorWithNoReturn
 * Description   : Kernel Panic!!!
 *
 * Parameters    : interrupt_info last_int_info
 * Returns       : none
 * Globals       : none
 */
void ErrorWithNoReturn(interrupt_info last_int_info)
{
    asm("EMUEXCPT;");
    idle();
    asm("jump 0;");
}


/***************************************
 *
 * Function Name : HwErrorHandler
 * Description   : Hardware Error Handler
 *
 * Parameters    : none
 * Returns       : none
 * Globals       : none
 */
EX_EXCEPTION_HANDLER(HwErrorHandler)
{
    unsigned char HwErrCause;
    static interrupt_info last_int_info;

    get_interrupt_info(ik_hardware_err, &last_int_info);
    HwErrCause = (unsigned char) (last_int_info.value>>14);

#if defined (__BTC__)
    SequencerStatus = last_int_info.value;
    btc_poll();
#endif

//    ERROR(1,""_RESETSCREEN_"");

    switch (HwErrCause) {
        case 0x02: ERROR(1,"HWERRCAUSE 0x%02X: System MMR Error:"_NL_"",HwErrCause);
                   ERROR(1,"An error can occur if an invalid System MMR location is accessed,"_NL_"");
                   ERROR(1,"if a 32-bit register is accessed with a 16-bit instruction,"_NL_"");
                   ERROR(1,"or if a 16-bit register is accessed with a 32-bit instruction,"_NL_"");
                   ERROR(1,"or if a read-only register is written."_NL_"");
                   break;
        case 0x03: ERROR(1,"HWERRCAUSE 0x%02X: External Memory Addressing Error."_NL_"",HwErrCause);
                   ERROR(1,"An access was attempted to reserved or uninitialized memory."_NL_"");
                   break;
        case 0x12: ERROR(1,"HWERRCAUSE 0x%02X: Performance Monitor Overflow"_NL_"",HwErrCause);
                   break;
        case 0x18: ERROR(1,"HWERRCAUSE 0x%02X: RAISE 5 instruction."_NL_"",HwErrCause);
                   ERROR(1,"Software issued a RAISE 5 instruction to invoke the Hardware Error Interrupt (IVHW)."_NL_"");
                   break;
        default  : ERROR(1,"Unknown Hardware Excause Type '0x%02X'"_NL_"",HwErrCause); break;
    }

    ERROR(1,""_NL_"PC/RETI: 0x%08X "_NL_"",last_int_info.pc);

    ErrorWithNoReturn(last_int_info);
}


/***************************************
 *
 * Function Name : ExceptionHandler
 * Description   : ExceptionHandler
 *
 * Parameters    : none
 * Returns       : none
 * Globals       : none
 */
EX_EXCEPTION_HANDLER(ExceptionHandler)
{
    unsigned short cplb_mgr_return;
    unsigned  char ExCause;
    static interrupt_info last_int_info;

    get_interrupt_info(ik_exception, &last_int_info);
    ExCause = (unsigned char) (last_int_info.value);

#if defined (__BTC__)
    SequencerStatus = last_int_info.value;
    btc_poll();
#endif

//    ERROR(1,""_RESETSCREEN_"");

    switch (ExCause) {
        case EX_DB_SINGLE_STEP: INFO(1,"EXCAUSE 0x%02X: Single step."_NL_"",ExCause);
                                INFO(1,"When the processor is in single step mode, every instruction generates an exception."_NL_"");
                                INFO(1,"Primarily used for debugging."_NL_"");
                                return;
        case EX_DB_EMTRCOVRFLW: INFO(1,"EXCAUSE 0x%02X: Exception caused by a trace buffer full condition."_NL_"",ExCause);
                                INFO(1,"The processor takes this exception when the trace buffer overflows"_NL_"");
                                INFO(1,"(only when enabled by the Trace Unit Control register)."_NL_"");
                                break;
        case EX_SYS_UNDEFINSTR: ERROR(1,"EXCAUSE 0x%02X: Undefined instruction."_NL_"",ExCause);
                                ERROR(1,"May be used to emulate instructions that are not defined for a particular processor implementation."_NL_"");
                                break;
        case EX_SYS_ILLINSTRC:  ERROR(1,"EXCAUSE 0x%02X: Illegal instruction combination."_NL_"",ExCause);
                                ERROR(1,"See section for multi-issue rules in the Blackfin Processor Programming Reference."_NL_"");
                                break;
        case EX_SYS_DCPLBPROT:  cplb_mgr_return = cplb_mgr(CPLB_EVT_DCPLB_WRITE,__cplb_ctrl);
                                cplb_mgr_return_handler(cplb_mgr_return);
                                return;
/*
                                ERROR(1,"EXCAUSE 0x%02X: Data access CPLB protection violation."_NL_"",ExCause);
                                ERROR(1,"Attempted read or write to Supervisor resource, or illegal data memory access."_NL_"");
                                ERROR(1,"Supervisor resources are registers and instructions that are reserved for Supervisor use:"_NL_"");
                                ERROR(1,"Supervisor only registers, all MMRs, and Supervisor only instructions."_NL_"");
                                ERROR(1,"(A simultaneous, dual access to two MMRs using the data address generators"_NL_"");
                                ERROR(1,"generates this type of exception.)"_NL_"");
                                ERROR(1,"In addition, this entry is used to signal a protection violation,"_NL_"");
                                ERROR(1,"caused by disallowed memory access, and it is defined by "_NL_"");
                                ERROR(1,"the Memory Management Unit (MMU) cacheability protection lookaside buffer (CPLB)."_NL_"");
                                ERROR(1,"DATA_FAULT_ADDR: 0x%08X"_NL_"",last_int_info.addr);
                                ERROR(1,"DATA_FAULT_STATUS: 0x%08X"_NL_"",last_int_info.status);
                                break;
*/
        case EX_SYS_DALIGN:     ERROR(1,"EXCAUSE 0x%02X: Data access misaligned address violation."_NL_"",ExCause);
                                ERROR(1,"Attempted misaligned data memory or data cache access."_NL_"");
                                ERROR(1,"DATA_FAULT_ADDR: 0x%08X"_NL_"",last_int_info.addr);
                                ERROR(1,"DATA_FAULT_STATUS: 0x%08X"_NL_"",last_int_info.status);
                                break;
        case EX_SYS_UNRECEVT:   ERROR(1,"EXCAUSE 0x%02X: Unrecoverable event."_NL_"",ExCause);
                                ERROR(1,"For example, an exception generated while processing a previous exception."_NL_"");
                                break;
        case EX_SYS_DCPLBMISS:  cplb_mgr_return = cplb_mgr(CPLB_EVT_DCPLB_MISS,__cplb_ctrl);
                                cplb_mgr_return_handler(cplb_mgr_return);
                                return;
/*
                                ERROR(1,"EXCAUSE 0x%02X: Data access CPLB miss."_NL_"");
                                ERROR(1,"Used by the MMU to signal a CPLB miss on a data access."_NL_"",ExCause);
                                ERROR(1,"DATA_FAULT_ADDR: 0x%08X"_NL_"",last_int_info.addr);
                                ERROR(1,"DATA_FAULT_STATUS: 0x%08X"_NL_"",last_int_info.status);
                                break;
*/
        case EX_SYS_DCPLBMHIT:  ERROR(1,"EXCAUSE 0x%02X: Data access multiple CPLB hits."_NL_"",ExCause);
                                ERROR(1,"More than one CPLB entry matches data fetch address."_NL_"");
                                ERROR(1,"DATA_FAULT_ADDR: 0x%08X"_NL_"",last_int_info.addr);
                                ERROR(1,"DATA_FAULT_STATUS: 0x%08X"_NL_"",last_int_info.status);
                                break;
        case EX_SYS_EMWATCHPT:  ERROR(1,"EXCAUSE 0x%02X: Exception caused by an emulation watchpoint match."_NL_"",ExCause);
                                ERROR(1,"There is a watchpoint match, and one of the EMUSW bits"_NL_"");
                                ERROR(1,"in the Watchpoint Instruction Address Control register (WPIACTL) is set."_NL_"");
                                break;
        case EX_SYS_CACCESSEX:  ERROR(1,"EXCAUSE 0x%02X: Instruction fetch access exception"_NL_"",ExCause);
                                ERROR(1,"CODE_FAULT_ADDR: 0x%08X"_NL_"",last_int_info.addr);
                                ERROR(1,"CODE_FAULT_STATUS: 0x%08X"_NL_"",last_int_info.status);
                                break;
        case EX_SYS_CALIGN:     ERROR(1,"EXCAUSE 0x%02X: Instruction fetch misaligned address violation."_NL_"",ExCause);
                                ERROR(1,"Attempted misaligned instruction cache fetch."_NL_"");
                                ERROR(1,"(Note this exception can never be generated from PC-relative branches, only from indirect branches.)"_NL_"");
                                ERROR(1,"CODE_FAULT_ADDR: 0x%08X"_NL_"",last_int_info.addr);
                                ERROR(1,"CODE_FAULT_STATUS: 0x%08X"_NL_"",last_int_info.status);
                                break;
        case EX_SYS_CCPLBPROT:  ERROR(1,"EXCAUSE 0x%02X: Instruction fetch CPLB protection violation."_NL_"",ExCause);
                                ERROR(1,"Illegal instruction fetch access (memory protection violation)."_NL_"");
                                ERROR(1,"CODE_FAULT_ADDR: 0x%08X"_NL_"",last_int_info.addr);
                                ERROR(1,"CODE_FAULT_STATUS: 0x%08X"_NL_"",last_int_info.status);
                                break;
        case EX_SYS_CCPLBMISS:  cplb_mgr_return = cplb_mgr(CPLB_EVT_ICPLB_MISS,__cplb_ctrl);
                                cplb_mgr_return_handler(cplb_mgr_return);
                                return;
/*
                                ERROR(1,"EXCAUSE 0x%02X: Instruction fetch CPLB miss."_NL_"",ExCause);
                                ERROR(1,"CPLB miss on an instruction fetch."_NL_"");
                                ERROR(1,"CODE_FAULT_ADDR: 0x%08X"_NL_"",last_int_info.addr);
                                ERROR(1,"CODE_FAULT_STATUS: 0x%08X"_NL_"",last_int_info.status);
                                break;
*/
        case EX_SYS_CCPLBMHIT:  ERROR(1,"EXCAUSE 0x%02X: Instruction fetch multiple CPLB hits."_NL_"",ExCause);
                                ERROR(1,"More than one CPLB entry matches instruction fetch address."_NL_"");
                                ERROR(1,"CODE_FAULT_ADDR: 0x%08X"_NL_"",last_int_info.addr);
                                ERROR(1,"CODE_FAULT_STATUS: 0x%08X"_NL_"",last_int_info.status);
                                break;
        case EX_SYS_ILLUSESUP:  ERROR(1,"EXCAUSE 0x%02X: Illegal use of supervisor resource."_NL_"",ExCause);
                                ERROR(1,"Attempted to use a Supervisor register or instruction from User mode."_NL_"");
                                ERROR(1,"Supervisor resources are registers and instructions that are reserved for Supervisor use:"_NL_"");
                                ERROR(1,"Supervisor only registers, all MMRs, and Supervisor only instructions."_NL_"");
                                break;
        default:                ERROR(1,"Unknown Excause Type '0x%02X'"_NL_"",ExCause);
                                break;
    }

    DEBUG(1,""_NL_"");
    ERROR(1,"PC/RETX: 0x%08X "_NL_"",last_int_info.pc);

    ErrorWithNoReturn(last_int_info);
}


/***************************************
 *
 * Function Name : CoreTimerInterruptHandler
 * Description   : Core Timer Interrupts Handler
 *
 * Parameters    : none
 * Returns       : none
 * Globals       : none
 */
EX_INTERRUPT_HANDLER(CoreTimerHandler)
{
    static unsigned char count;
    count = circindex(count, 1, 4);
    switch(count) {
        case 0: DEBUG(2,"|");  break;
        case 1: DEBUG(2,"/");  break;
        case 2: DEBUG(2,"-");  break;
        case 3: DEBUG(2,"\\"); break;
        default: return;
    }
}


/***************************************
 *
 * Function Name : CoreTimer
 * Description   : Core Timer Setup
 *
 * Parameters    : count
 * Returns       : none
 * Globals       : none
 */
void CoreTimer(unsigned long count)
{
    register_handler_ex(ik_timer,CoreTimerHandler,EX_INT_ENABLE);
    *pIMASK |= EVT_IVTMR;

    *pTCOUNT  = count;
    *pTPERIOD = count; // When auto-reload is enabled, the TCOUNT register is reloaded with the value of TPERIOD
    *pTSCALE  = 0;
    csync();
    *pTCNTL = (TINT|TAUTORLD|TMPWR|TMREN);
    csync();
}


/***************************************
 *
 * Function Name : CoreTimer2
 * Description   : Core Timer Setup
 *
 * Parameters    : value and *command ["s","ms","us","ns"]
 * Returns       : number of ticks
 * Globals       : none
 */
long CoreTimer2(unsigned long PosVal, const char *command)
{
    volatile unsigned long RetVal = 0;
    volatile unsigned long ticks = 0;

         if (!strncmp("ns",command,2)) { ticks=(PosVal*1); }
    else if (!strncmp("us",command,2)) { ticks=(PosVal*1000); }
    else if (!strncmp("ms",command,2)) { ticks=(PosVal*1000000); }
    else if (!strncmp( "s",command,1)) { ticks=(PosVal*1000000000); }
    else { return -1; }

    RetVal = (1000000000/get_cclk_hz());
    RetVal = ticks;

    CoreTimer(ticks);

    return RetVal;
}


/***************************************
 *
 * Function Name : CoreTimerDisable
 * Description   : Disable Core Timer
 *
 * Parameters    : none
 * Returns       : none
 * Globals       : none
 */
void CoreTimerDisable(void)
{
    *pTCNTL &= ~(TMPWR|TMREN);
    *pIMASK &= ~EVT_IVTMR;
}


/****************************************************************************
 EOF
*****************************************************************************/
