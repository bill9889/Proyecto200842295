#include <blackfin.h>
#include <ccblkfn.h>

#include <stdio.h>
#include <stdlib.h>
#include <stdarg.h>
#include <string.h>

#include <sys/exception.h>

#include "init_platform.h"
#include "BfDebugger.h"

#if (__DEBUG_FILE__ == 1)
    FILE *DEBUG_STREAM;
#endif

#if (__UART_IO_DEVICE__ == 1)
    FILE *pUartIOFile;
#endif


#if (__UART_IO_DEVICE__ == 1)

#if (__PRE_REGISTERING_DEVICE__ == 1)


int main(void)
{
    register_handler_ex(ik_hardware_err,HwErrorHandler,EX_INT_ENABLE);
    register_handler_ex(ik_exception,ExceptionHandler,EX_INT_ENABLE);

    full_on();

    // As there is no fopen/fclose operation required,
    // the DEBUG_OPEN()/DEBUG_CLOSE macros are used to setup/stop the UART
    DEBUG_OPEN();

    WelcomeMessage2(stdout);

    while(1) { idle(); }

//    DEBUG_CLOSE();

//    return 0;
}


#else /* __PRE_REGISTERING_DEVICE__ == 0 */


int main(void)
{
    register_handler_ex(ik_hardware_err,HwErrorHandler,EX_INT_ENABLE);
    register_handler_ex(ik_exception,ExceptionHandler,EX_INT_ENABLE);

    full_on();

    // Opening debug mode with DEBUG_OPEN() not required.
    // This macro is called in the uart_console_open(...) function when registering the file pointer

    int PrimDevId = get_default_io_device();
    int SecDevId  = add_devtab_entry(&UartIODevice);
    set_default_io_device(SecDevId);
    int DevId = get_default_io_device();

    pUartIOFile = fopen("uart","w"); /* actually, "uart" has no meaning at all, its just a dummy name */
    if (setvbuf(pUartIOFile,strbuf,_IOLBF,sizeof(strbuf)) == -1) { return -1; }
    set_default_io_device(PrimDevId); /* can be  restored immediately after fopen(). Once the file's open, it "knows" which device it was created on, and all accesses to that stream are routed to the appropriate device */

    WelcomeMessage2(pUartIOFile);

    // This is to show that the default stdout is still working
    WelcomeMessage2(stdout);

    // The DEBUG_CLOSE() macro is called in the uart_console_close(...) function when closing the file pointer
    fclose(pUartIOFile);

//    while(1) { idle(); }

    DEBUG_CLOSE();

    return 0;
}


#endif /* __PRE_REGISTERING_DEVICE__ == 1 */


#else  /* __UART_IO_DEVICE__ == 0 */


int main(void)
{
    register_handler_ex(ik_hardware_err,HwErrorHandler,EX_INT_ENABLE);
    register_handler_ex(ik_exception,ExceptionHandler,EX_INT_ENABLE);

    full_on();

#if ( ((__DEBUG_UART__ == 1) || (__DEBUG_UART_DMA__ == 1)) && (AUTOBAUD == 1) )
    unsigned long UartBitrate = DEBUG_OPEN();
#else
    DEBUG_OPEN();
#endif

    WelcomeMessage();

    DEBUG(1,"This is a debug message"_NL_"");
    INFO(1,"This is a info message"_NL_"");
    MSG(1,"This is a standard message"_NL_"");
    ERROR(1,"This is an error message"_NL_"");
    DEBUG(1,""_MAGENTATEXT_"This "_YELLOWTEXT_"is "_REDTEXT_"a "_BLUETEXT_"multi-"_YELLOWTEXT_"colored "_GREENTEXT_"message"_NL_"");

//    DEBUG(1,""_PROMPT_"");
    CoreTimer2(250,"ms");

    while(1) { idle(); }

//    DEBUG_CLOSE();

//    return 0;
}


#endif /* __UART_IO_DEVICE__ == 1 */


/******************************** End of File *********************************/
