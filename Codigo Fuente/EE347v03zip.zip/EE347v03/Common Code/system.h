/*****************************************************************************
**                                                                          **
**  Name:   SYSTEM                                                          **
**                                                                          **
******************************************************************************

(C) Copyright 2009 - Analog Devices, Inc.  All rights reserved.

File Name:      system.h

Date Modified:  03/29/2012

Processor:      Blackfin

Software:       VisualDSP++ 5.0

Purpose:        

******************************************************************************/


#ifndef _SYSTEM_H_
#define _SYSTEM_H_

/*******************************************************************************
*
*  Include File Area
*
*******************************************************************************/

/*******************************************************************************
*
*  Exported Constants Area
*
*******************************************************************************/

/*******************************************************************************
*
*  Exported Definition Area
*
*******************************************************************************/
 
/*******************************************************************************
*
*  Exported Types Area
*
*******************************************************************************/

/*******************************************************************************
*
*  Exported Function Prototypes Area
*
*******************************************************************************/

void full_on(void);
unsigned long get_vco_hz(void);
unsigned long get_cclk_hz(void);
unsigned long get_sclk_hz(void);
void async_mem_en(void);
void sdram_en(void);
unsigned short get_rdiv (void);
ERROR_CODE verify_clocks(unsigned char, unsigned char, unsigned char);

EX_EXCEPTION_HANDLER(HwErrorHandler);
EX_EXCEPTION_HANDLER(ExceptionHandler);

void CoreTimer(unsigned long count);
long CoreTimer2(unsigned long PosVal, const char *command);
void CoreTimerDisable(void);

#endif /* _SYSTEM_H_ */
/******************************** End of File *********************************/
