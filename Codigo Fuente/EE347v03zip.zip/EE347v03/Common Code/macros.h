/*****************************************************************************
 macros
******************************************************************************/

/*************************************************
* Save/Restore System Interrupt Wakeup Registers *
* Assumption: P5 = SYS_MMR_BASE (0xFFC0 0000)    *
*************************************************/

#if defined (__ADSPBF537_FAMILY__) || defined (__ADSPBF533_FAMILY__)
    #define  SIC_IWR0 SIC_IWR
    #define pSIC_IWR0 ((volatile unsigned long *)SIC_IWR)
#endif
#if defined (__ADSPBF561__)
    #define  SIC_IWR0 SICA_IWR0
    #define  SIC_IWR1 SICA_IWR1
    #define pSIC_IWR0 ((volatile unsigned long *)SICA_IWR0)
    #define pSIC_IWR1 ((volatile unsigned long *)SICA_IWR1)
#endif


#if defined (__ADSPBF50x__) || defined (__ADSPBF51x__) || defined (__ADSPBF52x__)
    #define IWR_SAVE\
        *pSIC_IWR1 = IWR1_DISABLE_ALL;\
        *pSIC_IWR0 = IRQ_PLL_WAKEUP
#elif defined  (__ADSPBF538_FAMILY__) || defined (__ADSPBF561__)
    #define IWR_SAVE\
        *pSIC_IWR1 = IWR_DISABLE_ALL;\
        *pSIC_IWR0 = IRQ_PLL_WAKEUP
#elif defined (__ADSPBF54x__)
    #define IWR_SAVE\
        *pSIC_IWR2 = IWR_DISABLE_ALL;\
        *pSIC_IWR1 = IWR_DISABLE_ALL;\
        *pSIC_IWR0 = IRQ_PLL_WAKEUP
#else // (__ADSPBF537_FAMILY__) || (__ADSPBF533_FAMILY__) || (__ADSPBF59x__)
    #define IWR_SAVE\
        *pSIC_IWR0 = IRQ_PLL_WAKEUP
#endif


#if defined (__ADSPBF50x__) || defined (__ADSPBF51x__) || defined (__ADSPBF52x__)
    #define IWR_RESTORE\
        *pSIC_IWR0 = IWR0_ENABLE_ALL;\
        *pSIC_IWR1 = IWR1_ENABLE_ALL
#elif defined  (__ADSPBF538_FAMILY__) || defined (__ADSPBF561__)
    #define IWR_RESTORE\
        *pSIC_IWR0 = IWR_ENABLE_ALL;\
        *pSIC_IWR1 = IWR_ENABLE_ALL
#elif defined (__ADSPBF54x__)
    #define IWR_RESTORE\
        *pSIC_IWR0 = IWR_ENABLE_ALL;\
        *pSIC_IWR1 = IWR_ENABLE_ALL;\
        *pSIC_IWR2 = IWR_ENABLE_ALL
#else // (__ADSPBF537_FAMILY__) || (__ADSPBF533_FAMILY__) || (__ADSPBF59x__)
    #define IWR_RESTORE\
        *pSIC_IWR0 = IWR_ENABLE_ALL
#endif


/****************************************************************************
 EOF
*****************************************************************************/
