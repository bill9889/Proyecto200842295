/*******************************************************************************
*
*  Exported Constants/Definition Area
*
*******************************************************************************/

#if (__ADSPBF50x__ == 1) || (__ADSPBF51x__ == 1) || (__ADSPBF526_FAMILY__ == 1) || ( (__ADSPBF527_FAMILY__ == 1) && (__SILICON_REVISION__ >= 0x002) ) || ( (__ADSPBF54x__ == 1) && __SILICON_REVISION__ >= 0x001 )
    #define __USEBFSYSCONTROL__ 1
#endif

#if (__ADSPBF533_FAMILY__ == 1) || (__ADSPBF537_FAMILY__ == 1) || (__ADSPBF538_FAMILY__ == 1) || (__ADSPBF561__ == 1)
    #define __OLD_ROM_REV__ 1
#endif


#if (__ADSPBF50x__ == 1) || (__ADSPBF51x__ == 1) || (__ADSPBF526_FAMILY__ == 1)
    #define __EXTVOLTAGE__ 1
#endif


#if ( defined (__ADSPBF527_FAMILY__) && __SILICON_REVISION__ <= 0x001 ) || ( defined (__ADSPBF54x__) && __SILICON_REVISION__ == 0x000 )
    #define __WORKAROUND_05000392__ 1
#endif

#if defined (__ADSPBF526_FAMILY__) && (__SILICON_REVISION__ == 0x000)
    #define __WORKAROUND_05000432__ 1
#endif

#if ( defined (__ADSPBF51x__) && __SILICON_REVISION__ == 0x000 ) || ( defined (__ADSPBF526_FAMILY__) && __SILICON_REVISION__ == 0x000 ) || ( defined (__ADSPBF527_FAMILY__) && __SILICON_REVISION__ <= 0x002 )
    #define __WORKAROUND_05000440__ 1
#endif

#if ( defined (__ADSPBF51x__) && __SILICON_REVISION__ == 0x000 ) || ( defined (__ADSPBF526_FAMILY__) && __SILICON_REVISION__ <= 0x001 )
    #define __WORKAROUND_05000353__ 1
#endif


/*******************************************************************************
*
*  Exported Types Area
*
*******************************************************************************/

typedef enum
{
    NO_ERR,
    ERROR,
} ERROR_CODE;

typedef enum
{
    YES,
    NO,
} TRUE;


/*******************************************************************************
*
*  Include File Area
*
*******************************************************************************/

#include <blackfin.h>

#if (__ADSPBF54x__ == 0)
    #include "nBlackfin.h"
#endif

#if (__ADSPBF50x__ == 1)
    #include "ezkitBF506f_initcode.h"
#elif (__ADSPBF51x__ == 1)
    #include "ezboardBF518f_initcode.h"
#elif (__ADSPBF526_FAMILY__ == 1)
    #include "ezboardBF526_initcode.h"
#elif (__ADSPBF527_FAMILY__ == 1)
    #include "ezkitBF527_initcode.h"
#elif (__ADSPBF533_FAMILY__ == 1)
    #include "ezkitBF533_initcode.h"
#elif (__ADSPBF537_FAMILY__ == 1)
    #include "ezkitBF537_initcode.h"
#elif (__ADSPBF538_FAMILY__ == 1)
    #include "ezkitBF538f_initcode.h"
#elif (__ADSPBF561__ == 1)
    #include "ezkitBF561_initcode.h"
#elif (__ADSPBF54x__ == 1)
    #include "ezkitBF548_initcode.h"
#elif (__ADSPBF59x__ == 1)
    #include "ezkitBF592_initcode.h"
#else
    #error target not supported
#endif


#include <ccblkfn.h>
#include <sysreg.h>
#include <sys/exception.h>
#if (__OLD_ROM_REV__ == 1)
    #include "services_types.h"
#else
    #include <bfrom.h>
#endif
#include "system.h"
#include "ivg.h"
#include "macros.h"

/*****************************************************************************
 EOF
******************************************************************************/
