// IVG7
#define IVG_UART_STATUS (ik_ivg7)
// IVG8
#define IVG_DMA_STATUS  (ik_ivg8)
// IVG9
// IVG10
// IVG11
// IVG12
// IVG13
#define IVG_WDOG        (ik_ivg13)
// IVG14
#define IVG_UART_DATA   (ik_ivg14)
// IVG15
#define IVG_SU          (ik_ivg15)
