*****************************************************************************************


This ZIP File is associated with Rev 1 of the Application Note


    Formatted Print to a UART Terminal with Blackfin� Processors (EE-347)  


that can be found at http://www.analog.com/ee-notes.


Date Created:   June 21st, 2012


*****************************************************************************************

CONTENTS

I.   FUNCTIONAL DESCRIPTION
II.  OPERATION DESCRIPTION
III. HARDWARE SETTINGS
IV.  FILES CONTAINED IN THIS DIRECTORY

___________________________________________________________

I.   FUNCTIONAL DESCRIPTION

The directory contains examples to redirect the printf function
to a different output device. In this case, the Blackfin processor's
UART peripheral (or a file on you PC).
The projects are available for all Blackfin processor evaluation platforms.

All ADSP-BF5xx code examples have been developed and tested using:
- The Blackfin EZ-KIT evaluation boards 
- VisualDSP++ 5.0 Update 10

All ADSP-BF6xx code examples have been developed and tested using:
- The Blackfin EZ-KIT evaluation boards 
- CrossCore Embedded Studio 1.0.1

___________________________________________________________


II.  OPERATION DESCRIPTION

Please read EE-347 carefully together with the comments in the source files.
The required settings to switch between the different supported modes are
done in BfDebugger.h. The definitions are:

__UART_IO_DEVICE__
__PRE_REGISTERING_DEVICE__

__DEBUG_UART_DMA__
__DEBUG_UART__
__DEBUG_FILE__
__DEBUG_VDSP__

__VERBOSITY__

Anything else must not be changed at all.

___________________________________________________________

III. HARDWARE SETTINGS

The UART settings are (by default)

These can be changed the specific header file (ADSP-BF5xx-UART.h):
Uart Number is set accroding to the connector available on the specific evaluation board
Bitrate: 115200
Autobaud detection is supported as well

Data bits: 8
Stop bits: 1
No parity
No flow control
-> This settings can be modified with the definition UART_LCR_VAL


Switch/Jumper settings: Default

___________________________________________________________

IV.  FILES CONTAINED IN THIS DIRECTORY

[BfUart]
|
|-> README.txt
|
|- [Common Code]
   |
   |-> BfDebugger.c
   |-> BfDebugger.h
   |-> devtab.c
   |-> init_platform.h
   |-> main.c
   |-> nBlackfin.h
   |-> NOR_FLASH.c
   |-> NOR_FLASH.h
   |-> primiolib.c
   |-> system.c
   |-> system.h
   |-> TWI.c
   |-> TWI.h
   |-> VR_DIGIPOT.c
   |-> VR_DIGIPOT.h
|
|- [ADSP-BF50x-UART]
   |
   |-> ADSP-BF50x-UART.c
   |-> ADSP-BF50x-UART.dpj
   |-> ADSP-BF50x-UART.h
   |-> ADSP-BF50x-UART.ldf
   |-> ADSP-BF50x-UART_basiccrt.s
   |-> ADSP-BF50x-UART_heaptab.c
   |-> ezkitBF506f_initcode.h
|
|- [ADSP-BF51x-UART]
   |
   |-> ADSP-BF51x-UART.c
   |-> ADSP-BF51x-UART.dpj
   |-> ADSP-BF51x-UART.h
   |-> ADSP-BF51x-UART.ldf
   |-> ADSP-BF51x-UART_basiccrt.s
   |-> ADSP-BF51x-UART_heaptab.c
   |-> ezboardBF518f_initcode.h
|
|- [ADSP-BF526_FAMILY-UART]
   |
   |-> ADSP-BF52x-UART.c
   |-> ADSP-BF52x-UART.dpj
   |-> ADSP-BF52x-UART.h
   |-> ADSP-BF526-UART.ldf
   |-> ADSP-BF526-UART_basiccrt.s
   |-> ADSP-BF526-UART_heaptab.c
   |-> ezboardBF526_initcode.h
|
|- [ADSP-BF527_FAMILY-UART]
   |
   |-> ADSP-BF52x-UART.c
   |-> ADSP-BF527-UART.dpj
   |-> ADSP-BF52x-UART.h
   |-> ADSP-BF527-UART.ldf
   |-> ADSP-BF527-UART_basiccrt.s
   |-> ADSP-BF527-UART_heaptab.c
   |-> ezkitBF527_initcode.h
|
|- [ADSP-BF533_FAMILY-UART]
   |
   |-> ADSP-BF532-UART.c
   |-> ADSP-BF533_FAMILY-UART.dpj
   |-> ADSP-BF532-UART.h
   |-> ADSP-BF533_FAMILY-UART.ldf
   |-> ADSP-BF533_FAMILY-UART_basiccrt.s
   |-> ADSP-BF533_FAMILY-UART_heaptab.c
   |-> ezkitBF533_initcode.h
|
|- [ADSP-BF537_FAMILY-UART]
   |
   |-> ADSP-BF534-UART.c
   |-> ADSP-BF537_FAMILY-UART.dpj
   |-> ADSP-BF534-UART.h
   |-> ADSP-BF537_FAMILY-UART.ldf
   |-> ADSP-BF537_FAMILY-UART_basiccrt.s
   |-> ADSP-BF537_FAMILY-UART_heaptab.c
   |-> ezkitBF533_initcode.h
|
|- [ADSP-BF538_FAMILY-UART]
   |
   |-> ADSP-BF538-UART.c
   |-> ADSP-BF538_FAMILY-UART.dpj
   |-> ADSP-BF538-UART.h
   |-> ADSP-BF538_FAMILY-UART.ldf
   |-> ADSP-BF538_FAMILY-UART_basiccrt.s
   |-> ADSP-BF538_FAMILY-UART_heaptab.c
   |-> ezkitBF538f_initcode.h
|
|- [ADSP-BF54x-UART]
   |
   |-> ADSP-BF54x-UART.c
   |-> ADSP-BF54x-UART.dpj
   |-> ADSP-BF54x-UART.h
   |-> ADSP-BF54x-UART.ldf
   |-> ADSP-BF54x-UART_basiccrt.s
   |-> ADSP-BF54x-UART_heaptab.c
   |-> ezkitBF548_initcode.h
|
|- [ADSP-BF561-UART]
   |
   |-> ADSP-BF561-UART.c
   |-> ADSP-BF561-UART.dpj
   |-> ADSP-BF561-UART.h
   |-> ADSP-BF561-UART.ldf
   |-> ADSP-BF561-UART_basiccrt.s
   |-> ADSP-BF561-UART_heaptab.c
   |-> ezkitBF561_initcode.h
|
|- [ADSP-BF59x-UART]
   |
   |-> ADSP-BF59x-UART.c
   |-> ADSP-BF59x-UART.dpj
   |-> ADSP-BF59x-UART.h
   |-> ADSP-BF59x-UART.ldf
   |-> ADSP-BF59x-UART_basiccrt.s
   |-> ADSP-BF59x-UART_heaptab.c
   |-> ezkitBF592_initcode.h
|
|- [ADSP-BF60x-UART]
   |
   |- [.settings]
   |-> [...]
   |- [src]
   |-> [...]
   |- [system]
   |-> [...]
|- [ADSP-BF60x-UART_Core1]
   |
   |- [.settings]
   |-> [...]
   |- [src]
   |-> [...]
   |- [system]
   |-> [...]