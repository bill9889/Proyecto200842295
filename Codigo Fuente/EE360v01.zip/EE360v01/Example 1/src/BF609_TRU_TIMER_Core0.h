/*
 *
 *   (C) Copyright 2013 - Analog Devices, Inc.  All rights reserved.
 *
 *    FILE:     BF609_TRU_TIMER_Core0.h
 *
 *    PURPOSE:  Includes the macros, variables and function declarations for BF609_TRU_TIMER_Core0.C
 *
 */


#ifndef __BF609_TRU_TIMER_CORE0_H__
#define __BF609_TRU_TIMER_CORE0_H__

/* Add your custom header content here */

// Global Macros
#define TIMEOUT_PERIOD	0x00002710

// Function Prototypes
int master_config(void);
int gpio_config(void);
int slave_config(void);
int timer_config(void);
int dma_config(void);
int tru_config(void);

int gcnt = 0 ;




#endif /* __BF609_TRU_TIMER_CORE0_H__ */
