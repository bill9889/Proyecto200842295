/*
 * (C) Copyright 2012 - Analog Devices, Inc.  All rights reserved.
 * This software is proprietary and confidential.  By using this software
 * you agree to the terms of the associated Analog Devices License Agreement.
 *
 * Project Name:  	TRU based timer
 *
 * Hardware:		ADSP-BF609 EZ-Board
 *
 * Description:	This file initializes the CGU on the ADSP-BF609 EZ-Board.
 */

/*****************************************************************************
 * BF609_TRU_TIMER_Core0.c
 *****************************************************************************/

#include <ccblkfn.h>
#include "adi_initialize.h"
#include "BF609_TRU_TIMER_Core0.h"
#include <stdio.h>
#include <services/gpio/adi_gpio.h>
#include  "cgu_init.h"

int main(void)
{

    adi_initComponents(); /* auto-generated code */

	*pREG_PORTB_FER = 0u;   /* bug? should reset to 0 */

	/* CCLK=500Mhz, 125Mhz SCLK0 CLK  */
	CGU_Init(20, 1, 2);

	printf("TRU Sample Example\n");

	/* Configure Master */
	master_config();

	/* Configure Slave */
	slave_config();

	/* Configure TRU */
	tru_config();

	while(1)
	{
		asm("NOP;");
	}

	return 0;
}


int master_config()
{
	/* Configure GPIO  Master*/
	gpio_config();

	return 0;
}

int slave_config()
{
	/* Configure timer slave */
	timer_config();

	/* Configure dma slave */
	dma_config();

	return 0;
}

int timer_config(void)
{
	// Enable PE14 in peripheral mode for Timer0 TMR0 PWM Wave
	*pREG_PORTE_FER |= 1<< BITP_PORT_FER_PX14;
	*pREG_PORTE_FER_SET = 1<< BITP_PORT_FER_SET_PX14;
	*pREG_PORTE_MUX |=  2 << BITP_PORT_MUX_MUX14;

	/* active state, auto reload, generate no interrupt */
	*pREG_TIMER0_TMR0_CFG = ENUM_TIMER_TMR_CFG_EMU_CNT|ENUM_TIMER_TMR_CFG_CLKSEL_SCLK| ENUM_TIMER_TMR_CFG_TRIGSTART|ENUM_TIMER_TMR_CFG_PWMCONT_MODE ;
	*pREG_TIMER0_TMR0_PER = TIMEOUT_PERIOD;
	*pREG_TIMER0_TMR0_WID = TIMEOUT_PERIOD/2;
	*pREG_TIMER0_TMR0_DLY = 0;
	*pREG_TIMER0_TRG_IE |= BITM_TIMER_TRG_IE_TMR00;
	return 0;
}


int dma_config(void)
{
	int stop_timer01 = 0x01;

	// Source DMA Channel
	*pREG_DMA25_ADDRSTART = &stop_timer01;
	/* configure source registers */
	*pREG_DMA25_CFG  = (ENUM_DMA_CFG_READ | ENUM_DMA_CFG_MSIZE02 | ENUM_DMA_CFG_STOP | ENUM_DMA_CFG_ADDR1D| ENUM_DMA_CFG_TRGWAIT);
	*pREG_DMA25_XCNT = 0x01;
	*pREG_DMA25_XMOD = 0;

	// Destination DMA Channel (DST: TIMER00 STOP Configuration Register)
	*pREG_DMA26_ADDRSTART = REG_TIMER0_RUN_CLR;
	/* configure destination registers */
	*pREG_DMA26_CFG  = (ENUM_DMA_CFG_WRITE | ENUM_DMA_CFG_MSIZE02 | ENUM_DMA_CFG_STOP | ENUM_DMA_CFG_ADDR1D|ENUM_DMA_CFG_TRGWAIT);
	*pREG_DMA26_XCNT = 0x01;
	*pREG_DMA26_XMOD = 0;

	// Enable DMA Channels
	*pREG_DMA25_CFG |= ENUM_DMA_CFG_EN ;
	*pREG_DMA26_CFG |= ENUM_DMA_CFG_EN ;

	return 0;
}


int gpio_config(void)
{
	// Configure PB12/PINT0 as master trigger to start the timer
	*pREG_PORTB_FER |= 0 << BITP_PORT_FER_PX12;
	*pREG_PORTB_DIR |= 0 << BITP_PORT_FER_PX12;
	*pREG_PORTB_INEN |= 1 << BITP_PORT_INEN_PX12;
	*pREG_PORTB_DATA_CLR |= 1 << BITP_PORT_DATA_CLR_PX12;

	//PINT0 as master trigger to start the timer
	*pREG_PINT0_ASSIGN |= BITM_PINT_ASSIGN_B0MAP;
	*pREG_PINT0_MSK_SET |= 1 << BITP_PINT_MSK_SET_PIQ12;
	*pREG_PINT0_EDGE_SET |= 1 << BITP_PINT_EDGE_SET_PIQ12;

	// PINT1 as master trigger to start the MDMA(TO stop the timer)
	*pREG_PINT1_ASSIGN |= BITM_PINT_ASSIGN_B0MAP;
	*pREG_PINT1_MSK_SET |= 1 << BITP_PINT_MSK_SET_PIQ28;
	*pREG_PINT1_EDGE_SET |= 1 << BITP_PINT_EDGE_SET_PIQ28;
	*pREG_PINT1_INV_SET |= 1 << BITP_PINT_INV_SET_PIQ28;

	return 0;
}

int tru_config(void)
{
	/* Enable the TRU */
	*pREG_TRU0_GCTL |= 0x1;

	/* Configure Timer0 slave to receive trigger from PINT0 master */
	*pREG_TRU0_SSR2 = TRGM_PINT0_BLOCK ;

	/* Configure MDMA Channel 25/26 slave to receive trigger from PINT1 master */
	*pREG_TRU0_SSR47 = TRGM_PINT1_BLOCK ;
	*pREG_TRU0_SSR48 = TRGM_PINT1_BLOCK ;

	return 0;
}
