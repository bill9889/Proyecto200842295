readme.txt for BF592_EMI_Project.dpj


Date Modified: June 09, 2011
__________________________________________________________________________________

Contents

I.  Overview
II. Operation Description

__________________________________________________________________________________

I.Overview

The README guides through to setup the tests for the BF592_EMI_Project.dpj project.

__________________________________________________________________________________

II.Opeartion Description

1)  Start the IDDE
2)  Create and/or select an ADSP-BF592-A session.
3)  Open the BF592_EMI_project (.dpj) file.
4)  From the "Tools" menu , choose the "Flash Programmer".
5)  In the "Driver" tab Browse for the "BF592EzFlashDriver_M25P16.dxe" file, in the 
    Flash Program driver folder provided with the project. Click "Load Driver",and 
    wait till message says "Success: Driver loaded"
6)  Select the "Programming"  tab. Browse the (.ldr)file to be loaded to the board.
    The files for different test are provided in the "Debug" folder , present inside
    folder for the project.
7)  Select the (.ldr) file, for the required test to be run.Following test files are
    included.

    -> BF592_EMI_Project_TEST_1.ldr (Test 1 Loader file)
    -> BF592_EMI_Project_TEST_2.ldr (Test 2 Loader file)
    -> BF592_EMI_Project_TEST_3.ldr (Test 3 Loader file)
    -> BF592_EMI_Project_TEST_4.ldr (Test 4 Loader file)

8)  Click "Program" after the file is selected.
9)  For loading different tests on the board repeat the procedure from Step 4, and 
    Select different tests listed in Step 7.

___________________________________________________________________________________