*****************************************************************************************


This ZIP File is associated with Rev 1 of the Application Note


    Utilizing the Trigger Routing Unit for System Level Synchronization (EE-360)  


that can be found at http://www.analog.com/ee-notes.


Date Created:	October 9th, 2013


*****************************************************************************************


The archive provides the following code examples:

Example 1 illustrates an example to time external event without the core intervenation 

Example 2 illustrates an example to time the assertion of Push Button (PB1) on the 
ADSP-BF609 EZ-KIT Board evaluation platform


*****************************************************************************************


All code examples have been written and tested with:

	ADSP-BF609 silicon revision 0.0

	ADSP-BF609 EZ-KIT Lite revision 1.0
        
        CrossCore Embedded Studio Tools version 1.0.2.0


*****************************************************************************************


