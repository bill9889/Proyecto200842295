/*****************************************************************************
 * TRU_Exampe_EZKit_Core0.c
 *****************************************************************************/

#include <ccblkfn.h>
#include "adi_initialize.h"
#include "TRU_Exampe_EZKit_Core0.h"
#include <stdio.h>
#include <services/gpio/adi_gpio.h>
#include "cgu_init.h"


int main(void)
{
	*pREG_PORTB_FER = 0u;   /* bug? should reset to 0 */

    adi_initComponents(); /* auto-generated code */

	printf("TRU EZ-kit Example\n");

	/* Software Switch Configuration for the ADSP-BF609 EZ-BOARD */
	ConfigSoftSwitches();

	/* CCLK=500Mhz, 125Mhz SCLK0 CLK  */
	CGU_Init(20, 1, 2);

	/* Configure Master */
	master_config();

	/* Configure Slave */
	slave_config();

	/* Configure TRU */
	tru_config();

	printf("\nPress PB1 to start and release to stop timer on the BF609 EZ-Board \n");

	while (1)
	{
		// Display Count
		if(gcnt)
		{
			printf("PB1 pressed for %d micro Sec\n ",*pREG_TIMER0_TMR0_CNT/125);
			break;
		}
	}
	return 0;
}


int master_config()
{
	/* Configure GPIO  Master*/
	gpio_config();

	return 0;
}

int slave_config()
{
	/* Configure timer slave */
	timer_config();

	/* Configure dma slave */
	dma_config();

	return 0;
}

int timer_config(void)
{
	/* active state, auto reload, generate no interrupt */
	*pREG_TIMER0_TMR0_CFG = ENUM_TIMER_TMR_CFG_EMU_CNT|ENUM_TIMER_TMR_CFG_CLKSEL_SCLK| ENUM_TIMER_TMR_CFG_TRIGSTART|ENUM_TIMER_TMR_CFG_PWMCONT_MODE |ENUM_TIMER_TMR_CFG_PADOUT_DIS;
	*pREG_TIMER0_TMR0_PER = TIMEOUT_PERIOD;
	*pREG_TIMER0_TMR0_WID = 1;
	*pREG_TIMER0_TRG_IE |= BITM_TIMER_TRG_IE_TMR00;

	return 0;
}


int dma_config(void)
{
	int stop_timer01 = 0x01;

	// Source DMA Channel
	*pREG_DMA25_ADDRSTART = &stop_timer01;
	/* configure source registers */
	*pREG_DMA25_CFG  = (ENUM_DMA_CFG_READ | ENUM_DMA_CFG_MSIZE02 | ENUM_DMA_CFG_STOP | ENUM_DMA_CFG_ADDR1D| ENUM_DMA_CFG_TRGWAIT);
	*pREG_DMA25_XCNT = 0x01;
	*pREG_DMA25_XMOD = 0;

	// Destination DMA Channel (DST: TIMER00 STOP Configuration Register)
	*pREG_DMA26_ADDRSTART = REG_TIMER0_RUN_CLR;
	/* configure destination registers */
	*pREG_DMA26_CFG  = (ENUM_DMA_CFG_WRITE | ENUM_DMA_CFG_MSIZE02 | ENUM_DMA_CFG_STOP | ENUM_DMA_CFG_ADDR1D|ENUM_DMA_CFG_TRGWAIT);
	*pREG_DMA26_XCNT = 0x01;
	*pREG_DMA26_XMOD = 0;

	// Enable DMA Channels
	*pREG_DMA25_CFG |= ENUM_DMA_CFG_EN ;
	*pREG_DMA26_CFG |= ENUM_DMA_CFG_EN ;

	return 0;
}

void GPIO_ISR(uint32_t iid, void* handlerArg)
{
	// clear interrupt
    *pREG_PINT1_LATCH |= 1 << BITP_PINT_EDGE_CLR_PIQ26;
	gcnt = 1;
	return ;
}


int gpio_config(void)
{
	// Configure PB1
	*pREG_PORTB_FER |= 0 << BITP_PORT_FER_PX10;
	*pREG_PORTB_DIR |= 0 << BITP_PORT_FER_PX10;
	*pREG_PORTB_INEN |= 1 << BITP_PORT_INEN_PX10;
	*pREG_PORTB_DATA_CLR |= 1 << BITP_PORT_DATA_CLR_PX10;

	//PINT0 as master trigger to start the timer
	*pREG_PINT0_ASSIGN |= BITM_PINT_ASSIGN_B0MAP;
	*pREG_PINT0_MSK_SET |= 1 << BITP_PINT_MSK_SET_PIQ10;
	*pREG_PINT0_EDGE_SET |= 1 << BITP_PINT_EDGE_SET_PIQ10;

	// PINT1 as master trigger to start the MDMA(TO stop the timer)
	*pREG_PINT1_ASSIGN |= BITM_PINT_ASSIGN_B0MAP;
	*pREG_PINT1_MSK_SET |= 1 << BITP_PINT_MSK_SET_PIQ26;
	*pREG_PINT1_EDGE_SET |= 1 << BITP_PINT_EDGE_SET_PIQ26;
	*pREG_PINT1_INV_SET |= 1 << BITP_PINT_INV_SET_PIQ26;

	/* Register the interrupt handler with SEC to display the TImer count */
    adi_int_InstallHandler(INTR_PINT1_BLOCK,GPIO_ISR,NULL,true);

	return 0;
}

int tru_config(void)
{
	/* Enable the TRU */
	*pREG_TRU0_GCTL |= 0x1;

	/* Configure Timer0 slave to receive trigger from PINT0 master */
	*pREG_TRU0_SSR2 = TRGM_PINT0_BLOCK ;

	/* Configure MDMA Channel 25/26 slave to receive trigger from PINT3 master */
	*pREG_TRU0_SSR47 = TRGM_PINT1_BLOCK ;
	*pREG_TRU0_SSR48 = TRGM_PINT1_BLOCK ;

	return 0;
}
