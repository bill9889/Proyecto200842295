/*
 *
 *   (C) Copyright 2012 - Analog Devices, Inc.  All rights reserved.
 *
 *    FILE:     TRU_Exampe_EZKit_Core0.h ( )
 *
 *    PURPOSE:  Includes the macros, variables and function declarations for TRU_Exampe_EZKit_Core0.h.C
 *
 */


#ifndef __TRU_EXAMPE_EZKIT_CORE0_H__
#define __TRU_EXAMPE_EZKIT_CORE0_H__

/* Add your custom header content here */

/* Global Macros */
#define TIMEOUT_PERIOD	0xFFFFFFFFF


extern void ConfigSoftSwitches(void);

/*  Function Prototypes */
int master_config(void);
int gpio_config(void);
int slave_config(void);
int timer_config(void);
int dma_config(void);
int tru_config(void);

/*  Global Flag */
int gcnt = 0 ;

#endif /* __TRU_EXAMPE_EZKIT_CORE0_H__ */
