/*****************************************************************************
 * SSL_2_0_Audio_Talkthrough.h
 *****************************************************************************/

#ifndef __SSL_2_0_AUDIO_TALKTHROUGH_H__
#define __SSL_2_0_AUDIO_TALKTHROUGH_H__

/* Add your custom header content here */

#endif /* __SSL_2_0_AUDIO_TALKTHROUGH_H__ */
