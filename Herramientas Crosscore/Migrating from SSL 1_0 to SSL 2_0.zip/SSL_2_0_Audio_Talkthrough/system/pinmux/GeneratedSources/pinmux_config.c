/*
 **
 ** pinmux_config.c source file generated on July 9, 2013 at 14:48:37.	
 **
 ** Copyright (C) 2000-2013 Analog Devices Inc., All Rights Reserved.
 **
 ** This file is generated automatically based upon the options selected in 
 ** the Pin Multiplexing configuration editor. Changes to the Pin Multiplexing
 ** configuration should be made by changing the appropriate options rather
 ** than editing this file.
 **
 ** Selected Peripherals
 ** --------------------
 ** SPORT0 (DRPRI, RFS, RSCLK, DTPRI, TFS, TSCLK)
 **
 ** GPIO (unavailable)
 ** ------------------
 ** PG6, PG7, PG8, PG9, PG10, PG15
 */

#include <sys/platform.h>
#include <stdint.h>

#define SPORT0_DRPRI_PORTG_MUX  ((uint16_t) ((uint16_t) 1<<4))
#define SPORT0_RFS_PORTG_MUX  ((uint16_t) ((uint16_t) 1<<4))
#define SPORT0_RSCLK_PORTG_MUX  ((uint16_t) ((uint16_t) 1<<6))
#define SPORT0_DTPRI_PORTG_MUX  ((uint16_t) ((uint16_t) 0<<2))
#define SPORT0_TFS_PORTG_MUX  ((uint16_t) ((uint16_t) 0<<12))
#define SPORT0_TSCLK_PORTG_MUX  ((uint16_t) ((uint16_t) 1<<8))

#define SPORT0_DRPRI_PORTG_FER  ((uint16_t) ((uint16_t) 1<<7))
#define SPORT0_RFS_PORTG_FER  ((uint16_t) ((uint16_t) 1<<8))
#define SPORT0_RSCLK_PORTG_FER  ((uint16_t) ((uint16_t) 1<<9))
#define SPORT0_DTPRI_PORTG_FER  ((uint16_t) ((uint16_t) 1<<6))
#define SPORT0_TFS_PORTG_FER  ((uint16_t) ((uint16_t) 1<<15))
#define SPORT0_TSCLK_PORTG_FER  ((uint16_t) ((uint16_t) 1<<10))

int32_t adi_initpinmux(void);

/*
 * Initialize the Port Control MUX and FER Registers
 */
int32_t adi_initpinmux(void) {
    /* PORTx_MUX registers */
    *pPORTG_MUX = SPORT0_DRPRI_PORTG_MUX | SPORT0_RFS_PORTG_MUX
     | SPORT0_RSCLK_PORTG_MUX | SPORT0_DTPRI_PORTG_MUX | SPORT0_TFS_PORTG_MUX
     | SPORT0_TSCLK_PORTG_MUX;

    /* PORTx_FER registers */
    *pPORTG_FER = SPORT0_DRPRI_PORTG_FER | SPORT0_RFS_PORTG_FER
     | SPORT0_RSCLK_PORTG_FER | SPORT0_DTPRI_PORTG_FER | SPORT0_TFS_PORTG_FER
     | SPORT0_TSCLK_PORTG_FER;
    return 0;
}

