//Necessary includes
#include <services/services.h>		// system service includes
#include <drivers/adi_dev.h>        // device driver includes
#include <drivers/twi/adi_twi.h>
#include <drivers/codec/adi_bf52xc1.h>  /* BF52xC1 driver includes      */
#include <stdio.h>

//Handlers for the DMA and Device Manager Services
ADI_DMA_MANAGER_HANDLE adi_dma_ManagerHandle;   // handle to the DMA manager
ADI_DEV_MANAGER_HANDLE adi_dev_ManagerHandle;   // handle to the Device manager
ADI_DCB_HANDLE         DCBManagerHandle;		// handle to the Deferred Callback Manager

//Global Definitions for our Services' data
#define ADI_SSL_INT_NUM_SECONDARY_HANDLERS  (4) // number of secondary interrupt handlers (SPORT DMA interrupts)
#define ADI_SSL_DCB_NUM_SERVERS             (4) // number of DCB servers
#define ADI_SSL_DMA_NUM_CHANNELS            (2) // number of DMA channels (SPORT Tx & Rx)
#define ADI_SSL_FLAG_NUM_CALLBACKS          (0) // number of flag callbacks
#define ADI_SSL_SEM_NUM_SEMAPHORES          (0) // number of semaphores
#define ADI_SSL_DEV_NUM_DEVICES             (3) // number of device drivers	(SPI,SPORT,BF52xC1)

static  u8  InterruptServiceData        [ADI_INT_SECONDARY_MEMORY * ADI_SSL_INT_NUM_SECONDARY_HANDLERS];
static  u8  DeferredCallbackServiceData [ADI_DCB_QUEUE_SIZE * ADI_SSL_DCB_NUM_SERVERS];
static  u8  DMAServiceData              [ADI_DMA_BASE_MEMORY + (ADI_DMA_CHANNEL_MEMORY *  ADI_SSL_DMA_NUM_CHANNELS)];
static  u8  FlagServiceData             [ADI_FLAG_CALLBACK_MEMORY *  ADI_SSL_FLAG_NUM_CALLBACKS];
static  u8  SemaphoreServiceData        [ADI_SEM_SEMAPHORE_MEMORY *  ADI_SSL_SEM_NUM_SEMAPHORES];
static  u8  DevMgrData                  [ADI_DEV_BASE_MEMORY + (ADI_DEV_DEVICE_MEMORY * ADI_SSL_DEV_NUM_DEVICES)];
static 	u8 	DCBMgrData					[ADI_DCB_QUEUE_SIZE + (ADI_DCB_ENTRY_SIZE)*4];

//Power Configuration
ADI_PWR_COMMAND_PAIR power_settings[] = {
    { ADI_PWR_CMD_SET_PROC_VARIANT, (void*)ADI_PWR_PROC_BF527SBBC1600 },
    { ADI_PWR_CMD_SET_PACKAGE,   (void*)ADI_PWR_PACKAGE_MBGA },
    { ADI_PWR_CMD_SET_VDDEXT,   (void*)ADI_PWR_VDDEXT_330 },
    { ADI_PWR_CMD_SET_CLKIN,    (void*)25 /* MHz */ },
    { ADI_PWR_CMD_END,          0 }
};

/* Hardware TWI configuration table to access BF52xC1 registers */
/* Run TWI clock at 100MHz & 50% Duty Cycle */
adi_twi_bit_rate rate={100,50};
/* Configuration table */
ADI_DEV_CMD_VALUE_PAIR aTWIConfigTable[]=
{
	{ ADI_TWI_CMD_SET_HARDWARE,         (void *)ADI_INT_TWI             },
   	{ ADI_DEV_CMD_SET_DATAFLOW_METHOD,  (void *)ADI_DEV_MODE_SEQ_CHAINED},
   	{ ADI_TWI_CMD_SET_FIFO,             (void *)0x0000                  },
   	{ ADI_TWI_CMD_SET_LOSTARB,          (void *)1                       },
  	{ ADI_TWI_CMD_SET_RATE,				(void *)(&rate)					},
   	{ ADI_TWI_CMD_SET_ANAK,             (void *)0                       },
   	{ ADI_TWI_CMD_SET_DNAK,             (void *)0                       },
   	{ ADI_DEV_CMD_SET_DATAFLOW,         (void *)TRUE                    },
   	{ ADI_DEV_CMD_END,                 	NULL                            }
};

//Additional Definition
#define ADI_SSL_ENTER_CRITICAL (NULL)

//Buffers for Audio Codec
ADI_DEV_1D_BUFFER     In1DBuf0,In1DBuf1;
ADI_DEV_1D_BUFFER     Out1DBuf0,Out1DBuf1;

//Defines for Codec
#define     SAMPLES_PER_CHANNEL     	(1024)
#define     NUM_CHANNELS                2
#define     DAC_LEFT_CHANNEL            0
#define     DAC_RIGHT_CHANNEL          	1
#define     ADC_LEFT_CHANNEL            0
#define     ADC_RIGHT_CHANNEL          	1

#define BUFFER_PACK_BYTES    2   /* 2 byte boundary if BF52xC1 word length = 16bits */
section ("InboundAudio")  u16 InDataBuf0 [SAMPLES_PER_CHANNEL * NUM_CHANNELS];
section ("InboundAudio")  u16 InDataBuf1 [SAMPLES_PER_CHANNEL * NUM_CHANNELS];
section ("OutboundAudio") u16 OutDataBuf0[SAMPLES_PER_CHANNEL * NUM_CHANNELS];
section ("OutboundAudio") u16 OutDataBuf1[SAMPLES_PER_CHANNEL * NUM_CHANNELS];

//Handle for the Audio Code
static ADI_DEV_DEVICE_HANDLE    BF52xC1DriverHandle;

//Function Prototypes
static ADI_INT_HANDLER(ExceptionHandler);   /* exception handler */
static ADI_INT_HANDLER(HWErrorHandler);     /* hardware error handler */
/* BF52xC1 callback */
static void BF52xC1Callback(
    void    *AppHandle,
    u32     Event,
    void    *pArg
);
void ProcessInput(void);

static ADI_INT_HANDLER(ExceptionHandler)    /* Exception handler    */
{
    printf("Exception!\n");
    while(1);
}

static ADI_INT_HANDLER(HWErrorHandler)  /* Hardware error handler   */
{
    printf("Hardware Error!\n");
    while(1);
}

static void BF52xC1Callback(
    void *AppHandle,
    u32  Event,
    void *pArg)
{
    u32 i;
    /* Pointer to processed buffer */
    ADI_DEV_1D_BUFFER *pBuffer;

	/* if (BF52xC1 input audio data bit length is set as 16-bits) */

    /* Samples are 16-bits */
    u16	    (*pSrc)[] = NULL;
    u16     (*pDest)[] = NULL;


    /* CASEOF (Event) */
    switch (Event)
    {
        /* CASE (Event buffer processed) */
		case (ADI_DEV_EVENT_BUFFER_PROCESSED):

			/* Get the address of 1D buffer that was processed */
			pBuffer = (ADI_DEV_1D_BUFFER*)pArg;

			/* get the source & destination data buffer addresses */
			if (pBuffer == &In1DBuf0)
			{
				pSrc = (void *) &InDataBuf0[0];
				pDest = (void *) &OutDataBuf0[0];
			}
			else if (pBuffer == &In1DBuf1)
			{
				pSrc = (void *) &InDataBuf1[0];
				pDest = (void *) &OutDataBuf1[0];
			}
			else
			{
				break;
			}

			/* copy the source Rx data to Tx channels */
			for (i = 0;i < (SAMPLES_PER_CHANNEL * NUM_CHANNELS); i++)
			{
			    (*pDest)[DAC_LEFT_CHANNEL+i] = (*pSrc)[ADC_LEFT_CHANNEL+i];
			    (*pDest)[DAC_RIGHT_CHANNEL+i] = (*pSrc)[ADC_RIGHT_CHANNEL+i];
			}
			break;

        default:
            printf("Callback occured. Event code: 0x%08X\n",Event);
            break;
    }
    /* return */
}

//Main function
void main( void )
{
	u32 Result, i, ResponseCount;
    ADI_BF52xC1_SAMPLE_RATE     SampleRate;
	
	//Initialize the interrupt Service
	Result = adi_int_Init(InterruptServiceData, sizeof(InterruptServiceData), &i, ADI_SSL_ENTER_CRITICAL);
	if (Result != ADI_INT_RESULT_SUCCESS) 
	{
		printf("adi_int_Init Error. Error Code: 0x%08X\n",Result);
	}
	
	//Initialize the Power Service
	Result = adi_pwr_Init(power_settings);
	if ((Result != ADI_PWR_RESULT_SUCCESS) && (Result != ADI_PWR_RESULT_ALREADY_INITIALIZED)) {
        printf("adi_pwr_Init Error. Error Code: 0x%08X\n",Result);
    }
    
    //Initialize the Deferred Callback Service
    Result = adi_dcb_Init(DeferredCallbackServiceData, sizeof(DeferredCallbackServiceData), &i, ADI_SSL_ENTER_CRITICAL);
    if (Result != ADI_DCB_RESULT_SUCCESS) {
        printf("adi_dcb_Init Error. Error Code: 0x%08X\n",Result);
    }

    //Initialize the DMA Manager Service
   	Result = adi_dma_Init(DMAServiceData, sizeof(DMAServiceData), &i, &adi_dma_ManagerHandle, ADI_SSL_ENTER_CRITICAL);
   	if (Result != ADI_DMA_RESULT_SUCCESS) {
   		printf("adi_dma_Init Error. Error Code: 0x%08X\n",Result);
    }
    
    Result = adi_flag_Init(FlagServiceData, sizeof(FlagServiceData), &i, ADI_SSL_ENTER_CRITICAL);
	if (Result != ADI_FLAG_RESULT_SUCCESS) { 
   		printf("adi_dma_Init Error. Error Code: 0x%08X\n",Result);
	}
    
    //Initialize the Device Manager Service
    Result = adi_dev_Init(DevMgrData, sizeof(DevMgrData), &i, &adi_dev_ManagerHandle, ADI_SSL_ENTER_CRITICAL);
   	if (Result != ADI_DEV_RESULT_SUCCESS) {
   		printf("adi_dev_Init Error. Error Code: 0x%08X\n",Result);
    }
    
    //Open the Deferred Callback Service
    Result = adi_dcb_Open(14, &DCBMgrData[ADI_DCB_QUEUE_SIZE], (ADI_DCB_ENTRY_SIZE)*4, &ResponseCount, &DCBManagerHandle);
   	if (Result != 0) {
   		printf("adi_dcb_Open Error. Error Code: 0x%08X\n",Result);
    }
    
    //Configure the Codec
    ADI_DEV_ACCESS_REGISTER_FIELD ConfigBF52xC1[] =
    {
    	{ BF52xC1_REG_POWER,            BF52xC1_RFLD_LINE_IN_PDN,       0           },  /* Line-In Power ON                     */
        { BF52xC1_REG_ANALOGUE_PATH,   	BF52xC1_RFLD_ENABLE_MIC_MUTE,   1           },  /* Mute MIC                             */
        { BF52xC1_REG_ANALOGUE_PATH,   	BF52xC1_RFLD_ADC_IN_SELECT,     0           },  /* Select Line-In as ADC input          */
        { BF52xC1_REG_LEFT_ADC_VOL,     BF52xC1_RFLD_LIN_ENABLE_MUTE,   0           },  /* Un-mute Left Channel ADC             */
        { BF52xC1_REG_RIGHT_ADC_VOL,    BF52xC1_RFLD_RIN_ENABLE_MUTE,   0           },  /* Un-mute Right Channel ADC            */
        { BF52xC1_REG_LEFT_ADC_VOL,     BF52xC1_RFLD_LIN_VOL,           0x17        },  /* Left Channel ADC Volume set to 0dB   */
        { BF52xC1_REG_RIGHT_ADC_VOL,    BF52xC1_RFLD_RIN_VOL,           0x17        },  /* Right Channel ADC Volume set to 0dB  */
        { BF52xC1_REG_LEFT_DAC_VOL,     BF52xC1_RFLD_LHP_VOL,           0x79        },  /* Left channel headphone voulme = 0dB  */
        { BF52xC1_REG_RIGHT_DAC_VOL,    BF52xC1_RFLD_RHP_VOL,           0x79        },  /* Left channel headphone voulme = 0dB  */
        { BF52xC1_REG_POWER,            BF52xC1_RFLD_POWER_OFF,         0           },  /* Device Power ON                      */
        { BF52xC1_REG_POWER,            BF52xC1_RFLD_ADC_PDN,           0           },  /* ADC Power ON                         */
        { BF52xC1_REG_POWER,            BF52xC1_RFLD_DAC_PDN,           0           },  /* DAC Power ON                         */
        { BF52xC1_REG_POWER,            BF52xC1_RFLD_OUT_PDN,           0           },  /* Outputs Power ON                     */
        { BF52xC1_REG_POWER,            BF52xC1_RFLD_OSC_PDN,           0           },  /* Oscillator Power ON                  */
        { BF52xC1_REG_ANALOGUE_PATH,    BF52xC1_RFLD_ENABLE_BYPASS,     0           },  /* Disable Bypass                       */
        { BF52xC1_REG_ANALOGUE_PATH,   	BF52xC1_RFLD_SELECT_DAC,        1           },  /* Select DAC (Enable DAC)              */
        { BF52xC1_REG_DIGITAL_PATH,		BF52xC1_RFLD_ENABLE_DAC_MUTE,   0           },  /* Un-mute DAC                          */
        { BF52xC1_REG_DIGITAL_IFACE,  	BF52xC1_RFLD_IFACE_FORMAT,      2			},  /* Set DAI format to I2S				*/
        { BF52xC1_REG_DIGITAL_IFACE,    BF52xC1_RFLD_AUDIO_DATA_LEN,    0    },  /* Set Input Audio data bit length: 0 = 16bit  */
        { BF52xC1_REG_DIGITAL_IFACE,    BF52xC1_RFLD_ENABLE_MASTER,     1           },  /* Enable Master Mode                   */
        { BF52xC1_REG_SAMPLING_CTRL,    BF52xC1_RFLD_ENABLE_USB_MODE,  	1           },  /* Enable USB Mode                      */
        { ADI_DEV_REGEND,               0,                              0           }   /* End of register access               */
    };
    
    /* hook the exception interrupt*/
    if((Result = adi_int_CECHook(3, ExceptionHandler, NULL, FALSE)) != ADI_INT_RESULT_SUCCESS)
    {
        printf("Failed to hook exception handler, Error Code: 0x%08X\n",Result);
    }

    /* hook the hardware error*/
    if((Result = adi_int_CECHook(5, HWErrorHandler, NULL, FALSE)) != ADI_INT_RESULT_SUCCESS)
    {
        printf("Failed to hook hardware error handler, Error Code: 0x%08X\n",Result);
    }
    
    /* open the BF52xC1 driver for loopback */
    Result = adi_dev_Open(  adi_dev_ManagerHandle,          /* Dev manager Handle                       */
                            &ADIBF52xC1EntryPoint,          /* Entry point for BF52xC1 driver           */
                            0,                              /* Device number                            */
                            NULL,                           /* No client handle                         */
                            &BF52xC1DriverHandle,           /* Location to store BF52xC1 driver handle  */
                            ADI_DEV_DIRECTION_BIDIRECTIONAL,/* Data Direction                           */
                            adi_dma_ManagerHandle,          /* Handle to DMA Manager                    */
                            DCBManagerHandle,               /* Handle to callback manager               */
                            BF52xC1Callback);               /* Callback Function                        */
    if (Result != ADI_DEV_RESULT_SUCCESS)
    {
        printf("Failed to open BF52xC1 device. Error Code: 0x%08X\n",Result);
    }
    
	/* Initialise CSB flag pin and clear it to use 0x1A as Audio CODEC TWI address */
    /* Open the Flag pin connected to the CSB pin */
    Result = adi_flag_Open(ADI_FLAG_PH9);
    if (Result != ADI_FLAG_RESULT_SUCCESS)
    {
        printf("Failed to open Flag pin connected to CSB, Error Code: 0x%08X\n",Result);
    }

    /* Set this pin as Output */
    Result = adi_flag_SetDirection(ADI_FLAG_PH9,ADI_FLAG_DIRECTION_OUTPUT);
    if (Result  != ADI_FLAG_RESULT_SUCCESS)
    {
        printf("Failed to configure Flag pin connected to CSB, Error Code: 0x%08X\n",Result);
    }

    /* clear this pin to use 0x1A as Audio CODEC TWI address */
    Result = adi_flag_Clear (ADI_FLAG_PH9);
    if (Result  != ADI_FLAG_RESULT_SUCCESS)
    {
        printf("Failed to clear Flag pin connected to CSB, Error Code: 0x%08X\n",Result);
    }

    /* Set BF52xC1 driver to use TWI to access BF52xC1 hardware registers */
    Result = adi_dev_Control(BF52xC1DriverHandle, ADI_BF52xC1_CMD_SET_TWI_DEVICE_NUMBER, (void *)0);
    if (Result != ADI_DEV_RESULT_SUCCESS)
    {
        printf("Failed to set TWI device number to use for BF52xC1 register access, Error Code: 0x%08X\n",Result);
    }

    /* Set BF52xC1 TWI address */
    Result = adi_dev_Control(BF52xC1DriverHandle, ADI_BF52xC1_CMD_SET_TWI_GLOBAL_ADDR, (void *)0x1A);
    if (Result != ADI_DEV_RESULT_SUCCESS)
    {
        printf("Failed to set TWI device address to use for BF52xC1 register access, Error Code: 0x%08X\n",Result);
    }

    /* pass TWI configuration table */
    Result = adi_dev_Control(BF52xC1DriverHandle, ADI_BF52xC1_CMD_SET_TWI_SPI_CONFIG_TABLE, (void *)aTWIConfigTable);
    if (Result != ADI_DEV_RESULT_SUCCESS)
    {
        printf("Failed to set TWI configuration table for BF52xC1 register access, Error Code: 0x%08X\n",Result);
    }
	
	/* Set SPORT device number connected to BF52xC1 Digital Audio Interface port */
    Result = adi_dev_Control(BF52xC1DriverHandle, ADI_BF52xC1_CMD_SET_SPORT_DEVICE_NUMBER, (void *)2);
    if (Result != ADI_DEV_RESULT_SUCCESS)
    {
    	printf("Failed to set SPORT device number connected to BF52xC1 Digital Audio Interface port, Error Code: 0x%08X\n",Result);
    }


    /* Configure BF52xC1 registers */
    Result = adi_dev_Control(BF52xC1DriverHandle, ADI_DEV_CMD_REGISTER_FIELD_TABLE_WRITE, (void *)ConfigBF52xC1);
    if (Result != ADI_DEV_RESULT_SUCCESS)
    {
    	printf("Failed to configure BF52xC1 register fields, Error Code: 0x%08X\n",Result);
    }
    else
    {
    	printf("Configured BF52xC1 in ");
    }
    
    /* ADC/DAC Sample rate */
    SampleRate.AdcSampleRate = ADI_BF52xC1_SR_44_1K;
    SampleRate.DacSampleRate = ADI_BF52xC1_SR_44_1K;

    /* Set ADC/DAC Sample rate */
    Result = adi_dev_Control(BF52xC1DriverHandle, ADI_BF52xC1_CMD_SET_SAMPLE_RATE, (void *)&SampleRate);
    if (Result != ADI_DEV_RESULT_SUCCESS)
    {
    	printf("Failed to set BF52xC1 ADC/DAC sample rate, Error Code: 0x%08X\n",Result);
    }
    else
    {
    	printf("ADC Sampling Rate = %dHz, DAC Sampling Rate = %dHz\n\n",ADI_BF52xC1_SR_44_1K,ADI_BF52xC1_SR_44_1K);
    }

    /******************Buffer preparation **********************/

    /* Inbound 1D buffers */
    In1DBuf0.Data               = InDataBuf0;
    In1DBuf0.ElementCount       = (SAMPLES_PER_CHANNEL * NUM_CHANNELS);
    In1DBuf0.ElementWidth       = BUFFER_PACK_BYTES;
    In1DBuf0.CallbackParameter  = &In1DBuf0;   /* enable callback on completion of this buffer */
    In1DBuf0.ProcessedFlag      = FALSE;
    In1DBuf0.pNext              = &In1DBuf1;

    In1DBuf1.Data               = InDataBuf1;
    In1DBuf1.ElementCount       = (SAMPLES_PER_CHANNEL * NUM_CHANNELS);
    In1DBuf1.ElementWidth       = BUFFER_PACK_BYTES;
    In1DBuf1.CallbackParameter  = &In1DBuf1;   /* enable callback on completion of this buffer */
    In1DBuf1.ProcessedFlag      = FALSE;
    In1DBuf1.pNext              = NULL;

    /* Outbound 1D buffers */
    Out1DBuf0.Data              = OutDataBuf0;
    Out1DBuf0.ElementCount      = (SAMPLES_PER_CHANNEL * NUM_CHANNELS);
    Out1DBuf0.ElementWidth      = BUFFER_PACK_BYTES;
    Out1DBuf0.CallbackParameter = NULL;             /* no callback for this buffer */
    Out1DBuf0.ProcessedFlag     = FALSE;
    Out1DBuf0.pNext             = &Out1DBuf1;

    Out1DBuf1.Data              = OutDataBuf1;
    Out1DBuf1.ElementCount      = (SAMPLES_PER_CHANNEL * NUM_CHANNELS);
    Out1DBuf1.ElementWidth      = BUFFER_PACK_BYTES;
    Out1DBuf1.CallbackParameter = NULL;             /* no callback for this buffer */
    Out1DBuf1.ProcessedFlag     = FALSE;
    Out1DBuf1.pNext             = NULL;

    /* Set dataflow method */
    Result = adi_dev_Control(BF52xC1DriverHandle, ADI_DEV_CMD_SET_DATAFLOW_METHOD, (void *)ADI_DEV_MODE_CHAINED_LOOPBACK);
    if (Result !=ADI_DEV_RESULT_SUCCESS)
    {
    	printf("Failed to set dataflow method, Error Code: 0x%08X\n",Result);
    }

    /* Submit Inbound buffer to BF52xC1 */
    Result = adi_dev_Read (BF52xC1DriverHandle, ADI_DEV_1D, (ADI_DEV_BUFFER *)&In1DBuf0);
    if (Result != ADI_DEV_RESULT_SUCCESS)
    {
    	printf("Failed to submit InboundBuffer, Error Code: 0x%08X\n",Result);
    }

    /* Submit Outbound buffer to BF52xC1 */
    Result = adi_dev_Write(BF52xC1DriverHandle, ADI_DEV_1D, (ADI_DEV_BUFFER *)&Out1DBuf0);
    if (Result != ADI_DEV_RESULT_SUCCESS)
    {
    	printf("Failed to submit OutboundBuffer, Error Code: 0x%08X\n",Result);
    }

    printf ("Enabling Audio Loopback...\n");

    /* Enable BF52xC1 dataflow  - this activates BF52xC1 Digital Audio Interface */
    Result = adi_dev_Control(BF52xC1DriverHandle, ADI_DEV_CMD_SET_DATAFLOW, (void *)TRUE);
    if (Result != ADI_DEV_RESULT_SUCCESS)
    {
    	printf("Failed to enable BF52xC1 dataflow, Error Code: 0x%08X\n",Result);
    }
	
	while(true)
	{
		
	}
}
