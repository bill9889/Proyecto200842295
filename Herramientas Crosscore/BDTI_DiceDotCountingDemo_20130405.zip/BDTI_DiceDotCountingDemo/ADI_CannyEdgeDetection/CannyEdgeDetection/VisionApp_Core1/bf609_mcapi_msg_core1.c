/*****************************************************************************
 * BF609_MCAPI_msg_Core1.c
 *****************************************************************************/

#include <ccblkfn.h>
#include "adi_initialize.h"
#include "bf609_mcapi_msg_core0.h"

#include <stdio.h>

extern int32_t graphics_init(void);
extern void InitEdgeDraw(void);

int main(void)
{
      mcapi_status_t    mcapi_status        = MCAPI_ERR_GENERAL;
      int               retVal              = PASS;

    /* Initialize managed drivers and/or services */
    if ( 0 != adi_initComponents() )
    {
        printf("[CORE1]: BF609_MCAPI_msg: Error initializing components\n");
    }

    /* Begin adding your custom code here */

    InitEdgeDraw();

    graphics_init();

    retVal = main_node1(&adi_mcapi_info);

    /*
    mcapi_finalize(&mcapi_status);
    if (MCAPI_SUCCESS != mcapi_status) {
        exit(1);
    }

    fprintf(stdout, "[CORE1]: BF609_MCAPI_msg: %s\n",
            retVal == PASS ? "All done" : "Error...");
    */
      return retVal;
}

