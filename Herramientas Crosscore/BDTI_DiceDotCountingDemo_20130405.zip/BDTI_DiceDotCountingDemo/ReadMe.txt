//=================================================================================================
//
//     BBBBBBBBBBBBBBBBB   DDDDDDDDDDDDD       TTTTTTTTTTTTTTTTTTTTTTT  iiii
//     B::::::::::::::::B  D::::::::::::DDD    T:::::::::::::::::::::T i::::i
//     B::::::BBBBBB:::::B D:::::::::::::::DD  T:::::::::::::::::::::T  iiii
//     BB:::::B     B:::::BDDD:::::DDDDD:::::D T:::::TT:::::::TT:::::T
//       B::::B     B:::::B  D:::::D    D:::::DTTTTTT  T:::::T  TTTTTTiiiiiii
//       B::::B     B:::::B  D:::::D     D:::::D       T:::::T        i:::::i
//       B::::BBBBBB:::::B   D:::::D     D:::::D       T:::::T         i::::i
//       B:::::::::::::BB    D:::::D     D:::::D       T:::::T         i::::i
//       B::::BBBBBB:::::B   D:::::D     D:::::D       T:::::T         i::::i
//       B::::B     B:::::B  D:::::D     D:::::D       T:::::T         i::::i
//       B::::B     B:::::B  D:::::D     D:::::D       T:::::T         i::::i
//       B::::B     B:::::B  D:::::D    D:::::D        T:::::T         i::::i
//     BB:::::BBBBBB::::::BDDD:::::DDDDD:::::D       TT:::::::TT      i::::::i
//     B:::::::::::::::::B D:::::::::::::::DD        T:::::::::T      i::::::i
//     B::::::::::::::::B  D::::::::::::DDD          T:::::::::T      i::::::i
//     BBBBBBBBBBBBBBBBB   DDDDDDDDDDDDD             TTTTTTTTTTT      iiiiiiii
//
//-----------------------------------------------------------------------------------------------
// BDTI Dice Dot-Counting Demo and Reference Design for the Analog Devices BF60x 
// Developed by Berkeley Design Technology, Inc. (BDTI)
//
// BDTI provides expert engineering services, including algorithm design and implementation of
// software for embedded vision applications. For questions regarding this demo or information
// on BDTI�s engineering services, contact BDTI:
//
// info@BDTI.com                      +1 (925) 954-1411                   http://www.BDTI.com
//
// Berkeley Design Technology, Inc.(BDTI) makes no warranty for the use of this software, which
// has been developed for demonstration purposes only.  This software is provided  "as is".  BDTI
// assumes no responsibility for any errors which may appear in this software, nor does it make
// a commitment to update the information contained herein. BDTI specifically disclaims any implied
// warranties of fitness for a particular purpose.  You are solely responsible for determining
// the suitability of this software for your purposes and you use it at your own risk. In no event
// shall BDTI be held liable for any damages of any kind arising out of your use of or inability to
// use this software.
//=================================================================================================


Introduction
============
The BDTI Dice Dot-Counting Demo and Reference Design (BDTI_DiceDotCountingDemo.zip) 
demonstrates boundary segmentation and classification on the Blackfin ADSP-BF609 
processor using the chip�s dual Blackfin CPU/DSP cores and the integrated 
Pipelined Vision Processor (PVP). 

Boundary segmentation and classification are demonstrated by finding and counting 
dice dots in real-time using a low-cost chip camera. The dice are thrown within view of 
the camera and the software automatically finds the dots and counts a total much faster 
than a human can. This is accomplished under semi-controlled lighting conditions and loosely 
controlled mechanical setup. Although the problem sounds simple, factors such as light 
reflecting off the dice, the need to reject dots on the sides of the dice, and irregular dots 
on the dice had to be overcome. 

The heart of this demo classifies the contours into dots and counts the dots. The dot 
classifier uses a simple mathematical model of a circle inscribed in a square to differentiate 
circles from other shapes. Only contours in the shape of circles fit the mathematical model 
and are counted as dots.


ADI Canny Edge Detection example project
========================================
This project is built on top of the ADI_CannyEdgeDetection project. 
The original un-modified ADI_CannyEdgeDetection project is compressed in the 
file: ADI_CannyEdgeDetection_YYYYMMDD.zip file. 
Where YYYYMMDD is the (Y)ear, (M)onth, and (D)ate of the project's release.


Directory Structure
===================
BDTI_DiceDotCountingDemo
    ADI_CannyEdgeDetection - folder
        binaries - folder containing pre-built binaries
        CannyEdgeDetection - folder containing the project/source

    Doc - folder containing documents
    ADI_CannyEdgeDetection_YYYYMMDD.zip
    ReadMe.txt - this file


Project Folder
==============
The projects meta data and source code is located in the BDTI_DiceDotCountingDemo/CannyEdgeDetection 
folder. This example contains two CCES projects, one for each core. 


Software Tools/Packages Required
================================
ADI CrossCore� Embedded Studio (CCES) 
    www.analog.com/cces

ADI Camera EI3 Extender Board Support Package (BSP) Software
    Release 1.0.0  
    www.analog.com/EX3-Camera

ADI Video Encoder EI3 Extender Board Support Package (BSP) Software
     www.analog.com/EX3-VidEncoder

ADI Blackfin 2D Graphics Library (OpenGL-based) BF2DGL-OGL
     www.analog.com/BF-GFX2D-00

ADI Blackfin Image Processing Toolbox
     www.analog.com/bf-iptbx-00

ADI Blackfin Vision Analytics Toolbox (VAT)
    www.analog.com/BF-VAT

ADI Board Support Package for BF609 EZ-Kit
    www.analog.com/BF609EZBoard


Hardware Required
=================
Avnet FinBoard        www.FinBoard.org


Opening/Building/Debugging the project in CCES
==============================================
For complete instructions with helpful screenshots please refer
to the "FinBoard Getting Started Guide" available at www.FinBoard.org


Opening CCES
============
After installing CCES and the required software packages open CCES.
Create a new workspace folder when asked by CCES.
Select File->Import->General->Existing Projects into Workspace.
Select the CannyEdgeDetection folder as the root directory.
Click the "Finish" button.


Building
========
Select Project->BuildAll


Configuring the Debugger
========================
Select Run->Debug Configurations
Select CrossCore Embedded Studio Application
Select "new" icon (a piece of paper with a yellow plus in the corner)
Select ADSP-BF609->Emulator
Select �ADSP-BF609 via ICE-100B� as the Platform Type, and then click Finish.
A window will pop-up asking which executable to load for each core.
Select VisionApp_Core0.dxe for core 0 and VisionApp_Core1.dxe for core 1.


Key Files
=========
BDTI_DiceDotCountingDemo/ADI_CannyEdgeDetection/CannyEdgeDetection/common
    adi_find_contours.c - dot classifier
    Graphics.c - OpenGL code to display dot count
    PVPInput.c - PVP configuration constants

BDTI_DiceDotCountingDemo/ADI_CannyEdgeDetection/CannyEdgeDetection/VisionApp_Core0
    EdgeDetection.c - Core 0 main()

BDTI_DiceDotCountingDemo/ADI_CannyEdgeDetection/CannyEdgeDetection/VisionApp_Core1
    node_1.c - main_node1()

