/*
 * GPIO.c
 */

#include "GPIO.h"
#include "SSL_CCES_Demo.h"

#define GPIO_MEMORY_SIZE (2*ADI_GPIO_CALLBACK_MEM_SIZE)
static uint8_t gpioMemory[GPIO_MEMORY_SIZE];
uint32_t gpioMaxCallbacks;

ADI_GPIO_RESULT LEDPBInit(void)
{
	ADI_GPIO_RESULT Result = ADI_GPIO_SUCCESS;

	Result = adi_gpio_Init(
		        (void*)gpioMemory,
		        GPIO_MEMORY_SIZE,
		        &gpioMaxCallbacks);
	CheckResult("GPIO Init", Result);

	Result = adi_gpio_SetDirection(
	    	ADI_GPIO_PORT_F,
	    	ADI_GPIO_PIN_8,
	        ADI_GPIO_DIRECTION_OUTPUT);
	CheckResult("LED1", Result);

	Result = adi_gpio_SetDirection(
	    	ADI_GPIO_PORT_G,
	    	ADI_GPIO_PIN_11,
	        ADI_GPIO_DIRECTION_OUTPUT);
	CheckResult("LED2", Result);

	Result = adi_gpio_SetDirection(
	    	ADI_GPIO_PORT_G,
	    	ADI_GPIO_PIN_12,
	        ADI_GPIO_DIRECTION_OUTPUT);
	CheckResult("LED3", Result);

	return Result;
}

ADI_GPIO_RESULT SetClearToggleLED(uint32_t action, uint32_t LED)
{
	ADI_GPIO_RESULT Result = ADI_GPIO_SUCCESS;
	if (action == 0)
	{
		if (LED == 1)
		{
			adi_gpio_Set(ADI_GPIO_PORT_F, ADI_GPIO_PIN_8);
		}else if (LED == 2) {
			adi_gpio_Set(ADI_GPIO_PORT_G, ADI_GPIO_PIN_11);
		} else if (LED == 3){
			adi_gpio_Set(ADI_GPIO_PORT_G, ADI_GPIO_PIN_12);
		}
	}
	else if (action == 1)
	{
		if (LED == 1)
		{
			adi_gpio_Clear(ADI_GPIO_PORT_F, ADI_GPIO_PIN_8);
		}else if (LED == 2) {
			adi_gpio_Clear(ADI_GPIO_PORT_G, ADI_GPIO_PIN_11);
		}else if (LED == 3) {
			adi_gpio_Clear(ADI_GPIO_PORT_G, ADI_GPIO_PIN_12);
		}
	}
	else if (action == 2)
	{
		if (LED == 1)
		{
			adi_gpio_Toggle(ADI_GPIO_PORT_F, ADI_GPIO_PIN_8);
		}else if (LED == 2) {
			adi_gpio_Toggle(ADI_GPIO_PORT_G, ADI_GPIO_PIN_11);
		}else if (LED == 3) {
			adi_gpio_Toggle(ADI_GPIO_PORT_G, ADI_GPIO_PIN_12);
		}
	}
	return Result;
}

