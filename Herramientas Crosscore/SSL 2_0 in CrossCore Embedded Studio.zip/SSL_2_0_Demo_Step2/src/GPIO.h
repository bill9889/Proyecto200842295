/*
 * GPIO.h
 */

#ifndef GPIO_H_
#define GPIO_H_

#include <services/gpio/adi_gpio.h>

ADI_GPIO_RESULT LEDPBInit(void);
ADI_GPIO_RESULT SetClearToggleLED(uint32_t LED, uint32_t action);

#endif /* GPIO_H_ */
