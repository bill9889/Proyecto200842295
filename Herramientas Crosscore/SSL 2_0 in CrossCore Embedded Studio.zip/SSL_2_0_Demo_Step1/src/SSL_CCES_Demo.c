/*****************************************************************************
 * SSL_2_0_Demo.c
 *****************************************************************************/

#include "adi_initialize.h"
#include "SSL_CCES_Demo.h"
#include <services/pwr/adi_pwr.h>
#include <stdint.h>
#include <stdio.h>


int main(void)
{
	/**
	 * Initialize managed drivers and/or services that have been added to 
	 * the project.
	 * @return zero on success 
	 */
	adi_initComponents();
	
	uint32_t Result = 0;

	Result = adi_pwr_Init(25000000, 500000000, 125000000, 60000000);
	CheckResult("Power Service", Result);

	return 0;
}

void CheckResult(char *operation, uint32_t result){
	if (result != 0) {
	    printf("%s Failed with error: %x\r\n", operation, result);
		bError = true;
	}
}
