/*****************************************************************************
 * SSL_2_0_Demo.h
 *****************************************************************************/

#ifndef __SSL_2_0_DEMO_H__
#define __SSL_2_0_DEMO_H__

/* Add your custom header content here */
#include <stdint.h>

static bool bError;

void CheckResult(char *operation, uint32_t result);

#endif /* __SSL_2_0_DEMO_H__ */
