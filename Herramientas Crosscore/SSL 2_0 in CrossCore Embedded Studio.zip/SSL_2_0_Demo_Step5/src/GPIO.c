/*
 * GPIO.c
 *
 *  Created on: Jul 17, 2013
 *      Author: cgilchr
 */

#include "GPIO.h"
#include "Audio.h"
#include "SSL_CCES_Demo.h"

#define GPIO_MEMORY_SIZE (2*ADI_GPIO_CALLBACK_MEM_SIZE)
static uint8_t gpioMemory[GPIO_MEMORY_SIZE];
uint32_t gpioMaxCallbacks;

ADI_GPIO_RESULT LEDPBInit(void)
{
	ADI_GPIO_RESULT Result = ADI_GPIO_SUCCESS;

	Result = adi_gpio_Init(
		        (void*)gpioMemory,
		        GPIO_MEMORY_SIZE,
		        &gpioMaxCallbacks);
	CheckResult("GPIO Init", Result);

	Result = adi_gpio_SetDirection(
	    	ADI_GPIO_PORT_F,
	    	ADI_GPIO_PIN_8,
	        ADI_GPIO_DIRECTION_OUTPUT);
	CheckResult("LED1", Result);

	Result = adi_gpio_SetDirection(
	    	ADI_GPIO_PORT_G,
	    	ADI_GPIO_PIN_11,
	        ADI_GPIO_DIRECTION_OUTPUT);
	CheckResult("LED2", Result);

	Result = adi_gpio_SetDirection(
	    	ADI_GPIO_PORT_G,
	    	ADI_GPIO_PIN_12,
	        ADI_GPIO_DIRECTION_OUTPUT);
	CheckResult("LED3", Result);

	Result = adi_gpio_SetDirection(
			ADI_GPIO_PORT_G,
	        ADI_GPIO_PIN_0,
	        ADI_GPIO_DIRECTION_INPUT);
	CheckResult("PB1 SetDirection",Result);

	Result = adi_gpio_SetDirection(
			ADI_GPIO_PORT_G,
	        ADI_GPIO_PIN_13,
	        ADI_GPIO_DIRECTION_INPUT);
	CheckResult("PB2 SetDirection",Result);

	Result = adi_gpio_SetInputEdgeSense(
			ADI_GPIO_PORT_G,
	        ADI_GPIO_PIN_0,
	        ADI_GPIO_SENSE_RISING_EDGE);
	CheckResult("PB1 SetInputEdgeSense",Result);

	Result = adi_gpio_SetInputEdgeSense(
			ADI_GPIO_PORT_G,
	        ADI_GPIO_PIN_13,
	        ADI_GPIO_SENSE_RISING_EDGE);
	CheckResult("PB1 SetInputEdgeSense",Result);

	Result = adi_gpio_EnableInterruptMask(
			ADI_GPIO_PORT_G,
	        ADI_GPIO_PIN_0,
	        ADI_GPIO_MASK_A,
	        true);
	CheckResult("PB1 EnableInterruptMask",Result);

	Result = adi_gpio_EnableInterruptMask(
			ADI_GPIO_PORT_G,
	        ADI_GPIO_PIN_13,
	        ADI_GPIO_MASK_A,
	        true);
	CheckResult("PB1 EnableInterruptMask",Result);

	Result = adi_gpio_RegisterCallback(
	    	ADI_GPIO_PORT_G,
	        ADI_GPIO_PIN_0,
	        LED_PB_Callback,
	        (void*)0);
	CheckResult("PB2 RegisterCallback",Result);

	Result = adi_gpio_RegisterCallback(
	    	ADI_GPIO_PORT_G,
	        ADI_GPIO_PIN_13,
	        LED_PB_Callback,
	        (void*)0);
	CheckResult("PB2 RegisterCallback",Result);


	return Result;
}

void LED_PB_Callback(ADI_GPIO_PORT ePort, uint32_t pin, void *pCBParam)
{
    if (ePort == ADI_GPIO_PORT_G)
    {
        if (pin & ADI_GPIO_PIN_0)
        {
            SSM2603_VolumeUp();
        }
        else if (pin & ADI_GPIO_PIN_13)
        {
            SSM2603_VolumeDown();
        }
    }
}

ADI_GPIO_RESULT SetClearToggleLED(uint32_t action, uint32_t LED)
{
	ADI_GPIO_RESULT Result = ADI_GPIO_SUCCESS;
	if (action == 0)
	{
		if (LED == 1)
		{
			adi_gpio_Set(ADI_GPIO_PORT_F, ADI_GPIO_PIN_8);
		}else if (LED == 2) {
			adi_gpio_Set(ADI_GPIO_PORT_G, ADI_GPIO_PIN_11);
		} else if (LED == 3){
			adi_gpio_Set(ADI_GPIO_PORT_G, ADI_GPIO_PIN_12);
		}
	}
	else if (action == 1)
	{
		if (LED == 1)
		{
			adi_gpio_Clear(ADI_GPIO_PORT_F, ADI_GPIO_PIN_8);
		}else if (LED == 2) {
			adi_gpio_Clear(ADI_GPIO_PORT_G, ADI_GPIO_PIN_11);
		}else if (LED == 3) {
			adi_gpio_Clear(ADI_GPIO_PORT_G, ADI_GPIO_PIN_12);
		}
	}
	else if (action == 2)
	{
		if (LED == 1)
		{
			adi_gpio_Toggle(ADI_GPIO_PORT_F, ADI_GPIO_PIN_8);
		}else if (LED == 2) {
			adi_gpio_Toggle(ADI_GPIO_PORT_G, ADI_GPIO_PIN_11);
		}else if (LED == 3) {
			adi_gpio_Toggle(ADI_GPIO_PORT_G, ADI_GPIO_PIN_12);
		}
	}
	return Result;
}
