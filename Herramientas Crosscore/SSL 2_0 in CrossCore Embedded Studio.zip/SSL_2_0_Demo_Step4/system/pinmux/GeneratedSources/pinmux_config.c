/*
 **
 ** pinmux_config.c source file generated on July 17, 2013 at 11:55:53.	
 **
 ** Copyright (C) 2000-2013 Analog Devices Inc., All Rights Reserved.
 **
 ** This file is generated automatically based upon the options selected in 
 ** the Pin Multiplexing configuration editor. Changes to the Pin Multiplexing
 ** configuration should be made by changing the appropriate options rather
 ** than editing this file.
 **
 ** Selected Peripherals
 ** --------------------
 ** SPORT0 (DRPRI, RFS, RSCLK, DTPRI, TFS, TSCLK)
 ** UART1 (TX, RX)
 **
 ** GPIO (unavailable)
 ** ------------------
 ** PF14, PF15, PG6, PG7, PG8, PG9, PG10, PG15
 */

#include <sys/platform.h>
#include <stdint.h>

#define SPORT0_DRPRI_PORTG_MUX  ((uint16_t) ((uint16_t) 1<<4))
#define SPORT0_RFS_PORTG_MUX  ((uint16_t) ((uint16_t) 1<<4))
#define SPORT0_RSCLK_PORTG_MUX  ((uint16_t) ((uint16_t) 1<<6))
#define SPORT0_DTPRI_PORTG_MUX  ((uint16_t) ((uint16_t) 0<<2))
#define SPORT0_TFS_PORTG_MUX  ((uint16_t) ((uint16_t) 0<<12))
#define SPORT0_TSCLK_PORTG_MUX  ((uint16_t) ((uint16_t) 1<<8))
#define UART1_TX_PORTF_MUX  ((uint16_t) ((uint16_t) 2<<10))
#define UART1_RX_PORTF_MUX  ((uint16_t) ((uint16_t) 2<<10))

#define SPORT0_DRPRI_PORTG_FER  ((uint16_t) ((uint16_t) 1<<7))
#define SPORT0_RFS_PORTG_FER  ((uint16_t) ((uint16_t) 1<<8))
#define SPORT0_RSCLK_PORTG_FER  ((uint16_t) ((uint16_t) 1<<9))
#define SPORT0_DTPRI_PORTG_FER  ((uint16_t) ((uint16_t) 1<<6))
#define SPORT0_TFS_PORTG_FER  ((uint16_t) ((uint16_t) 1<<15))
#define SPORT0_TSCLK_PORTG_FER  ((uint16_t) ((uint16_t) 1<<10))
#define UART1_TX_PORTF_FER  ((uint16_t) ((uint16_t) 1<<14))
#define UART1_RX_PORTF_FER  ((uint16_t) ((uint16_t) 1<<15))

int32_t adi_initpinmux(void);

/*
 * Initialize the Port Control MUX and FER Registers
 */
int32_t adi_initpinmux(void) {
    /* PORTx_MUX registers */
    *pPORTF_MUX = UART1_TX_PORTF_MUX | UART1_RX_PORTF_MUX;
    *pPORTG_MUX = SPORT0_DRPRI_PORTG_MUX | SPORT0_RFS_PORTG_MUX
     | SPORT0_RSCLK_PORTG_MUX | SPORT0_DTPRI_PORTG_MUX | SPORT0_TFS_PORTG_MUX
     | SPORT0_TSCLK_PORTG_MUX;

    /* PORTx_FER registers */
    *pPORTF_FER = UART1_TX_PORTF_FER | UART1_RX_PORTF_FER;
    *pPORTG_FER = SPORT0_DRPRI_PORTG_FER | SPORT0_RFS_PORTG_FER
     | SPORT0_RSCLK_PORTG_FER | SPORT0_DTPRI_PORTG_FER | SPORT0_TFS_PORTG_FER
     | SPORT0_TSCLK_PORTG_FER;
    return 0;
}

