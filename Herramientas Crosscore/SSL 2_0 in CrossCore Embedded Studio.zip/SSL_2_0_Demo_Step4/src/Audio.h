/*
 * Audio.h
 */

#ifndef AUDIO_H_
#define AUDIO_H_

#include <drivers/codec/ssm2603/adi_ssm2603.h>

ADI_SSM2603_RESULT SSM2603_Init(void);
ADI_SSM2603_RESULT SSM2603_StartAudio(void);
ADI_SSM2603_RESULT SSM2603_ProcessAudio(void);
void SSM2603_VolumeUp(void);
void SSM2603_VolumeDown(void);

#define OUT_VOLUME_LEVEL        80u
#define IN_VOLUME_LEVEL        80u
static uint8_t CurrentVolumeLevel_0_100 = OUT_VOLUME_LEVEL;
static uint8_t SetVolumeLevel_0_100 = OUT_VOLUME_LEVEL;


#endif /* AUDIO_H_ */
