/*
 * Audio.c
 */

#include "Audio.h"
#include "SSL_CCES_Demo.h"
#include "UART.h"
#include <string.h>
#include <stdio.h>

static ADI_SSM2603_HANDLE hAudioDevice;
static uint8_t gAudioMemory[ADI_SSM2603_MEMORY_SIZE];

#define BUFFER_SIZE             1024u

#pragma align 4
static uint8_t InAudio1[BUFFER_SIZE];
static uint8_t InAudio2[BUFFER_SIZE];
static uint8_t OpAudio1[BUFFER_SIZE];
static uint8_t OpAudio2[BUFFER_SIZE];

ADI_SSM2603_RESULT SSM2603_Init(void)
{
	ADI_SSM2603_RESULT Result = ADI_SSM2603_SUCCESS;

	Result = adi_ssm2603_Open(0u,
			&gAudioMemory,
			ADI_SSM2603_MEMORY_SIZE,
			&hAudioDevice);
	CheckResult("SSM2603 Open",Result);

	Result = adi_ssm2603_SetTWIDevice(hAudioDevice,
			0u,
			ADI_SSM2603_TWI_ADDR1_27,
			NULL);
	CheckResult("SSM2603 SetTWIDevice",Result);

	Result = adi_ssm2603_SetSPORTDevice(hAudioDevice,
			0u,
			ADI_SSM2603_ADC_DAC,
			NULL);
	CheckResult("SSM2603 SetSPORTDevice", Result);

	Result = adi_ssm2603_SetRegister(hAudioDevice,
			ADI_SSM2603_RESET_REG,
			0x0u);
	CheckResult("SSM2603 Reset to Defaults", Result);

	Result = adi_ssm2603_SetSamplingRate(hAudioDevice,
			ADI_SSM2603_44100_SR,
			ADI_SSM2603_44100_SR,
			ADI_SSM2603_12_0000_MCLK);
	CheckResult("SSM2603 SetSamplingRate", Result);

	memset(InAudio1, 0, BUFFER_SIZE);
	memset(InAudio2, 0, BUFFER_SIZE);
	memset(OpAudio1, 0, BUFFER_SIZE);
	memset(OpAudio2, 0, BUFFER_SIZE);

	Result = adi_ssm2603_SubmitRxBuffer(hAudioDevice, &InAudio1[0], BUFFER_SIZE);
	CheckResult("Submit Rx Buf 1", Result);
	Result = adi_ssm2603_SubmitTxBuffer(hAudioDevice, &OpAudio1[0], BUFFER_SIZE);
	CheckResult("Submit Tx Buf 1", Result);
	Result = adi_ssm2603_SubmitRxBuffer(hAudioDevice, &InAudio2[0], BUFFER_SIZE);
	CheckResult("Submit Rx Buf 2", Result);
	Result = adi_ssm2603_SubmitTxBuffer(hAudioDevice, &OpAudio2[0], BUFFER_SIZE);
	CheckResult("Submit Tx Buf 2", Result);

	return Result;
}

ADI_SSM2603_RESULT SSM2603_StartAudio(void)
{
	ADI_SSM2603_RESULT Result = ADI_SSM2603_SUCCESS;

	Result = adi_ssm2603_TxEnable(hAudioDevice, true);
	CheckResult("Enable SSM2603 Tx", Result);

	Result = adi_ssm2603_RxEnable(hAudioDevice, true);
	CheckResult("Enable SSM2603 Rx", Result);

	adi_ssm2603_SetVolume(hAudioDevice, ADI_SSM2603_DAC_LEFT, CurrentVolumeLevel_0_100);
	adi_ssm2603_SetVolume(hAudioDevice, ADI_SSM2603_DAC_RIGHT, CurrentVolumeLevel_0_100);
	adi_ssm2603_SetVolume(hAudioDevice, ADI_SSM2603_ADC_LEFT, IN_VOLUME_LEVEL);
	adi_ssm2603_SetVolume(hAudioDevice, ADI_SSM2603_ADC_RIGHT, IN_VOLUME_LEVEL);

	return Result;
}


ADI_SSM2603_RESULT SSM2603_ProcessAudio(void)
{
	ADI_SSM2603_RESULT Result = ADI_SSM2603_SUCCESS;

	void *pGetADC = NULL;
	void *pGetDAC = NULL;

	Result = adi_ssm2603_GetRxBuffer(hAudioDevice, &pGetADC);
	CheckResult("Process: GetRxBuffer", Result);

	Result = adi_ssm2603_GetTxBuffer(hAudioDevice, &pGetDAC);
	CheckResult("Process: GetTxBuffer", Result);

	if(pGetDAC != NULL && pGetADC != NULL)
	{
		memcpy(pGetDAC, pGetADC, BUFFER_SIZE);
	}

	Result = adi_ssm2603_SubmitRxBuffer(hAudioDevice, (uint8_t *)pGetADC, BUFFER_SIZE);
	CheckResult("Process: Re-SubmitRxBuffer", Result);

	Result = adi_ssm2603_SubmitTxBuffer(hAudioDevice, (uint8_t *)pGetDAC, BUFFER_SIZE);
	CheckResult("Process: Re-SubmitTxBuffer", Result);

	pGetADC = NULL;
	pGetDAC = NULL;

	return Result;
}


void SSM2603_VolumeUp(void)
{
}

void SSM2603_VolumeDown(void)
{
}

