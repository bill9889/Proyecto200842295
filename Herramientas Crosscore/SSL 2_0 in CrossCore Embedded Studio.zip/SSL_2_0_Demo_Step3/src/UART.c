/*
 * UART.c
 */

#include "UART.h"
#include "SSL_CCES_Demo.h"
#include <string.h>

static uint8_t gUARTMemory[ADI_UART_UNIDIR_DMA_MEMORY_SIZE];
static ADI_UART_HANDLE hUARTDevice;
#define UART_BUFFER_SIZE             64u

#pragma align 4
static uint8_t UARTPrintBuf1[UART_BUFFER_SIZE];
static uint8_t UARTPrintBuf2[UART_BUFFER_SIZE];

ADI_UART_RESULT UARTInit(void)
{
	ADI_UART_RESULT Result = ADI_UART_SUCCESS;

	Result = adi_uart_Open(1,
		ADI_UART_DIR_TRANSMIT,
		gUARTMemory,
		ADI_UART_UNIDIR_DMA_MEMORY_SIZE,
		&hUARTDevice);
	CheckResult("UART Open", Result);

	Result = adi_uart_SetConfiguration(hUARTDevice,
	ADI_UART_NO_PARITY,
	ADI_UART_ONE_STOPBIT,
	ADI_UART_WORDLEN_8BITS);
	CheckResult("UART Config", Result);

	Result = adi_uart_SetBaudRate(hUARTDevice, 19200u);
	CheckResult("UART Baud Rate", Result);

	Result = adi_uart_EnableDMAMode(hUARTDevice, true);
	CheckResult("UART EnableDMA", Result);

	memset(UARTPrintBuf1, 42, UART_BUFFER_SIZE);
	memset(UARTPrintBuf2, 42, UART_BUFFER_SIZE);
	UARTPrintBuf1[UART_BUFFER_SIZE-2] = '\r';
	UARTPrintBuf1[UART_BUFFER_SIZE-1] = '\n';
	UARTPrintBuf2[UART_BUFFER_SIZE-2] = '\r';
	UARTPrintBuf2[UART_BUFFER_SIZE-1] = '\n';

	Result = adi_uart_SubmitTxBuffer(hUARTDevice, UARTPrintBuf1, UART_BUFFER_SIZE);
	CheckResult("Submit UARTBuffer1", Result);
	Result = adi_uart_SubmitTxBuffer(hUARTDevice, UARTPrintBuf2, UART_BUFFER_SIZE);
	CheckResult("Submit UARTBuffer2", Result);

	Result = adi_uart_EnableTx(hUARTDevice, true);
	CheckResult("Enable UARTTx",Result);

	return Result;
}

ADI_UART_RESULT UARTPrint(char *UART_String)
{
	ADI_UART_RESULT Result = ADI_UART_SUCCESS;

	void *pGetUART = NULL;
	uint32_t string_length;

	Result = adi_uart_GetTxBuffer(hUARTDevice, &pGetUART);
	CheckResult("GetTxBuffer",Result);

	if(pGetUART != NULL && UART_String != NULL)
	{
		string_length = strlen(UART_String);
		memcpy(pGetUART, UART_String, string_length);
	}

	Result = adi_uart_SubmitTxBuffer(hUARTDevice, pGetUART, string_length);
	CheckResult("Submit Buffer",Result);

	return Result;
}
