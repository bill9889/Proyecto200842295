/*
 * UART.h
 */

#ifndef UART_H_
#define UART_H_

#include <drivers/uart/adi_uart.h>

ADI_UART_RESULT UARTInit(void);
ADI_UART_RESULT UARTPrint(char *UART_String);

#endif /* UART_H_ */
