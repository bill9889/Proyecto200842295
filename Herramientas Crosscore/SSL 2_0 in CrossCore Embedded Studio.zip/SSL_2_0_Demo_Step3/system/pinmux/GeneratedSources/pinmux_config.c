/*
 **
 ** pinmux_config.c source file generated on July 17, 2013 at 11:51:50.	
 **
 ** Copyright (C) 2000-2013 Analog Devices Inc., All Rights Reserved.
 **
 ** This file is generated automatically based upon the options selected in 
 ** the Pin Multiplexing configuration editor. Changes to the Pin Multiplexing
 ** configuration should be made by changing the appropriate options rather
 ** than editing this file.
 **
 ** Selected Peripherals
 ** --------------------
 ** UART1 (TX, RX)
 **
 ** GPIO (unavailable)
 ** ------------------
 ** PF14, PF15
 */

#include <sys/platform.h>
#include <stdint.h>

#define UART1_TX_PORTF_MUX  ((uint16_t) ((uint16_t) 2<<10))
#define UART1_RX_PORTF_MUX  ((uint16_t) ((uint16_t) 2<<10))

#define UART1_TX_PORTF_FER  ((uint16_t) ((uint16_t) 1<<14))
#define UART1_RX_PORTF_FER  ((uint16_t) ((uint16_t) 1<<15))

int32_t adi_initpinmux(void);

/*
 * Initialize the Port Control MUX and FER Registers
 */
int32_t adi_initpinmux(void) {
    /* PORTx_MUX registers */
    *pPORTF_MUX = UART1_TX_PORTF_MUX | UART1_RX_PORTF_MUX;

    /* PORTx_FER registers */
    *pPORTF_FER = UART1_TX_PORTF_FER | UART1_RX_PORTF_FER;
    return 0;
}

